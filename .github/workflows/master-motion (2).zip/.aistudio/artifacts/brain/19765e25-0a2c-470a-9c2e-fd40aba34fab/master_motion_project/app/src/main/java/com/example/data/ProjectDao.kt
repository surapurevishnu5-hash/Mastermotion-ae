package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM motion_projects ORDER BY updatedAt DESC")
    fun observeAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM motion_projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): Project?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(project: Project)

    @Query("UPDATE motion_projects SET name = :name, updatedAt = :lastModified WHERE id = :id")
    suspend fun updateProjectMetadata(id: String, name: String, lastModified: Long)

    @Query("DELETE FROM motion_projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)
}
