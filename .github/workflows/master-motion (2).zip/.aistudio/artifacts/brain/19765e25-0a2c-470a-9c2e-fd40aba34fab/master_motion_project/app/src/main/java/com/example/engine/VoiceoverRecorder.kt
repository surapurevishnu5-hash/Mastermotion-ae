package com.example.engine

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RecordedVoiceoverResult(
    val filePath: String,
    val displayName: String,
    val durationMs: Long,
    val waveformSamples: List<Float>
)

/**
 * Hardware-backed Android MediaRecorder wrapper for capturing studio AAC (.m4a) voiceovers
 * directly into the project's local media storage directory.
 */
class VoiceoverRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var startTimeMs: Long = 0L
    private val capturedSamples = mutableListOf<Float>()

    var isRecording: Boolean = false
        private set

    fun startRecording(projectId: String): Boolean {
        if (isRecording) return false
        cancelAndRelease()

        val mediaDir = File(context.filesDir, "project_media/$projectId").apply {
            if (!exists()) mkdirs()
        }
        val targetFile = File(mediaDir, "voiceover_${System.currentTimeMillis()}.m4a")

        val instance = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        return try {
            instance.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44_100)
                setAudioEncodingBitRate(128_000)
                setAudioChannels(1)
                setOutputFile(targetFile.absolutePath)
                prepare()
                start()
            }
            recorder = instance
            outputFile = targetFile
            startTimeMs = System.currentTimeMillis()
            capturedSamples.clear()
            isRecording = true
            true
        } catch (_: Throwable) {
            runCatching { instance.reset() }
            runCatching { instance.release() }
            runCatching { targetFile.delete() }
            recorder = null
            outputFile = null
            isRecording = false
            false
        }
    }

    fun pollAmplitude(): Float {
        if (!isRecording) return 0f
        val amp = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
        val normalized = (amp / 32767f).coerceIn(0.08f, 1.0f)
        capturedSamples.add(normalized)
        return normalized
    }

    fun elapsedMs(): Long =
        if (isRecording) (System.currentTimeMillis() - startTimeMs).coerceAtLeast(0L) else 0L

    fun stopRecording(): RecordedVoiceoverResult? {
        if (!isRecording) return null
        val file = outputFile
        val recordedDurationMs = (System.currentTimeMillis() - startTimeMs).coerceAtLeast(300L)
        isRecording = false

        val stoppedCleanly = runCatching {
            recorder?.stop()
            true
        }.getOrDefault(false)

        runCatching { recorder?.reset() }
        runCatching { recorder?.release() }
        recorder = null
        outputFile = null

        if (!stoppedCleanly || file == null || !file.exists() || file.length() == 0L) {
            runCatching { file?.delete() }
            capturedSamples.clear()
            return null
        }

        val finalDuration = extractAudioDuration(file.absolutePath, recordedDurationMs)
        val waveform = resampleWaveform(capturedSamples, 48)
        capturedSamples.clear()
        val labelTime = SimpleDateFormat("HH:mm", Locale.US).format(Date())

        return RecordedVoiceoverResult(
            filePath = file.absolutePath,
            displayName = "Voiceover $labelTime",
            durationMs = finalDuration.coerceAtLeast(500L),
            waveformSamples = waveform
        )
    }

    fun cancelAndRelease() {
        isRecording = false
        runCatching { recorder?.stop() }
        runCatching { recorder?.reset() }
        runCatching { recorder?.release() }
        recorder = null
        outputFile?.let { f -> runCatching { if (f.exists()) f.delete() } }
        outputFile = null
        capturedSamples.clear()
    }

    private fun extractAudioDuration(path: String, fallbackMs: Long): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?.coerceAtLeast(300L)
                ?: fallbackMs
        } catch (_: Throwable) {
            fallbackMs
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun resampleWaveform(samples: List<Float>, targetCount: Int): List<Float> {
        if (samples.isEmpty()) return List(targetCount) { 0.35f }
        if (samples.size <= targetCount) {
            val out = samples.toMutableList()
            while (out.size < targetCount) {
                out.add(samples[out.size % samples.size])
            }
            return out
        }
        return List(targetCount) { i ->
            val idx = ((i.toFloat() / targetCount.toFloat()) * samples.size)
                .toInt()
                .coerceIn(0, samples.lastIndex)
            samples[idx].coerceIn(0.12f, 1.0f)
        }
    }
}
