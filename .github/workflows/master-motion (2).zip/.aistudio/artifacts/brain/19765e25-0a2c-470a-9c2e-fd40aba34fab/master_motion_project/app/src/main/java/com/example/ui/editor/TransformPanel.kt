package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.KeyframeEvaluator
import com.example.model.AnimatableProperty
import com.example.model.MotionLayer
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.KeyframeMagenta
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun TransformPanel(
    layer: MotionLayer?,
    playheadMs: Long,
    is3DMode: Boolean,
    linkScale: Boolean,
    onSet3DMode: (Boolean) -> Unit,
    onToggleLinkScale: () -> Unit,
    onUpdateProperty: (AnimatableProperty, Float) -> Unit,
    onUpdateLinkedScale: (Float) -> Unit,
    onUpdateCameraDistance: (Float) -> Unit,
    onBeginSliderEdit: () -> Unit = {},
    onEndSliderEdit: () -> Unit = {},
    onToggleKeyframe: (AnimatableProperty) -> Unit,
    onJumpKeyframe: (AnimatableProperty, Int) -> Unit,
    onResetTransform: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (layer == null) {
        EmptyInspectorHint("Select a layer on the timeline to edit 2D & 3D transforms and keyframes.", modifier)
        return
    }

    val scroll = rememberScrollState()

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(12.dp)
    ) {
        // 2D / 3D Mode Switcher + Reset
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(StudioInspector)
                    .padding(3.dp)
            ) {
                ModeChip(
                    label = "2D Motion",
                    selected = !is3DMode,
                    onClick = { onSet3DMode(false) },
                    testTag = "transform_2d_tab"
                )
                ModeChip(
                    label = "3D Space",
                    selected = is3DMode,
                    icon = Icons.Filled.ViewInAr,
                    onClick = { onSet3DMode(true) },
                    testTag = "transform_3d_tab"
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!is3DMode) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (linkScale) CyberBlue.copy(alpha = 0.2f) else StudioInspector,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (linkScale) CyberBlue else StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onToggleLinkScale)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (linkScale) Icons.Filled.Link else Icons.Filled.LinkOff,
                                contentDescription = "Link Scale",
                                tint = if (linkScale) CyberCyan else TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scale", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        }
                    }
                }

                IconButton(
                    onClick = onResetTransform,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = "Reset Transform", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }

        val props = if (is3DMode) {
            AnimatableProperty.properties3D
        } else {
            if (linkScale) {
                listOf(
                    AnimatableProperty.POSITION_X,
                    AnimatableProperty.POSITION_Y,
                    AnimatableProperty.SCALE_X,
                    AnimatableProperty.ROTATION_Z,
                    AnimatableProperty.OPACITY
                )
            } else {
                AnimatableProperty.properties2D
            }
        }

        props.forEach { prop ->
            val label = if (!is3DMode && linkScale && prop == AnimatableProperty.SCALE_X) "Uniform Scale" else prop.label
            val value = KeyframeEvaluator.evaluateProperty(layer, prop, playheadMs)
            val kfs = layer.keyframesFor(prop)
            val hasKfHere = KeyframeEvaluator.hasKeyframeNear(kfs, playheadMs)

            PropertySliderCard(
                label = label,
                property = prop,
                value = value,
                keyframeCount = kfs.size,
                hasKeyframeAtPlayhead = hasKfHere,
                accentColor = if (is3DMode) CyberCyan else ElectricPurple,
                onValueChange = { next ->
                    onBeginSliderEdit()
                    if (!is3DMode && linkScale && prop == AnimatableProperty.SCALE_X) {
                        onUpdateLinkedScale(next)
                    } else {
                        onUpdateProperty(prop, next)
                    }
                },
                onValueChangeFinished = onEndSliderEdit,
                onToggleKeyframe = { onToggleKeyframe(prop) },
                onPrevKeyframe = { onJumpKeyframe(prop, -1) },
                onNextKeyframe = { onJumpKeyframe(prop, 1) }
            )
        }

        if (is3DMode) {
            // Camera perspective distance control
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = StudioSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Camera Perspective", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                        Text(
                            text = String.format(Locale.US, "%.1f", layer.baseTransform.cameraDistance),
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan
                        )
                    }
                    Slider(
                        value = layer.baseTransform.cameraDistance,
                        onValueChange = {
                            onBeginSliderEdit()
                            onUpdateCameraDistance(it)
                        },
                        onValueChangeFinished = onEndSliderEdit,
                        valueRange = 3f..28f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyberCyan,
                            activeTrackColor = CyberBlue
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeChip(
    label: String,
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) ElectricPurple else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag(testTag)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) Color.White else TextSecondary
        )
    }
}

@Composable
private fun PropertySliderCard(
    label: String,
    property: AnimatableProperty,
    value: Float,
    keyframeCount: Int,
    hasKeyframeAtPlayhead: Boolean,
    accentColor: Color,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    onToggleKeyframe: () -> Unit,
    onPrevKeyframe: () -> Unit,
    onNextKeyframe: () -> Unit
) {
    val formattedValue = when (property) {
        AnimatableProperty.OPACITY -> "${(value * 100f).toInt()}%"
        AnimatableProperty.ROTATION_X,
        AnimatableProperty.ROTATION_Y,
        AnimatableProperty.ROTATION_Z -> String.format(Locale.US, "%.1f°", value)
        AnimatableProperty.SCALE_X,
        AnimatableProperty.SCALE_Y -> String.format(Locale.US, "%.2fx", value)
        else -> String.format(Locale.US, "%.2f", value)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = StudioSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (hasKeyframeAtPlayhead) KeyframeMagenta.copy(alpha = 0.7f) else StudioBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = formattedValue,
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onPrevKeyframe,
                    enabled = keyframeCount > 0,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = "Previous Keyframe",
                        tint = if (keyframeCount > 0) TextSecondary else TextSecondary.copy(alpha = 0.25f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (hasKeyframeAtPlayhead) KeyframeMagenta.copy(alpha = 0.25f)
                            else StudioInspector
                        )
                        .clickable(onClick = onToggleKeyframe)
                        .testTag("kf_toggle_${property.name}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Diamond,
                        contentDescription = "Toggle Keyframe",
                        tint = when {
                            hasKeyframeAtPlayhead -> KeyframeMagenta
                            keyframeCount > 0 -> CyberCyan
                            else -> TextSecondary
                        },
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = onNextKeyframe,
                    enabled = keyframeCount > 0,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Next Keyframe",
                        tint = if (keyframeCount > 0) TextSecondary else TextSecondary.copy(alpha = 0.25f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Slider(
                value = value.coerceIn(property.minValue, property.maxValue),
                onValueChange = onValueChange,
                onValueChangeFinished = onValueChangeFinished,
                valueRange = property.minValue..property.maxValue,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = accentColor,
                    inactiveTrackColor = StudioBorder
                ),
                modifier = Modifier
                    .height(28.dp)
                    .testTag("slider_${property.name}")
            )
        }
    }
}

@Composable
fun EmptyInspectorHint(message: String, modifier: Modifier = Modifier) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
    }
}
