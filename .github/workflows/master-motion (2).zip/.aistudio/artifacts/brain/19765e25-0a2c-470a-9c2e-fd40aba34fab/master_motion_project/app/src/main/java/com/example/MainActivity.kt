package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.ProjectRepository
import com.example.engine.MediaExporter
import com.example.engine.MediaManager
import com.example.ui.editor.EditorScreen
import com.example.ui.gallery.ExportsGalleryScreen
import com.example.ui.hub.ProjectsHubScreen
import com.example.ui.theme.MasterMotionTheme
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.ProjectsViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var repository: ProjectRepository

    @Inject
    lateinit var mediaManager: MediaManager

    @Inject
    lateinit var mediaExporter: MediaExporter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MasterMotionTheme {
                MasterMotionApp(
                    repository = repository,
                    mediaManager = mediaManager,
                    exporter = mediaExporter
                )
            }
        }
    }
}

@Composable
fun MasterMotionApp(
    repository: ProjectRepository,
    mediaManager: MediaManager,
    exporter: MediaExporter
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "hub"
    ) {
        composable("hub") {
            val projectsViewModel: ProjectsViewModel = hiltViewModel()
            ProjectsHubScreen(
                viewModel = projectsViewModel,
                onOpenProject = { projectId ->
                    navController.navigate("editor/$projectId")
                },
                onOpenExportsGallery = {
                    navController.navigate("exports")
                }
            )
        }

        composable("exports") {
            val galleryViewModel: com.example.viewmodel.ExportsGalleryViewModel = hiltViewModel()
            ExportsGalleryScreen(
                viewModel = galleryViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "editor/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId").orEmpty()
            val editorViewModel: EditorViewModel = viewModel(
                key = "editor_$projectId",
                factory = EditorViewModel.Factory(
                    projectId = projectId,
                    repository = repository,
                    mediaManager = mediaManager,
                    mediaExporter = exporter
                )
            )
            EditorScreen(
                viewModel = editorViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenExportsGallery = { navController.navigate("exports") }
            )
        }
    }
}
