package com.example.data

import com.example.model.MotionProject
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

object ProjectSerializer {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(MotionProject::class.java)

    fun toJson(project: MotionProject): String = adapter.toJson(project)

    fun fromJson(json: String): MotionProject? = runCatching {
        adapter.fromJson(json)
    }.getOrNull()
}
