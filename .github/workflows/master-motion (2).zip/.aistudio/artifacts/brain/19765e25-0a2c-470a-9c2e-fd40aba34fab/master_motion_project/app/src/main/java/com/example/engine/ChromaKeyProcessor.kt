package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sqrt

object ChromaKeyProcessor {

    private val keyedCache = object : LruCache<String, Bitmap>(16 * 1024) { // 16 MB cache in KB
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    fun clearCache() {
        keyedCache.evictAll()
    }

    fun applyChromaKey(
        source: Bitmap,
        keyColorHex: Long,
        tolerance: Float,
        spillSuppression: Float,
        useCache: Boolean = true
    ): Bitmap {
        val tol = tolerance.coerceIn(0f, 1f)
        val spill = spillSuppression.coerceIn(0f, 1f)
        val keyInt = keyColorHex.toInt()

        val cacheKey = if (useCache) {
            "${System.identityHashCode(source)}_${source.width}x${source.height}_${keyInt}_${(tol * 200f).roundToInt()}_${(spill * 200f).roundToInt()}"
        } else null

        if (cacheKey != null) {
            val cached = keyedCache.get(cacheKey)
            if (cached != null && !cached.isRecycled) {
                return cached
            }
        }

        val w = source.width.coerceAtLeast(1)
        val h = source.height.coerceAtLeast(1)
        val total = w * h
        val pixels = IntArray(total)
        source.getPixels(pixels, 0, w, 0, 0, w, h)

        processPixels(
            pixels = pixels,
            keyColorInt = keyInt,
            tolerance = tol,
            spillSuppression = spill
        )

        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        output.setPixels(pixels, 0, w, 0, 0, w, h)

        if (cacheKey != null) {
            keyedCache.put(cacheKey, output)
        }
        return output
    }

    /**
     * Performs YCbCr chroma-key matting and chroma-axis spill suppression directly on ARGB pixels.
     */
    fun processPixels(
        pixels: IntArray,
        keyColorInt: Int,
        tolerance: Float,
        spillSuppression: Float
    ) {
        val kr = Color.red(keyColorInt) / 255f
        val kg = Color.green(keyColorInt) / 255f
        val kb = Color.blue(keyColorInt) / 255f

        val kY = 0.299f * kr + 0.587f * kg + 0.114f * kb
        val kCb = -0.168736f * kr - 0.331264f * kg + 0.5f * kb
        val kCr = 0.5f * kr - 0.418688f * kg - 0.081312f * kb
        val kChromaMag = hypot(kCb, kCr)
        val isChromaticKey = kChromaMag > 0.06f
        val uCb = if (isChromaticKey) kCb / kChromaMag else 0f
        val uCr = if (isChromaticKey) kCr / kChromaMag else 0f

        val t = tolerance.coerceIn(0f, 1f)
        val spill = spillSuppression.coerceIn(0f, 1f)
        val tolMin = 0.03f + t * 0.40f
        val feather = 0.06f + t * 0.14f
        val tolMax = tolMin + feather

        for (i in pixels.indices) {
            val px = pixels[i]
            val a = (px ushr 24) and 0xFF
            if (a == 0) continue

            val rInt = (px ushr 16) and 0xFF
            val gInt = (px ushr 8) and 0xFF
            val bInt = px and 0xFF

            val r = rInt / 255f
            val g = gInt / 255f
            val b = bInt / 255f

            val pY = 0.299f * r + 0.587f * g + 0.114f * b
            val pCb = -0.168736f * r - 0.331264f * g + 0.5f * b
            val pCr = 0.5f * r - 0.418688f * g - 0.081312f * b

            val dist = if (isChromaticKey) {
                val chromaDist = hypot(pCb - kCb, pCr - kCr)
                val lumaDist = abs(pY - kY)
                chromaDist + 0.16f * lumaDist
            } else {
                val dr = r - kr
                val dg = g - kg
                val db = b - kb
                sqrt(dr * dr + dg * dg + db * db) * 0.58f
            }

            val alphaScale = when {
                dist <= tolMin -> 0f
                dist >= tolMax -> 1f
                else -> {
                    val u = ((dist - tolMin) / feather).coerceIn(0f, 1f)
                    u * u * (3f - 2f * u) // smoothstep edge anti-aliasing
                }
            }

            val outA = (a * alphaScale).roundToInt().coerceIn(0, 255)
            if (outA == 0) {
                pixels[i] = 0
                continue
            }

            if (spill > 0.005f && isChromaticKey) {
                val proj = pCb * uCb + pCr * uCr
                if (proj > 0f) {
                    val removeProj = proj * spill
                    val newCb = pCb - uCb * removeProj
                    val newCr = pCr - uCr * removeProj

                    val outR = ((pY + 1.402f * newCr).coerceIn(0f, 1f) * 255f).roundToInt().coerceIn(0, 255)
                    val outG = ((pY - 0.344136f * newCb - 0.714136f * newCr).coerceIn(0f, 1f) * 255f).roundToInt().coerceIn(0, 255)
                    val outB = ((pY + 1.772f * newCb).coerceIn(0f, 1f) * 255f).roundToInt().coerceIn(0, 255)
                    pixels[i] = (outA shl 24) or (outR shl 16) or (outG shl 8) or outB
                    continue
                }
            }

            pixels[i] = (outA shl 24) or (rInt shl 16) or (gInt shl 8) or bInt
        }
    }
}
