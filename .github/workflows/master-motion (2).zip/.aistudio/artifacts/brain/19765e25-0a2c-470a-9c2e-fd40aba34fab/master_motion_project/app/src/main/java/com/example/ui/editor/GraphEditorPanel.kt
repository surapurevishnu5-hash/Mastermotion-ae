package com.example.ui.editor

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.KeyframeEvaluator
import com.example.model.AnimatableProperty
import com.example.model.CubicBezierCurve
import com.example.model.MotionLayer
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.KeyframeMagenta
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.hypot

@Composable
fun GraphEditorPanel(
    layer: MotionLayer?,
    selectedProperty: AnimatableProperty,
    selectedSegmentIndex: Int,
    onSelectProperty: (AnimatableProperty) -> Unit,
    onSelectSegment: (Int) -> Unit,
    onUpdateCurve: (AnimatableProperty, Int, CubicBezierCurve, Boolean) -> Unit,
    onBeginBezierEdit: () -> Unit = {},
    onEndBezierEdit: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    if (layer == null) {
        EmptyInspectorHint("Select a layer with 2+ keyframes to edit easing curves in the Graph Editor.", modifier)
        return
    }

    val keyframedProps = remember(layer.keyframeTracks) {
        AnimatableProperty.entries.filter { layer.keyframesFor(it).size >= 2 }
    }

    val activeProp = if (selectedProperty in keyframedProps) {
        selectedProperty
    } else {
        keyframedProps.firstOrNull() ?: selectedProperty
    }

    val keyframes = layer.keyframesFor(activeProp)
    val segmentCount = (keyframes.size - 1).coerceAtLeast(0)
    val activeSegmentIdx = selectedSegmentIndex.coerceIn(0, (segmentCount - 1).coerceAtLeast(0))

    val scroll = rememberScrollState()

    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(12.dp)
    ) {
        // Property Selector Strip
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            val propsToShow = if (keyframedProps.isNotEmpty()) keyframedProps else AnimatableProperty.properties2D
            propsToShow.forEach { prop ->
                val count = layer.keyframesFor(prop).size
                val selected = prop == activeProp
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (selected) ElectricPurple.copy(alpha = 0.25f) else StudioSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selected) ElectricPurple else StudioBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSelectProperty(prop) }
                ) {
                    Text(
                        text = if (count >= 2) "${prop.label} ($count)" else prop.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) Color.White else TextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        if (segmentCount == 0) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = StudioSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "No Keyframe Segments for ${activeProp.label}",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Add at least 2 keyframes on ${activeProp.label} in the Transform tab to sculpt custom Bezier easing curves.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
            return
        }

        // Segment Selector if multiple segments
        if (segmentCount > 1) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                for (i in 0 until segmentCount) {
                    val selected = i == activeSegmentIdx
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selected) CyberBlue.copy(alpha = 0.28f) else StudioInspector,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) CyberCyan else StudioBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSelectSegment(i) }
                    ) {
                        Text(
                            text = "KF ${i + 1} → ${i + 2}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (selected) Color.White else TextSecondary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }

        val currentCurve = keyframes[activeSegmentIdx].curve

        // Interactive Cubic Bezier Curve Canvas
        val infiniteTransition = rememberInfiniteTransition(label = "bezier_preview")
        val previewProgress by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1600, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "curve_tracer"
        )

        var activeHandle by remember { mutableIntStateOf(0) } // 0 = none, 1 = P1, 2 = P2
        var liveCurve by remember(activeProp, activeSegmentIdx, currentCurve) {
            mutableStateOf(currentCurve)
        }
        val latestCurve by rememberUpdatedState(liveCurve)

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = ObsidianBg,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = liveCurve.presetName,
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberCyan
                    )
                    Text(
                        text = if (liveCurve.isStep) "HOLD (STEP)" else String.format(
                            Locale.US,
                            "bezier(%.2f, %.2f, %.2f, %.2f)",
                            liveCurve.x1, liveCurve.y1, liveCurve.x2, liveCurve.y2
                        ),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.testTag("graph_bezier_readout")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(136.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioSurfaceElevated.copy(alpha = 0.45f))
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(activeProp, activeSegmentIdx) {
                                detectDragGestures(
                                    onDragStart = { startOffset ->
                                        val padX = 28f
                                        val padY = 34f
                                        val plotW = (size.width - padX * 2f).coerceAtLeast(10f)
                                        val plotH = (size.height - padY * 2f).coerceAtLeast(10f)

                                        val p1Screen = Offset(
                                            padX + latestCurve.x1 * plotW,
                                            padY + (1f - latestCurve.y1) * plotH
                                        )
                                        val p2Screen = Offset(
                                            padX + latestCurve.x2 * plotW,
                                            padY + (1f - latestCurve.y2) * plotH
                                        )
                                        val d1 = hypot(startOffset.x - p1Screen.x, startOffset.y - p1Screen.y)
                                        val d2 = hypot(startOffset.x - p2Screen.x, startOffset.y - p2Screen.y)
                                        activeHandle = if (d1 <= d2 && d1 < 72f) 1 else if (d2 < 72f) 2 else 0
                                        if (activeHandle != 0) onBeginBezierEdit()
                                    },
                                    onDrag = { change, _ ->
                                        if (activeHandle == 0) return@detectDragGestures
                                        change.consume()
                                        val padX = 28f
                                        val padY = 34f
                                        val plotW = (size.width - padX * 2f).coerceAtLeast(10f)
                                        val plotH = (size.height - padY * 2f).coerceAtLeast(10f)

                                        val normX = ((change.position.x - padX) / plotW).coerceIn(0f, 1f)
                                        val normY = (1f - (change.position.y - padY) / plotH).coerceIn(-0.45f, 1.45f)

                                        val updated = if (activeHandle == 1) {
                                            latestCurve.copy(x1 = normX, y1 = normY, isStep = false, presetName = "Custom")
                                        } else {
                                            latestCurve.copy(x2 = normX, y2 = normY, isStep = false, presetName = "Custom")
                                        }
                                        liveCurve = updated
                                        onUpdateCurve(activeProp, activeSegmentIdx, updated, false)
                                    },
                                    onDragEnd = {
                                        if (activeHandle != 0) onEndBezierEdit()
                                        activeHandle = 0
                                    },
                                    onDragCancel = {
                                        if (activeHandle != 0) onEndBezierEdit()
                                        activeHandle = 0
                                    }
                                )
                            }
                            .testTag("graph_bezier_canvas")
                    ) {
                        val padX = 28f
                        val padY = 34f
                        val plotW = (size.width - padX * 2f).coerceAtLeast(10f)
                        val plotH = (size.height - padY * 2f).coerceAtLeast(10f)

                        fun toScreen(nx: Float, ny: Float): Offset =
                            Offset(padX + nx * plotW, padY + (1f - ny) * plotH)

                        // Unit box [0..1] grid
                        for (g in 0..4) {
                            val f = g / 4f
                            val pA = toScreen(f, 0f)
                            val pB = toScreen(f, 1f)
                            drawLine(Color(0xFF2D3348), pA, pB, strokeWidth = 1f)
                            val hA = toScreen(0f, f)
                            val hB = toScreen(1f, f)
                            drawLine(Color(0xFF2D3348), hA, hB, strokeWidth = 1f)
                        }

                        // Linear reference diagonal
                        drawLine(
                            color = Color(0xFF3E4663),
                            start = toScreen(0f, 0f),
                            end = toScreen(1f, 1f),
                            strokeWidth = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                        )

                        val p0 = toScreen(0f, 0f)
                        val p3 = toScreen(1f, 1f)
                        val p1 = toScreen(liveCurve.x1, liveCurve.y1)
                        val p2 = toScreen(liveCurve.x2, liveCurve.y2)

                        // Curve Path
                        val curvePath = Path()
                        if (liveCurve.isStep) {
                            curvePath.moveTo(p0.x, p0.y)
                            curvePath.lineTo(p3.x, p0.y)
                            curvePath.lineTo(p3.x, p3.y)
                        } else {
                            curvePath.moveTo(p0.x, p0.y)
                            curvePath.cubicTo(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y)
                        }
                        drawPath(
                            path = curvePath,
                            brush = Brush.horizontalGradient(listOf(ElectricPurple, CyberCyan)),
                            style = Stroke(width = 4.5f, cap = StrokeCap.Round)
                        )

                        if (!liveCurve.isStep) {
                            // Tangent arms
                            drawLine(ElectricPurple.copy(alpha = 0.7f), p0, p1, strokeWidth = 2f)
                            drawLine(CyberCyan.copy(alpha = 0.7f), p3, p2, strokeWidth = 2f)

                            // Control handle P1
                            drawCircle(ElectricPurple, radius = 12f, center = p1)
                            drawCircle(Color.White, radius = 5f, center = p1)

                            // Control handle P2
                            drawCircle(CyberCyan, radius = 12f, center = p2)
                            drawCircle(Color.White, radius = 5f, center = p2)
                        }

                        // Endpoint anchors
                        drawCircle(Color.White, radius = 6f, center = p0)
                        drawCircle(Color.White, radius = 6f, center = p3)

                        // Live animated tracer ball along the curve
                        val easedY = KeyframeEvaluator.evaluateBezier(previewProgress, liveCurve)
                        val tracerPos = toScreen(previewProgress, easedY)
                        drawCircle(KeyframeMagenta.copy(alpha = 0.35f), radius = 12f, center = tracerPos)
                        drawCircle(KeyframeMagenta, radius = 6f, center = tracerPos)
                    }
                }
            }
        }

        // Preset Easing Chips
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            CubicBezierCurve.presets.forEach { preset ->
                val isSelected = liveCurve.presetName == preset.presetName && !liveCurve.isStep && !preset.isStep ||
                    (liveCurve.isStep && preset.isStep)
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) ElectricPurple.copy(alpha = 0.25f) else StudioSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) ElectricPurple else StudioBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            liveCurve = preset
                            onUpdateCurve(activeProp, activeSegmentIdx, preset, true)
                        }
                        .testTag("easing_preset_${preset.presetName}")
                ) {
                    Text(
                        text = preset.presetName,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSelected) Color.White else TextSecondary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}
