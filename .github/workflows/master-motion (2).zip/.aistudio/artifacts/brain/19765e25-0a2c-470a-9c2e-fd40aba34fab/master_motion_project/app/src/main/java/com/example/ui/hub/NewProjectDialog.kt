package com.example.ui.hub

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.model.AspectRatioPreset
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, aspectRatio: AspectRatioPreset, fps: Int, durationMs: Long) -> Unit
) {
    var name by remember { mutableStateOf("Studio Motion 01") }
    var selectedRatio by remember { mutableStateOf(AspectRatioPreset.RATIO_16_9) }
    var selectedFps by remember { mutableIntStateOf(30) }
    var selectedDurationMs by remember { mutableLongStateOf(8000L) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = StudioSurface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, StudioBorder, RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "New Composition",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricPurple,
                        unfocusedBorderColor = StudioBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedLabelColor = ElectricPurple
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_name_input")
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Aspect Ratio",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AspectRatioPreset.entries.forEach { preset ->
                            val selected = preset == selectedRatio
                            val borderColor = if (selected) ElectricPurple else StudioBorder
                            val bg = if (selected) ElectricPurple.copy(alpha = 0.2f) else StudioSurfaceElevated
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(bg)
                                    .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
                                    .clickable { selectedRatio = preset }
                                    .testTag("ratio_option_${preset.label}")
                            ) {
                                val boxW = when (preset) {
                                    AspectRatioPreset.RATIO_16_9 -> 24.dp
                                    AspectRatioPreset.RATIO_9_16 -> 12.dp
                                    AspectRatioPreset.RATIO_1_1 -> 18.dp
                                    AspectRatioPreset.RATIO_4_5 -> 15.dp
                                }
                                val boxH = when (preset) {
                                    AspectRatioPreset.RATIO_16_9 -> 14.dp
                                    AspectRatioPreset.RATIO_9_16 -> 22.dp
                                    AspectRatioPreset.RATIO_1_1 -> 18.dp
                                    AspectRatioPreset.RATIO_4_5 -> 19.dp
                                }
                                Box(
                                    modifier = Modifier
                                        .size(width = boxW, height = boxH)
                                        .border(
                                            1.5.dp,
                                            if (selected) Color.White else TextSecondary,
                                            RoundedCornerShape(3.dp)
                                        )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = preset.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) Color.White else TextSecondary
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Frame Rate",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(24, 30, 60).forEach { fps ->
                                val selected = fps == selectedFps
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) CyberBlue.copy(alpha = 0.25f) else StudioSurfaceElevated)
                                        .border(
                                            1.dp,
                                            if (selected) CyberBlue else StudioBorder,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { selectedFps = fps }
                                        .testTag("fps_option_$fps")
                                ) {
                                    Text(
                                        text = "${fps}fps",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (selected) Color.White else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Initial Duration",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(4000L to "4s", 6000L to "6s", 8000L to "8s", 15000L to "15s").forEach { (dur, label) ->
                            val selected = dur == selectedDurationMs
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) ElectricPurple.copy(alpha = 0.22f) else StudioSurfaceElevated)
                                    .border(
                                        1.dp,
                                        if (selected) ElectricPurple else StudioBorder,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { selectedDurationMs = dur }
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) Color.White else TextSecondary
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onCreate(name, selectedRatio, selectedFps, selectedDurationMs) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.horizontalGradient(listOf(ElectricPurple, CyberBlue)))
                            .testTag("confirm_create_project_button")
                    ) {
                        Text(
                            text = "Create Studio",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
