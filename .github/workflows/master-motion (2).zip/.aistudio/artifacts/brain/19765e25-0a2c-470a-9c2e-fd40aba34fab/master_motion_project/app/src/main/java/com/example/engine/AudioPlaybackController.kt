package com.example.engine

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.model.LayerType
import com.example.model.MotionLayer
import java.io.File
import kotlin.math.abs

/**
 * Coordinates Media3 ExoPlayer instances for AUDIO and secondary VIDEO audio tracks,
 * kept tightly synchronized with timeline playheadMs, mute/solo state, and playback speed.
 */
class AudioPlaybackController(private val context: Context) {

    private data class ActivePlayer(
        val layerId: String,
        val mediaPath: String,
        val player: ExoPlayer,
        var lastVolume: Float = -1f,
        var lastSpeed: Float = -1f
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val players = mutableMapOf<String, ActivePlayer>()

    val activePlayerCount: Int
        get() = players.size

    var releasedPlayerCount: Int = 0
        private set

    fun syncPlayback(
        layers: List<MotionLayer>,
        playheadMs: Long,
        isPlaying: Boolean,
        playbackSpeed: Float = 1f,
        excludeVideoLayerId: String? = null,
        masterVolume: Float = 1f
    ) {
        val block = {
            syncPlaybackInternal(layers, playheadMs, isPlaying, playbackSpeed, excludeVideoLayerId, masterVolume)
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    private fun syncPlaybackInternal(
        layers: List<MotionLayer>,
        playheadMs: Long,
        isPlaying: Boolean,
        playbackSpeed: Float,
        excludeVideoLayerId: String?,
        masterVolume: Float
    ) {
        val audioCapable = layers.filter {
            (it.type == LayerType.AUDIO || it.type == LayerType.VIDEO) &&
                it.id != excludeVideoLayerId &&
                !it.mediaPath.isNullOrBlank()
        }
        val anySolo = layers.any {
            (it.type == LayerType.AUDIO || it.type == LayerType.VIDEO) && it.isSolo
        }

        // Release stale players no longer in timeline or handled by primary Media3 video surface
        val validIds = audioCapable.map { it.id }.toSet()
        val toRemove = players.keys.filter { it !in validIds }
        for (id in toRemove) {
            releasePlayerInternal(id)
        }

        val clampedMaster = masterVolume.coerceIn(0f, 1f)
        val clampedSpeed = playbackSpeed.coerceIn(0.25f, 2.5f)

        for (layer in audioCapable) {
            val path = layer.mediaPath ?: continue
            val isMuted = layer.isMuted || (anySolo && !layer.isSolo) || (layer.type != LayerType.AUDIO && !layer.isVisible)
            val isActive = isPlaying && !isMuted && layer.isActiveAt(playheadMs)

            if (!isActive) {
                players[layer.id]?.let { active ->
                    runCatching {
                        if (active.player.isPlaying) active.player.pause()
                    }
                }
                continue
            }

            val file = File(path)
            if (!file.exists()) continue

            val active = ensurePlayerInternal(layer.id, file) ?: continue
            val targetMediaMs = (layer.mediaTrimStartMs + (playheadMs - layer.startTimeMs))
                .coerceAtLeast(0L)
            val nextVol = (layer.volume * clampedMaster).coerceIn(0f, 1f)

            runCatching {
                if (abs(active.lastVolume - nextVol) > 0.005f) {
                    active.player.volume = nextVol
                    active.lastVolume = nextVol
                }
                if (abs(active.lastSpeed - clampedSpeed) > 0.005f) {
                    active.player.playbackParameters = PlaybackParameters(clampedSpeed)
                    active.lastSpeed = clampedSpeed
                }
                val currentPos = active.player.currentPosition
                if (!active.player.isPlaying || active.player.playbackState == Player.STATE_ENDED) {
                    active.player.seekTo(targetMediaMs)
                    active.player.play()
                } else if (abs(currentPos - targetMediaMs) > 240L) {
                    active.player.seekTo(targetMediaMs)
                }
            }
        }
    }

    fun pauseAll() {
        val block = {
            for ((_, active) in players) {
                runCatching {
                    if (active.player.isPlaying) active.player.pause()
                }
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    fun releaseAll() {
        val block = {
            for ((_, active) in players) {
                runCatching {
                    active.player.stop()
                    active.player.release()
                }
                releasedPlayerCount++
            }
            players.clear()
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    private fun ensurePlayerInternal(layerId: String, file: File): ActivePlayer? {
        val existing = players[layerId]
        if (existing != null && existing.mediaPath == file.absolutePath) {
            return existing
        }
        if (existing != null) {
            releasePlayerInternal(layerId)
        }
        return runCatching {
            val exo = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                prepare()
                playWhenReady = false
            }
            ActivePlayer(layerId, file.absolutePath, exo).also { players[layerId] = it }
        }.getOrNull()
    }

    private fun releasePlayerInternal(layerId: String) {
        players.remove(layerId)?.let { active ->
            runCatching {
                active.player.stop()
                active.player.release()
            }
            releasedPlayerCount++
        }
    }
}
