package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0A0B10)
val StudioSurface = Color(0xFF12141E)
val StudioSurfaceElevated = Color(0xFF1A1D2B)
val StudioInspector = Color(0xFF212537)
val StudioBorder = Color(0xFF2D3348)
val StudioBorderBright = Color(0xFF3E4663)

val ElectricPurple = Color(0xFF8B5CF6)
val ElectricPurpleLight = Color(0xFFA78BFA)
val ElectricPurpleDark = Color(0xFF6D28D9)

val CyberBlue = Color(0xFF3B82F6)
val CyberCyan = Color(0xFF38BDF8)
val KeyframeMagenta = Color(0xFFEC4899)

val TextPrimary = Color(0xFFF3F4F8)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val TrackVideoColor = Color(0xFF3B82F6)
val TrackImageColor = Color(0xFF8B5CF6)
val TrackShapeColor = Color(0xFF06B6D4)
val TrackTextColor = Color(0xFFF59E0B)
val TrackAudioColor = Color(0xFF10B981)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorCoral = Color(0xFFEF4444)
