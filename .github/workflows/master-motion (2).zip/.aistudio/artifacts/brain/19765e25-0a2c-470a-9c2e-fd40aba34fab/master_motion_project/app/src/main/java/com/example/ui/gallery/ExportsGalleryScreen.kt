package com.example.ui.gallery

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.compose.PlayerSurface
import androidx.media3.ui.compose.SURFACE_TYPE_TEXTURE_VIEW
import com.example.R
import com.example.data.ExportFileType
import com.example.data.ExportedMediaItem
import com.example.ui.editor.formatTimecode
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackImageColor
import com.example.ui.theme.TrackVideoColor
import com.example.viewmodel.ExportGalleryFilter
import com.example.viewmodel.ExportsGalleryViewModel
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ExportsGalleryScreen(
    viewModel: ExportsGalleryViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var renameTarget by remember { mutableStateOf<ExportedMediaItem?>(null) }
    var deleteTarget by remember { mutableStateOf<ExportedMediaItem?>(null) }

    BackHandler {
        if (state.previewItem != null) {
            viewModel.closePreview()
        } else {
            onNavigateBack()
        }
    }

    LaunchedEffect(state.statusMessage) {
        if (state.statusMessage != null) {
            delay(2200L)
            viewModel.clearStatusMessage()
        }
    }

    val shareItem: (ExportedMediaItem) -> Unit = { item ->
        runCatching {
            val intent = viewModel.buildShareIntent(item)
            context.startActivity(Intent.createChooser(intent, "Share ${item.displayTitle}"))
        }
    }

    Scaffold(
        containerColor = ObsidianBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Top Studio Gallery Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StudioSurface)
                    .border(0.5.dp, StudioBorder)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("exports_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.exports_gallery),
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "${state.items.size} rendered ${if (state.items.size == 1) "file" else "files"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan
                    )
                }

                IconButton(
                    onClick = { viewModel.refreshExports() },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("exports_refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Refresh Exports",
                        tint = CyberCyan
                    )
                }
            }

            // Filter Pills Bar
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StudioSurfaceElevated)
                    .border(0.5.dp, StudioBorder)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                ExportGalleryFilter.entries.forEach { filter ->
                    val selected = filter == state.filter
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (selected) ElectricPurple.copy(alpha = 0.25f) else StudioInspector,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) ElectricPurple else StudioBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { viewModel.setFilter(filter) }
                            .testTag("exports_filter_${filter.name}")
                    ) {
                        Text(
                            text = filter.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) Color.White else TextSecondary,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            AnimatedVisibility(visible = state.statusMessage != null) {
                Surface(
                    color = ElectricPurple.copy(alpha = 0.22f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exports_status_banner")
                ) {
                    Text(
                        text = state.statusMessage.orEmpty(),
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }

            BoxWithConstraints(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                val columns = if (maxWidth >= 840.dp) 3 else 2
                val visibleItems = state.filteredItems

                when {
                    state.isLoading -> {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            CircularProgressIndicator(color = ElectricPurple)
                        }
                    }
                    visibleItems.isEmpty() -> {
                        EmptyExportsPlaceholder(
                            hasAnyItems = state.items.isNotEmpty(),
                            onShowAll = { viewModel.setFilter(ExportGalleryFilter.ALL) }
                        )
                    }
                    else -> {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(columns),
                            contentPadding = PaddingValues(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("exports_grid")
                        ) {
                            items(visibleItems, key = { it.filePath }) { item ->
                                ExportGalleryCard(
                                    item = item,
                                    loadThumbnail = { viewModel.loadThumbnail(item) },
                                    onPlayOrView = { viewModel.openPreview(item) },
                                    onShare = { shareItem(item) },
                                    onRename = { renameTarget = item },
                                    onDelete = { deleteTarget = item }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Media3 ExoPlayer Video / Image Preview Modal
    state.previewItem?.let { active ->
        ExportMediaPlayerDialog(
            item = active,
            loadStillBitmap = { viewModel.loadThumbnail(active) },
            onShare = { shareItem(active) },
            onRename = { renameTarget = active },
            onDelete = { deleteTarget = active },
            onDismiss = { viewModel.closePreview() }
        )
    }

    // Rename Dialog
    renameTarget?.let { target ->
        var editedTitle by remember(target.filePath) { mutableStateOf(target.displayTitle) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            containerColor = StudioSurface,
            title = { Text("Rename Export", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editedTitle,
                        onValueChange = { editedTitle = it },
                        singleLine = true,
                        label = { Text("File Name (.${target.type.name.lowercase(Locale.US)})") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rename_export_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.renameExport(target, editedTitle)
                        renameTarget = null
                    },
                    modifier = Modifier.testTag("confirm_rename_export_button")
                ) {
                    Text("Save", color = ElectricPurple)
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Confirmation Dialog
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            containerColor = StudioSurface,
            title = { Text("Delete Export?", color = TextPrimary) },
            text = {
                Text(
                    text = "Remove \"${target.fileName}\" permanently from Master Motion exports?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteExport(target)
                        deleteTarget = null
                    },
                    modifier = Modifier.testTag("confirm_delete_export_button")
                ) {
                    Text("Delete", color = ErrorCoral)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun ExportGalleryCard(
    item: ExportedMediaItem,
    loadThumbnail: suspend () -> Bitmap?,
    onPlayOrView: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val thumb by produceState<Bitmap?>(initialValue = null, item.filePath, item.lastModifiedMs) {
        value = loadThumbnail()
    }
    val accent = if (item.type == ExportFileType.MP4) TrackVideoColor else TrackImageColor

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = StudioSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onPlayOrView)
            .testTag("export_card_${item.fileName}")
    ) {
        Column {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(StudioInspector)
            ) {
                if (thumb != null && !thumb!!.isRecycled) {
                    Image(
                        bitmap = thumb!!.asImageBitmap(),
                        contentDescription = item.displayTitle,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = if (item.type == ExportFileType.MP4) Icons.Filled.Movie else Icons.Filled.Image,
                        contentDescription = item.displayTitle,
                        tint = accent.copy(alpha = 0.7f),
                        modifier = Modifier.size(34.dp)
                    )
                }

                // Type badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ObsidianBg.copy(alpha = 0.78f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = item.type.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = accent,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (item.type == ExportFileType.MP4) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ObsidianBg.copy(alpha = 0.72f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.7f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = "Play Video",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = item.displayTitle,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("export_menu_${item.fileName}")
                        ) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More Actions", tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                            containerColor = StudioSurfaceElevated
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (item.type == ExportFileType.MP4) "Play Video" else "View Image", color = TextPrimary) },
                                leadingIcon = { Icon(Icons.Filled.PlayArrow, null, tint = CyberCyan) },
                                onClick = {
                                    menuExpanded = false
                                    onPlayOrView()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Share", color = TextPrimary) },
                                leadingIcon = { Icon(Icons.Filled.Share, null, tint = CyberBlue) },
                                onClick = {
                                    menuExpanded = false
                                    onShare()
                                },
                                modifier = Modifier.testTag("export_share_${item.fileName}")
                            )
                            DropdownMenuItem(
                                text = { Text("Rename", color = TextPrimary) },
                                leadingIcon = { Icon(Icons.Filled.DriveFileRenameOutline, null, tint = ElectricPurple) },
                                onClick = {
                                    menuExpanded = false
                                    onRename()
                                },
                                modifier = Modifier.testTag("export_rename_${item.fileName}")
                            )
                            DropdownMenuItem(
                                text = { Text("Delete", color = ErrorCoral) },
                                leadingIcon = { Icon(Icons.Filled.DeleteOutline, null, tint = ErrorCoral) },
                                onClick = {
                                    menuExpanded = false
                                    onDelete()
                                },
                                modifier = Modifier.testTag("export_delete_${item.fileName}")
                            )
                        }
                    }
                }

                val metaLine = buildString {
                    if (item.width > 0 && item.height > 0) {
                        append("${item.width}×${item.height} • ")
                    }
                    if (item.type == ExportFileType.MP4 && item.durationMs > 0L) {
                        append("${formatTimecode(item.durationMs)} • ")
                    }
                    append(formatFileSize(item.fileSizeBytes))
                }
                Text(
                    text = metaLine,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(item.lastModifiedMs)),
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun ExportMediaPlayerDialog(
    item: ExportedMediaItem,
    loadStillBitmap: suspend () -> Bitmap?,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val speedOptions = remember { listOf(0.5f, 1.0f, 1.5f, 2.0f) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = StudioSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("export_player_dialog")
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = item.fileName,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    TextButton(onClick = onDismiss) {
                        Text("Close", color = CyberCyan)
                    }
                }

                if (item.type == ExportFileType.MP4) {
                    val fileExists = remember(item.filePath) { File(item.filePath).exists() }
                    var playerErrorText by remember(item.filePath) {
                        mutableStateOf(if (fileExists) null else "Export file not found on device.")
                    }
                    val exoPlayer = remember(item.filePath, fileExists) {
                        if (!fileExists) null else runCatching {
                            ExoPlayer.Builder(context).build().apply {
                                setMediaItem(MediaItem.fromUri(Uri.fromFile(File(item.filePath))))
                                prepare()
                                playWhenReady = true
                            }
                        }.getOrNull()
                    }

                    var isPlaying by remember(item.filePath) { mutableStateOf(false) }
                    var currentPosMs by remember(item.filePath) { mutableLongStateOf(0L) }
                    var totalDurMs by remember(item.filePath) { mutableLongStateOf(item.durationMs.coerceAtLeast(1000L)) }
                    var speed by remember(item.filePath) { mutableFloatStateOf(1.0f) }

                    DisposableEffect(exoPlayer, item.filePath) {
                        val listener = object : Player.Listener {
                            override fun onIsPlayingChanged(playing: Boolean) {
                                isPlaying = playing
                            }

                            override fun onPlaybackStateChanged(playbackState: Int) {
                                val d = exoPlayer?.duration ?: -1L
                                if (d > 0L) totalDurMs = d
                                if (playbackState == Player.STATE_ENDED) {
                                    isPlaying = false
                                }
                            }

                            override fun onPlayerError(error: PlaybackException) {
                                isPlaying = false
                                playerErrorText = error.message ?: "Unable to decode video playback."
                            }
                        }
                        exoPlayer?.addListener(listener)
                        onDispose {
                            exoPlayer?.removeListener(listener)
                            runCatching {
                                exoPlayer?.stop()
                                exoPlayer?.release()
                            }
                        }
                    }

                    LaunchedEffect(exoPlayer, isPlaying) {
                        while (exoPlayer != null && isPlaying) {
                            currentPosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                            val d = exoPlayer.duration
                            if (d > 0L) totalDurMs = d
                            delay(100L)
                        }
                    }

                    val aspect = if (item.width > 0 && item.height > 0) {
                        (item.width.toFloat() / item.height.toFloat()).coerceIn(0.5f, 2.2f)
                    } else 16f / 9f

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 320.dp)
                            .aspectRatio(aspect, matchHeightConstraintsFirst = aspect < 1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(ObsidianBg)
                            .border(1.dp, StudioBorder, RoundedCornerShape(14.dp))
                    ) {
                        if (exoPlayer != null && playerErrorText == null) {
                            PlayerSurface(
                                player = exoPlayer,
                                surfaceType = SURFACE_TYPE_TEXTURE_VIEW,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("media3_gallery_player_surface")
                            )
                        } else {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Icon(Icons.Filled.Movie, contentDescription = null, tint = ErrorCoral, modifier = Modifier.size(36.dp))
                                Text(
                                    text = playerErrorText ?: "Player unavailable",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Seek Slider & Timecode
                    Column {
                        Slider(
                            value = currentPosMs.toFloat().coerceIn(0f, totalDurMs.toFloat()),
                            onValueChange = { next ->
                                currentPosMs = next.toLong()
                                exoPlayer?.seekTo(currentPosMs)
                            },
                            valueRange = 0f..totalDurMs.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = ElectricPurple,
                                inactiveTrackColor = StudioBorder
                            ),
                            modifier = Modifier.testTag("media3_gallery_seek_slider")
                        )
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${formatTimecode(currentPosMs)} / ${formatTimecode(totalDurMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        exoPlayer?.seekTo(0L)
                                        exoPlayer?.play()
                                        currentPosMs = 0L
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("media3_gallery_replay")
                                ) {
                                    Icon(Icons.Filled.Replay, contentDescription = "Replay", tint = TextPrimary)
                                }

                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(ElectricPurple, CyberBlue)))
                                        .clickable {
                                            if (exoPlayer != null) {
                                                if (exoPlayer.isPlaying) {
                                                    exoPlayer.pause()
                                                } else {
                                                    if (exoPlayer.playbackState == Player.STATE_ENDED) {
                                                        exoPlayer.seekTo(0L)
                                                    }
                                                    exoPlayer.play()
                                                }
                                            }
                                        }
                                        .testTag("media3_gallery_play_pause")
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = Color.White
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StudioSurfaceElevated,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            val idx = speedOptions.indexOfFirst { kotlin.math.abs(it - speed) < 0.05f }
                                            speed = speedOptions[(idx + 1) % speedOptions.size]
                                            exoPlayer?.playbackParameters = PlaybackParameters(speed)
                                        }
                                        .testTag("media3_gallery_speed")
                                ) {
                                    Text(
                                        text = "${String.format(Locale.US, "%.1f", speed).removeSuffix(".0")}x",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberCyan,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                } else {
                    val bitmap by produceState<Bitmap?>(initialValue = null, item.filePath) {
                        value = loadStillBitmap()
                    }
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(ObsidianBg)
                            .border(1.dp, StudioBorder, RoundedCornerShape(14.dp))
                    ) {
                        if (bitmap != null && !bitmap!!.isRecycled) {
                            Image(
                                bitmap = bitmap!!.asImageBitmap(),
                                contentDescription = item.displayTitle,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Filled.Image, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(42.dp))
                        }
                    }
                }

                // Direct Share / Rename / Delete Actions Bar
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onShare,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("player_share_button")
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share", color = TextPrimary)
                    }
                    OutlinedButton(
                        onClick = onRename,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("player_rename_button")
                    ) {
                        Icon(Icons.Filled.DriveFileRenameOutline, contentDescription = null, tint = ElectricPurple, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Rename", color = TextPrimary)
                    }
                    OutlinedButton(
                        onClick = onDelete,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorCoral.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("player_delete_button")
                    ) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = ErrorCoral, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete", color = ErrorCoral)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyExportsPlaceholder(
    hasAnyItems: Boolean,
    onShowAll: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .testTag("exports_empty_state")
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = StudioSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.VideoLibrary,
                    contentDescription = null,
                    tint = ElectricPurple,
                    modifier = Modifier.size(44.dp)
                )
                Text(
                    text = if (hasAnyItems) "No Matching Exports" else stringResource(R.string.no_exports_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Text(
                    text = if (hasAnyItems) "Switch filter to All to see your other exported videos and frames." else stringResource(R.string.no_exports_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                if (hasAnyItems) {
                    TextButton(onClick = onShowAll) {
                        Text("Show All Exports", color = CyberCyan)
                    }
                }
            }
        }
    }
}

private fun formatFileSize(bytes: Long): String {
    return when {
        bytes >= 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> "${bytes / 1024L} KB"
        else -> "$bytes B"
    }
}
