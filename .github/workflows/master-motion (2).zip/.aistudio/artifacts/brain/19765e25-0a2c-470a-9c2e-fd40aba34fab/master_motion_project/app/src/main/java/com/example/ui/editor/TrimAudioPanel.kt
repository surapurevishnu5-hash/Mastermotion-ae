package com.example.ui.editor

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LastPage
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FirstPage
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.MotionProject
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackAudioColor
import com.example.ui.theme.TrackVideoColor
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.VoiceoverRecorderUiState

@Composable
fun TrimAudioPanel(
    project: MotionProject,
    layer: MotionLayer?,
    playheadMs: Long,
    voiceoverState: VoiceoverRecorderUiState = VoiceoverRecorderUiState(),
    onTrimLayer: (layerId: String, startMs: Long, endMs: Long, recordUndo: Boolean) -> Unit,
    onTrimStartToPlayhead: (String) -> Unit,
    onTrimEndToPlayhead: (String) -> Unit,
    onSplitAtPlayhead: (String) -> Unit,
    onSetVolume: (String, Float) -> Unit,
    onToggleMute: (String) -> Unit,
    onToggleSolo: (String) -> Unit = {},
    onSetMasterVolume: (Float) -> Unit = {},
    onSetProjectDuration: (Long) -> Unit,
    onBeginSliderEdit: () -> Unit = {},
    onEndSliderEdit: () -> Unit = {},
    onStartVoiceover: () -> Unit = {},
    onStopVoiceover: () -> Unit = {},
    onCancelVoiceover: () -> Unit = {},
    onVoiceoverPermissionDenied: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scroll = rememberScrollState()

    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onStartVoiceover()
        } else {
            onVoiceoverPermissionDenied()
        }
    }

    val audioTracks = project.layers
        .filter { it.type == LayerType.AUDIO || it.type == LayerType.VIDEO }
        .sortedByDescending { it.zIndex }
    val anyAudioSolo = audioTracks.any { it.isSolo }

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(12.dp)
    ) {
        if (layer != null) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = StudioSurfaceElevated,
                border = BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(12.dp)
                ) {
                    Text(
                        text = "Clip Timing: ${layer.name}",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        TrimActionPill(
                            label = "Trim In",
                            icon = Icons.Filled.FirstPage,
                            accent = CyberBlue,
                            testTag = "trim_start_playhead_button",
                            modifier = Modifier.weight(1f),
                            onClick = { onTrimStartToPlayhead(layer.id) }
                        )
                        TrimActionPill(
                            label = "Split",
                            icon = Icons.Filled.ContentCut,
                            accent = ElectricPurple,
                            testTag = "trim_split_button",
                            modifier = Modifier.weight(1f),
                            onClick = { onSplitAtPlayhead(layer.id) }
                        )
                        TrimActionPill(
                            label = "Trim Out",
                            icon = Icons.AutoMirrored.Filled.LastPage,
                            accent = CyberBlue,
                            testTag = "trim_end_playhead_button",
                            modifier = Modifier.weight(1f),
                            onClick = { onTrimEndToPlayhead(layer.id) }
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Start Time", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Text(formatTimecode(layer.startTimeMs), style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    }
                    Slider(
                        value = layer.startTimeMs.toFloat(),
                        onValueChange = {
                            onBeginSliderEdit()
                            onTrimLayer(layer.id, it.toLong(), layer.endTimeMs, false)
                        },
                        onValueChangeFinished = onEndSliderEdit,
                        valueRange = 0f..(layer.endTimeMs - 250L).coerceAtLeast(100L).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = ElectricPurple),
                        modifier = Modifier.height(26.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("End Time", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                        Text(formatTimecode(layer.endTimeMs), style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    }
                    Slider(
                        value = layer.endTimeMs.toFloat(),
                        onValueChange = {
                            onBeginSliderEdit()
                            onTrimLayer(layer.id, layer.startTimeMs, it.toLong(), false)
                        },
                        onValueChangeFinished = onEndSliderEdit,
                        valueRange = (layer.startTimeMs + 250L).coerceAtMost(project.durationMs).toFloat()..project.durationMs.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = CyberBlue),
                        modifier = Modifier.height(26.dp)
                    )
                }
            }
        }

        // Voiceover Studio Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = StudioSurfaceElevated,
            border = BorderStroke(
                1.dp,
                if (voiceoverState.isRecording) ErrorCoral else StudioBorder
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("voiceover_studio_card")
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = null,
                            tint = if (voiceoverState.isRecording) ErrorCoral else TrackAudioColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Voiceover Studio",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (voiceoverState.isRecording) ErrorCoral.copy(alpha = 0.2f) else StudioInspector,
                        border = BorderStroke(1.dp, if (voiceoverState.isRecording) ErrorCoral else StudioBorder)
                    ) {
                        Text(
                            text = if (voiceoverState.isRecording) {
                                "REC ${formatTimecode(voiceoverState.elapsedMs)}"
                            } else {
                                "At ${formatTimecode(playheadMs)}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (voiceoverState.isRecording) ErrorCoral else CyberCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Live microphone level bar meter during recording
                if (voiceoverState.isRecording) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StudioInspector)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("voiceover_level_meter")
                    ) {
                        val bars = voiceoverState.liveBars.ifEmpty { listOf(0.2f) }
                        val padded = List(24) { idx ->
                            val srcIdx = idx - (24 - bars.size).coerceAtLeast(0)
                            if (srcIdx in bars.indices) bars[srcIdx] else 0.1f
                        }
                        padded.forEach { amp ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(amp.coerceIn(0.12f, 1f))
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (amp > 0.72f) ErrorCoral else TrackAudioColor)
                            )
                        }
                    }
                } else if (voiceoverState.permissionDenied) {
                    Text(
                        text = "Microphone permission denied. Grant audio permission to record voiceovers.",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErrorCoral
                    )
                } else {
                    Text(
                        text = "Record narration directly onto a new audio track starting at the playhead.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (voiceoverState.isRecording) ErrorCoral else TrackAudioColor.copy(alpha = 0.22f),
                        border = BorderStroke(
                            1.dp,
                            if (voiceoverState.isRecording) ErrorCoral else TrackAudioColor
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                if (voiceoverState.isRecording) {
                                    onStopVoiceover()
                                } else {
                                    val hasPerm = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.RECORD_AUDIO
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasPerm) {
                                        onStartVoiceover()
                                    } else {
                                        recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            }
                            .testTag("voiceover_record_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = if (voiceoverState.isRecording) Icons.Filled.Stop else Icons.Filled.Mic,
                                contentDescription = if (voiceoverState.isRecording) "Stop Voiceover" else "Record Voiceover",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (voiceoverState.isRecording) "Stop & Insert Clip" else "Record Voiceover",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (voiceoverState.isRecording) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = StudioInspector,
                            border = BorderStroke(1.dp, StudioBorder),
                            modifier = Modifier
                                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onCancelVoiceover)
                                .testTag("voiceover_cancel_button")
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                                Icon(
                                    Icons.Filled.Close,
                                    contentDescription = "Cancel Recording",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Multi-Track Audio Mixer Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = StudioSurfaceElevated,
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("audio_mixer_card")
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.GraphicEq,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Audio Mixer", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    }
                    Text(
                        text = "${audioTracks.size} track(s)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                // Master Bus Volume Fader
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = StudioInspector,
                    border = BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Master Output Bus",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${(project.masterVolume * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = SuccessGreen
                            )
                        }
                        Slider(
                            value = project.masterVolume,
                            onValueChange = {
                                onBeginSliderEdit()
                                onSetMasterVolume(it)
                            },
                            onValueChangeFinished = onEndSliderEdit,
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = SuccessGreen),
                            modifier = Modifier
                                .height(26.dp)
                                .testTag("mixer_master_volume_slider")
                        )
                    }
                }

                if (audioTracks.isEmpty()) {
                    Text(
                        text = "Import audio/video or record a voiceover to mix track levels, mute, and solo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                } else {
                    audioTracks.forEach { track ->
                        val effectivelyMuted = track.isMuted || (anyAudioSolo && !track.isSolo)
                        val trackColor = if (track.type == LayerType.AUDIO) TrackAudioColor else TrackVideoColor
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (track.id == layer?.id) trackColor.copy(alpha = 0.1f) else StudioInspector,
                            border = BorderStroke(
                                1.dp,
                                if (track.id == layer?.id) trackColor.copy(alpha = 0.7f) else StudioBorder
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(trackColor)
                                    )
                                    Text(
                                        text = track.name,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (effectivelyMuted) TextSecondary else TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = if (effectivelyMuted) "MUTED" else "${(track.volume * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (effectivelyMuted) ErrorCoral else trackColor
                                    )
                                    MixerToggleBadge(
                                        label = "M",
                                        active = track.isMuted,
                                        activeColor = ErrorCoral,
                                        testTag = "mixer_mute_${track.id}",
                                        onClick = { onToggleMute(track.id) }
                                    )
                                    MixerToggleBadge(
                                        label = "S",
                                        active = track.isSolo,
                                        activeColor = WarningAmber,
                                        testTag = "mixer_solo_${track.id}",
                                        onClick = { onToggleSolo(track.id) }
                                    )
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        if (effectivelyMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = null,
                                        tint = if (effectivelyMuted) ErrorCoral else trackColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Slider(
                                        value = track.volume,
                                        onValueChange = {
                                            onBeginSliderEdit()
                                            onSetVolume(track.id, it)
                                        },
                                        onValueChangeFinished = onEndSliderEdit,
                                        enabled = !track.isMuted,
                                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = trackColor),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(26.dp)
                                            .testTag("mixer_track_slider_${track.id}")
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Composition Total Duration
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = StudioSurfaceElevated,
            border = BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Composition Duration", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text(formatTimecode(project.durationMs), style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
                }
                Slider(
                    value = project.durationMs.toFloat(),
                    onValueChange = {
                        onBeginSliderEdit()
                        onSetProjectDuration(it.toLong())
                    },
                    onValueChangeFinished = onEndSliderEdit,
                    valueRange = 2000f..30000f,
                    colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = ElectricPurple),
                    modifier = Modifier.height(26.dp)
                )
            }
        }
    }
}

@Composable
private fun MixerToggleBadge(
    label: String,
    active: Boolean,
    activeColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (active) activeColor.copy(alpha = 0.25f) else StudioSurfaceElevated,
        border = BorderStroke(1.dp, if (active) activeColor else StudioBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) activeColor else TextSecondary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun TrimActionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = accent.copy(alpha = 0.2f),
        border = BorderStroke(1.dp, accent),
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = Color.White)
        }
    }
}
