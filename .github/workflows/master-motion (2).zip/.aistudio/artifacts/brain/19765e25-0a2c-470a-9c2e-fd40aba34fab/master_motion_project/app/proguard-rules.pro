# Add project specific ProGuard rules here.
# Keep Moshi models, Kotlin metadata, Room entities, Hilt injection, and Media3 classes
# safe when R8/ProGuard minification is enabled in release builds.

-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Moshi + Kotlin codegen / reflection
-keep class com.example.model.** { *; }
-keepclassmembers class com.example.model.** { *; }
-keep class com.example.data.Project { *; }
-keepclassmembers class com.example.data.Project { *; }
-keep @com.squareup.moshi.JsonClass class * { *; }
-keepclassmembers @com.squareup.moshi.JsonClass class * {
    <fields>;
    <init>(...);
}
-keepclassmembers class kotlin.Metadata {
    public <methods>;
}

# Room Database & DAOs
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Media3 / ExoPlayer
-dontwarn androidx.media3.**
-keep class androidx.media3.** { *; }

# Keep stack trace line numbers for crash diagnostics
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
