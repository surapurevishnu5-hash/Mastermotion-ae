package com.example.engine

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.model.MotionLayer
import java.io.File
import kotlin.math.abs

/**
 * Dedicated AndroidX Media3 ExoPlayer controller for hardware-accelerated video+audio preview
 * inside the Master Motion editor viewport.
 */
class Media3VideoPreviewController(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var exoPlayer: ExoPlayer? = null
    private var loadedMediaPath: String? = null
    private var lastAppliedVolume: Float = -1f
    private var lastAppliedSpeed: Float = -1f

    var activeLayerId: String? = null
        private set

    var isReleased: Boolean = false
        private set

    val player: Player?
        get() = if (isReleased) null else exoPlayer

    fun ensurePlayer(): ExoPlayer? {
        if (isReleased) return null
        if (exoPlayer == null) {
            exoPlayer = runCatching {
                ExoPlayer.Builder(context).build()
            }.getOrNull()
            lastAppliedVolume = -1f
            lastAppliedSpeed = -1f
        }
        return exoPlayer
    }

    fun syncVideoPreview(
        activeVideoLayer: MotionLayer?,
        playheadMs: Long,
        isPlaying: Boolean,
        anySolo: Boolean,
        playbackSpeed: Float = 1f,
        masterVolume: Float = 1f
    ) {
        val block = {
            syncVideoPreviewInternal(activeVideoLayer, playheadMs, isPlaying, anySolo, playbackSpeed, masterVolume)
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    private fun syncVideoPreviewInternal(
        activeVideoLayer: MotionLayer?,
        playheadMs: Long,
        isPlaying: Boolean,
        anySolo: Boolean,
        playbackSpeed: Float,
        masterVolume: Float
    ) {
        if (isReleased) return

        val path = activeVideoLayer?.mediaPath
        val file = path?.let(::File)?.takeIf { it.exists() }

        if (activeVideoLayer == null || file == null || !activeVideoLayer.isActiveAt(playheadMs)) {
            activeLayerId = null
            exoPlayer?.let { p ->
                runCatching {
                    if (p.isPlaying) p.pause()
                }
            }
            return
        }

        val p = ensurePlayer() ?: return
        activeLayerId = activeVideoLayer.id

        if (loadedMediaPath != file.absolutePath) {
            loadedMediaPath = file.absolutePath
            lastAppliedVolume = -1f
            lastAppliedSpeed = -1f
            runCatching {
                p.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                p.prepare()
            }
        }

        val isMuted = activeVideoLayer.isMuted || (anySolo && !activeVideoLayer.isSolo) || !activeVideoLayer.isVisible
        val targetMediaMs = (activeVideoLayer.mediaTrimStartMs + (playheadMs - activeVideoLayer.startTimeMs))
            .coerceAtLeast(0L)
        val nextVolume = if (isMuted) 0f else (activeVideoLayer.volume * masterVolume.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        val nextSpeed = playbackSpeed.coerceIn(0.25f, 2.5f)

        runCatching {
            if (abs(lastAppliedVolume - nextVolume) > 0.005f) {
                p.volume = nextVolume
                lastAppliedVolume = nextVolume
            }
            if (abs(lastAppliedSpeed - nextSpeed) > 0.005f) {
                p.playbackParameters = PlaybackParameters(nextSpeed)
                lastAppliedSpeed = nextSpeed
            }

            if (isPlaying) {
                if (p.playbackState == Player.STATE_ENDED || abs(p.currentPosition - targetMediaMs) > 260L) {
                    p.seekTo(targetMediaMs)
                }
                if (!p.isPlaying) {
                    p.play()
                }
            } else {
                if (p.isPlaying) {
                    p.pause()
                }
                if (abs(p.currentPosition - targetMediaMs) > 120L) {
                    p.seekTo(targetMediaMs)
                }
            }
        }
    }

    fun seekTo(mediaPosMs: Long) {
        val block = {
            runCatching {
                exoPlayer?.seekTo(mediaPosMs.coerceAtLeast(0L))
            }
            Unit
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    fun pause() {
        val block = {
            runCatching {
                exoPlayer?.pause()
            }
            Unit
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }

    fun release() {
        val block = {
            if (!isReleased) {
                isReleased = true
                runCatching {
                    exoPlayer?.stop()
                    exoPlayer?.release()
                }
                exoPlayer = null
                loadedMediaPath = null
                activeLayerId = null
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
