package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.media3.ui.compose.PlayerSurface
import androidx.media3.ui.compose.SURFACE_TYPE_TEXTURE_VIEW
import com.example.engine.CompositionRenderer
import com.example.engine.KeyframeEvaluator
import com.example.engine.Media3VideoPreviewController
import com.example.engine.MediaManager
import com.example.model.EffectType
import com.example.model.LayerType
import com.example.model.MotionProject
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.KeyframeMagenta
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File
import java.util.Locale

private val playbackSpeedSteps = listOf(0.5f, 1.0f, 1.5f, 2.0f)

@Composable
fun PreviewStage(
    project: MotionProject,
    mediaManager: MediaManager,
    selectedLayerId: String?,
    playheadMs: Long,
    isPlaying: Boolean,
    playbackSpeed: Float = 1.0f,
    showGuides: Boolean,
    autoKeyframe: Boolean,
    videoPreviewController: Media3VideoPreviewController? = null,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onStepFrame: (Int) -> Unit,
    onChangePlaybackSpeed: (Float) -> Unit = {},
    onToggleGuides: () -> Unit,
    onToggleAutoKeyframe: () -> Unit,
    onCanvasTransform: (deltaXNorm: Float, deltaYNorm: Float, zoom: Float, rotationDeg: Float) -> Unit,
    onCanvasTransformStart: () -> Unit = {},
    onCanvasTransformEnd: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val frameRevision by mediaManager.previewFrameRevision.collectAsStateWithLifecycle()

    // Check file existence only when layers change rather than 60x/sec during playback
    val existingVideoLayers = remember(project.layers) {
        val anySolo = project.layers.any { it.type != LayerType.AUDIO && it.isSolo }
        project.layers
            .filter {
                it.type == LayerType.VIDEO &&
                    !it.mediaPath.isNullOrBlank() &&
                    File(it.mediaPath).exists() &&
                    it.isVisible &&
                    (!anySolo || it.isSolo)
            }
            .sortedByDescending { it.zIndex }
    }
    val activeVideoLayer = remember(existingVideoLayers, playheadMs) {
        existingVideoLayers.firstOrNull { it.isActiveAt(playheadMs) }
    }
    val exoPlayer = videoPreviewController?.player
    val hasActiveChromaKey = activeVideoLayer?.effects?.any {
        it.enabled && it.type == EffectType.CHROMA_KEY
    } == true
    val useMedia3VideoSurface = isPlaying && activeVideoLayer != null && exoPlayer != null && !hasActiveChromaKey

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(ObsidianBg)
    ) {
        // Aspect-ratio-accurate Composition Viewport
        BoxWithConstraints(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            val aspect = project.aspectRatio.ratio
            val containerRatio = if (maxHeight > 0.dp) maxWidth / maxHeight else 16f / 9f
            val stageModifier = if (aspect > containerRatio) {
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspect)
            } else {
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(aspect)
            }

            Box(
                modifier = stageModifier
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, StudioBorder, RoundedCornerShape(10.dp))
                    .pointerInput(selectedLayerId) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            var started = false
                            try {
                                do {
                                    val event = awaitPointerEvent()
                                    val canceled = event.changes.any { it.isConsumed }
                                    if (!canceled && selectedLayerId != null) {
                                        val zoomChange = event.calculateZoom()
                                        val rotationChange = event.calculateRotation()
                                        val panChange = event.calculatePan()
                                        if (zoomChange != 1f || rotationChange != 0f || panChange != androidx.compose.ui.geometry.Offset.Zero) {
                                            if (!started) {
                                                started = true
                                                onCanvasTransformStart()
                                            }
                                            val dxNorm = (panChange.x / (size.width / 2f)).coerceIn(-0.25f, 0.25f)
                                            val dyNorm = (panChange.y / (size.height / 2f)).coerceIn(-0.25f, 0.25f)
                                            onCanvasTransform(dxNorm, dyNorm, zoomChange, rotationChange)
                                            event.changes.forEach { it.consume() }
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                            } finally {
                                if (started) onCanvasTransformEnd()
                            }
                        }
                    }
                    .testTag("preview_canvas")
            ) {
                if (useMedia3VideoSurface && activeVideoLayer != null && exoPlayer != null) {
                    val videoEval = KeyframeEvaluator.evaluateLayerState(activeVideoLayer, playheadMs)

                    // 1. Background + lower zIndex layers
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        @Suppress("UNUSED_EXPRESSION")
                        frameRevision
                        drawIntoCanvas { canvas ->
                            CompositionRenderer.renderToCanvas(
                                canvas = canvas.nativeCanvas,
                                project = project,
                                timeMs = playheadMs,
                                width = size.width.toInt().coerceAtLeast(2),
                                height = size.height.toInt().coerceAtLeast(2),
                                mediaManager = mediaManager,
                                selectedLayerId = selectedLayerId,
                                showGuides = showGuides,
                                exactVideoFrames = false,
                                drawBackground = true,
                                layerPredicate = { it.zIndex < activeVideoLayer.zIndex }
                            )
                        }
                    }

                    // 2. Live Media3 ExoPlayer Video Surface with keyframed 2D/3D transform
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val stageW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                        val stageH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
                        PlayerSurface(
                            player = exoPlayer,
                            surfaceType = SURFACE_TYPE_TEXTURE_VIEW,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    translationX = videoEval.transform.posX * (stageW / 2f)
                                    translationY = videoEval.transform.posY * (stageH / 2f)
                                    scaleX = videoEval.transform.scaleX
                                    scaleY = videoEval.transform.scaleY
                                    rotationZ = videoEval.transform.rotationZ
                                    rotationX = videoEval.transform.rotationX
                                    rotationY = videoEval.transform.rotationY
                                    alpha = videoEval.transform.opacity.coerceIn(0f, 1f)
                                    cameraDistance = videoEval.transform.cameraDistance * density
                                }
                                .testTag("media3_player_surface")
                        )
                    }

                    // 3. Overlay layers above active video zIndex
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        @Suppress("UNUSED_EXPRESSION")
                        frameRevision
                        drawIntoCanvas { canvas ->
                            CompositionRenderer.renderToCanvas(
                                canvas = canvas.nativeCanvas,
                                project = project,
                                timeMs = playheadMs,
                                width = size.width.toInt().coerceAtLeast(2),
                                height = size.height.toInt().coerceAtLeast(2),
                                mediaManager = mediaManager,
                                selectedLayerId = selectedLayerId,
                                showGuides = showGuides,
                                exactVideoFrames = false,
                                drawBackground = false,
                                layerPredicate = { it.zIndex > activeVideoLayer.zIndex }
                            )
                        }
                    }
                } else {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        @Suppress("UNUSED_EXPRESSION")
                        frameRevision
                        drawIntoCanvas { canvas ->
                            CompositionRenderer.renderToCanvas(
                                canvas = canvas.nativeCanvas,
                                project = project,
                                timeMs = playheadMs,
                                width = size.width.toInt().coerceAtLeast(2),
                                height = size.height.toInt().coerceAtLeast(2),
                                mediaManager = mediaManager,
                                selectedLayerId = selectedLayerId,
                                showGuides = showGuides,
                                exactVideoFrames = false
                            )
                        }
                    }
                }

                // Aspect Ratio, FPS & Media3 badge overlay
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ObsidianBg.copy(alpha = 0.72f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = buildString {
                            append("${project.aspectRatio.label} • ${project.fps}fps")
                            if (activeVideoLayer != null) {
                                append(" • Media3")
                            }
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // Transport Control Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurface)
                .border(0.5.dp, StudioBorder)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            // Timecode readout
            Column {
                Text(
                    text = "${formatTimecode(playheadMs)} / ${formatTimecode(project.durationMs)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextPrimary,
                    modifier = Modifier.testTag("timecode_text")
                )
            }

            // Playback controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = { onSeekTo(0L) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("jump_start_button")
                ) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Jump to Start", tint = TextSecondary, modifier = Modifier.size(20.dp))
                }
                IconButton(
                    onClick = { onStepFrame(-1) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("step_back_button")
                ) {
                    Icon(Icons.Filled.FastRewind, contentDescription = "Previous Frame", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(ElectricPurple, CyberBlue)))
                        .clickable(onClick = onTogglePlayPause)
                        .testTag("play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                IconButton(
                    onClick = { onStepFrame(1) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("step_forward_button")
                ) {
                    Icon(Icons.Filled.FastForward, contentDescription = "Next Frame", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = { onSeekTo(project.durationMs) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("jump_end_button")
                ) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Jump to End", tint = TextSecondary, modifier = Modifier.size(20.dp))
                }
            }

            // Playback speed, Auto-keyframe & Studio grid
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StudioSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            val idx = playbackSpeedSteps.indexOfFirst { kotlin.math.abs(it - playbackSpeed) < 0.05f }
                            val next = playbackSpeedSteps[(idx + 1) % playbackSpeedSteps.size]
                            onChangePlaybackSpeed(next)
                        }
                        .testTag("playback_speed_button")
                ) {
                    Text(
                        text = "${String.format(Locale.US, "%.1f", playbackSpeed).removeSuffix(".0")}x",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (autoKeyframe) KeyframeMagenta.copy(alpha = 0.22f) else StudioSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (autoKeyframe) KeyframeMagenta else StudioBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onToggleAutoKeyframe)
                        .testTag("auto_keyframe_toggle")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Diamond,
                            contentDescription = "Auto Keyframe",
                            tint = if (autoKeyframe) KeyframeMagenta else TextSecondary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "KEY",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (autoKeyframe) Color.White else TextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onToggleGuides,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("guides_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.GridOn,
                        contentDescription = "Toggle Guides",
                        tint = if (showGuides) CyberCyan else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

fun formatTimecode(ms: Long): String {
    val clamped = ms.coerceAtLeast(0L)
    val totalSec = clamped / 1000L
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    val centis = (clamped % 1000L) / 10L
    return String.format(Locale.US, "%02d:%02d.%02d", mins, secs, centis)
}
