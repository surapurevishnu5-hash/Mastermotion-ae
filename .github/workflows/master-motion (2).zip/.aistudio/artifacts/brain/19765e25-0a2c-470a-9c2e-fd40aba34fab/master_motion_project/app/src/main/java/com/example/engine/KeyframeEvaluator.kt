package com.example.engine

import com.example.model.AnimatableProperty
import com.example.model.CubicBezierCurve
import com.example.model.Keyframe
import com.example.model.MotionLayer
import com.example.model.TransformValues
import com.example.model.TransitionType
import kotlin.math.abs

data class EvaluatedLayerState(
    val transform: TransformValues,
    val wipeProgress: Float = 1f,
    val isActive: Boolean = true
)

object KeyframeEvaluator {

    /**
     * Evaluates a single AnimatableProperty for [layer] at [timeMs].
     */
    fun evaluateProperty(
        layer: MotionLayer,
        property: AnimatableProperty,
        timeMs: Long
    ): Float {
        val keyframes = layer.keyframesFor(property)
        if (keyframes.isEmpty()) {
            return layer.baseTransform.getProperty(property)
        }
        if (timeMs <= keyframes.first().timeMs) {
            return keyframes.first().value
        }
        if (timeMs >= keyframes.last().timeMs) {
            return keyframes.last().value
        }

        for (i in 0 until keyframes.size - 1) {
            val k0 = keyframes[i]
            val k1 = keyframes[i + 1]
            if (timeMs >= k0.timeMs && timeMs <= k1.timeMs) {
                val span = (k1.timeMs - k0.timeMs).coerceAtLeast(1L)
                val rawProgress = ((timeMs - k0.timeMs).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                val eased = evaluateBezier(rawProgress, k0.curve)
                return k0.value + (k1.value - k0.value) * eased
            }
        }
        return keyframes.last().value
    }

    /**
     * Evaluates full 2D & 3D TransformValues plus In/Out transitions for [layer] at [timeMs].
     */
    fun evaluateLayerState(layer: MotionLayer, timeMs: Long): EvaluatedLayerState {
        if (!layer.isActiveAt(timeMs) || !layer.isVisible) {
            return EvaluatedLayerState(layer.baseTransform, wipeProgress = 0f, isActive = false)
        }

        var posX = evaluateProperty(layer, AnimatableProperty.POSITION_X, timeMs)
        var posY = evaluateProperty(layer, AnimatableProperty.POSITION_Y, timeMs)
        var scaleX = evaluateProperty(layer, AnimatableProperty.SCALE_X, timeMs)
        var scaleY = evaluateProperty(layer, AnimatableProperty.SCALE_Y, timeMs)
        var rotZ = evaluateProperty(layer, AnimatableProperty.ROTATION_Z, timeMs)
        var rotX = evaluateProperty(layer, AnimatableProperty.ROTATION_X, timeMs)
        var rotY = evaluateProperty(layer, AnimatableProperty.ROTATION_Y, timeMs)
        val depthZ = evaluateProperty(layer, AnimatableProperty.DEPTH_Z, timeMs)
        var opacity = evaluateProperty(layer, AnimatableProperty.OPACITY, timeMs).coerceIn(0f, 1f)
        var wipeProgress = 1f

        val clipLen = (layer.endTimeMs - layer.startTimeMs).coerceAtLeast(1L)

        // Apply In Transition
        if (layer.inTransition.type != TransitionType.NONE && layer.inTransition.durationMs > 0L) {
            val inDur = layer.inTransition.durationMs.coerceAtMost(clipLen)
            val elapsed = timeMs - layer.startTimeMs
            if (elapsed < inDur) {
                val p = (elapsed.toFloat() / inDur.toFloat()).coerceIn(0f, 1f)
                val eased = evaluateBezier(p, CubicBezierCurve.EASE_OUT)
                val inv = 1f - eased
                when (layer.inTransition.type) {
                    TransitionType.FADE -> opacity *= eased
                    TransitionType.SLIDE_LEFT -> posX += inv * 1.4f
                    TransitionType.SLIDE_RIGHT -> posX -= inv * 1.4f
                    TransitionType.SLIDE_UP -> posY += inv * 1.4f
                    TransitionType.ZOOM_POP -> {
                        val pop = evaluateBezier(p, CubicBezierCurve.OVERSHOOT)
                        scaleX *= pop.coerceAtLeast(0.01f)
                        scaleY *= pop.coerceAtLeast(0.01f)
                        opacity *= eased
                    }
                    TransitionType.FLIP_3D -> {
                        rotY += inv * 90f
                        opacity *= (p * 1.5f).coerceIn(0f, 1f)
                    }
                    TransitionType.WIPE_HORIZONTAL -> wipeProgress = eased
                    TransitionType.NONE -> {}
                }
            }
        }

        // Apply Out Transition
        if (layer.outTransition.type != TransitionType.NONE && layer.outTransition.durationMs > 0L) {
            val outDur = layer.outTransition.durationMs.coerceAtMost(clipLen)
            val remaining = layer.endTimeMs - timeMs
            if (remaining < outDur) {
                val p = (1f - (remaining.toFloat() / outDur.toFloat())).coerceIn(0f, 1f)
                val eased = evaluateBezier(p, CubicBezierCurve.EASE_IN)
                when (layer.outTransition.type) {
                    TransitionType.FADE -> opacity *= (1f - eased)
                    TransitionType.SLIDE_LEFT -> posX -= eased * 1.4f
                    TransitionType.SLIDE_RIGHT -> posX += eased * 1.4f
                    TransitionType.SLIDE_UP -> posY -= eased * 1.4f
                    TransitionType.ZOOM_POP -> {
                        val s = (1f - eased * 0.9f).coerceAtLeast(0.01f)
                        scaleX *= s
                        scaleY *= s
                        opacity *= (1f - eased)
                    }
                    TransitionType.FLIP_3D -> {
                        rotY -= eased * 90f
                        opacity *= (1f - eased)
                    }
                    TransitionType.WIPE_HORIZONTAL -> wipeProgress = (1f - eased).coerceAtLeast(0f)
                    TransitionType.NONE -> {}
                }
            }
        }

        return EvaluatedLayerState(
            transform = TransformValues(
                posX = posX,
                posY = posY,
                scaleX = scaleX,
                scaleY = scaleY,
                rotationZ = rotZ,
                rotationX = rotX,
                rotationY = rotY,
                depthZ = depthZ,
                opacity = opacity.coerceIn(0f, 1f),
                cameraDistance = layer.baseTransform.cameraDistance
            ),
            wipeProgress = wipeProgress.coerceIn(0f, 1f),
            isActive = true
        )
    }

    /**
     * Solves cubic-bezier(x1, y1, x2, y2) for a normalized time progress x in [0, 1].
     * Uses Newton-Raphson iteration with bisection fallback for accuracy even on overshoot curves.
     */
    fun evaluateBezier(x: Float, curve: CubicBezierCurve): Float {
        if (curve.isStep) {
            return if (x >= 1f) 1f else 0f
        }
        val clampedX = x.coerceIn(0f, 1f)
        if (clampedX <= 0f) return 0f
        if (clampedX >= 1f) return 1f
        if (abs(curve.x1 - curve.y1) < 1e-4f && abs(curve.x2 - curve.y2) < 1e-4f) {
            return clampedX
        }

        var t = clampedX
        // Newton-Raphson iterations
        for (i in 0 until 8) {
            val xEstimate = sampleBezierCoordinate(t, curve.x1, curve.x2) - clampedX
            if (abs(xEstimate) < 1e-5f) {
                return sampleBezierCoordinate(t, curve.y1, curve.y2)
            }
            val dEstimate = sampleBezierDerivative(t, curve.x1, curve.x2)
            if (abs(dEstimate) < 1e-6f) break
            t = (t - xEstimate / dEstimate).coerceIn(0f, 1f)
        }

        // Bisection fallback for steep slopes
        var lo = 0f
        var hi = 1f
        t = clampedX
        for (i in 0 until 16) {
            val xVal = sampleBezierCoordinate(t, curve.x1, curve.x2)
            if (abs(xVal - clampedX) < 1e-5f) break
            if (clampedX > xVal) lo = t else hi = t
            t = (lo + hi) * 0.5f
        }
        return sampleBezierCoordinate(t, curve.y1, curve.y2)
    }

    fun sampleBezierCoordinate(t: Float, p1: Float, p2: Float): Float {
        val inv = 1f - t
        return 3f * inv * inv * t * p1 + 3f * inv * t * t * p2 + t * t * t
    }

    private fun sampleBezierDerivative(t: Float, p1: Float, p2: Float): Float {
        val inv = 1f - t
        return 3f * inv * inv * p1 + 6f * inv * t * (p2 - p1) + 3f * t * t * (1f - p2)
    }

    /**
     * Inserts or updates a keyframe at [timeMs] (within [toleranceMs] snaps to existing keyframe).
     */
    fun upsertKeyframe(
        existing: List<Keyframe>,
        timeMs: Long,
        value: Float,
        curve: CubicBezierCurve = CubicBezierCurve.EASE_IN_OUT,
        toleranceMs: Long = 40L
    ): List<Keyframe> {
        val sorted = existing.sortedBy { it.timeMs }.toMutableList()
        val matchIdx = sorted.indexOfFirst { abs(it.timeMs - timeMs) <= toleranceMs }
        if (matchIdx >= 0) {
            val prev = sorted[matchIdx]
            sorted[matchIdx] = prev.copy(value = value)
        } else {
            sorted.add(Keyframe(timeMs = timeMs, value = value, curve = curve))
        }
        return sorted.sortedBy { it.timeMs }
    }

    fun hasKeyframeNear(existing: List<Keyframe>, timeMs: Long, toleranceMs: Long = 40L): Boolean =
        existing.any { abs(it.timeMs - timeMs) <= toleranceMs }
}
