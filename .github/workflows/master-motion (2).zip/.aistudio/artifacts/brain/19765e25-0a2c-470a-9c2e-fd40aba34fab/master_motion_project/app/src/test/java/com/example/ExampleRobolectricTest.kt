package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextReplacement
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ProjectDao
import com.example.data.ProjectRepository
import com.example.data.SampleProjectFactory
import com.example.engine.CompositionRenderer
import com.example.engine.ExportConfig
import com.example.engine.MediaExporter
import com.example.engine.MediaManager
import com.example.model.AspectRatioPreset
import com.example.model.ExportFormat
import com.example.model.ExportResolution
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.HiltTestApplication
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import javax.inject.Inject

@HiltAndroidTest
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], application = HiltTestApplication::class)
class ExampleRobolectricTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Inject
    lateinit var injectedDatabase: AppDatabase

    @Inject
    lateinit var injectedProjectDao: ProjectDao

    @Inject
    lateinit var injectedRepository: ProjectRepository

    @Inject
    lateinit var injectedExportsRepository: com.example.data.ExportsRepository

    @Before
    fun setUpHilt() {
        hiltRule.inject()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Master Motion", appName)
    }

    @Test
    fun `composition renderer produces 1080p frame with 3D layers and effects`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val mediaManager = MediaManager(context)
        val project = SampleProjectFactory.createShowcaseProject()
        val bitmap = CompositionRenderer.renderToBitmap(
            project = project,
            timeMs = 1500L,
            width = 1920,
            height = 1080,
            mediaManager = mediaManager,
            selectedLayerId = project.layers.first().id,
            showGuides = false
        )
        assertEquals(1920, bitmap.width)
        assertEquals(1080, bitmap.height)
        assertEquals(Bitmap.Config.ARGB_8888, bitmap.config)
        bitmap.recycle()
    }

    @Test
    fun `room repository saves and reopens project`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val created = repo.createBlankProject("Robolectric Test", AspectRatioPreset.RATIO_9_16, 60, 5000L)
            val localFiles = repo.listLocalProjectFiles()
            assertTrue("Expected .mmproj file in local directory", localFiles.any { it.name == "${created.id}.mmproj" })
            val reopened = repo.loadProject(created.id)
            assertNotNull(reopened)
            assertEquals("Robolectric Test", reopened!!.name)
            assertEquals(AspectRatioPreset.RATIO_9_16, reopened.aspectRatio)
            assertEquals(60, reopened.fps)
        } finally {
            db.close()
        }
    }

    @Test
    fun `repository scans local mmproj files into room database`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val externalProject = SampleProjectFactory.createShowcaseProject().copy(
                id = "local-scan-test-id",
                name = "Scanned Local Project"
            )
            val file = File(repo.localProjectsDir(), "${externalProject.id}.mmproj")
            file.writeText(com.example.data.ProjectSerializer.toJson(externalProject))

            val syncedCount = repo.scanLocalProjectsIntoDatabase()
            assertTrue("Expected at least 1 local .mmproj file synced", syncedCount >= 1)
            val entity = db.projectDao().getProjectById(externalProject.id)
            assertNotNull("Expected scanned project to be indexed in Room", entity)
            assertEquals("Scanned Local Project", entity!!.name)
        } finally {
            db.close()
        }
    }

    @Test
    fun `png export creates 4K output file`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val mediaManager = MediaManager(context)
        val exporter = MediaExporter(context, mediaManager)
        val project = SampleProjectFactory.createShowcaseProject()

        val result = exporter.export(
            project = project,
            playheadMs = 1200L,
            config = ExportConfig(
                format = ExportFormat.PNG_IMAGE,
                resolution = ExportResolution.UHD_4K
            ),
            onProgress = {}
        )
        val file = File(result.filePath)
        assertTrue("Expected exported PNG file to exist", file.exists())
        assertTrue("Expected non-empty PNG file", file.length() > 1000L)
        assertEquals(3840, result.width)
        assertEquals(2160, result.height)
    }

    @Test
    fun `hub loads sample motion project into editor and exercises tools and export dialog`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithText("MASTER MOTION").assertIsDisplayed()
        composeRule.onNodeWithTag("new_project_fab").assertIsDisplayed()
        composeRule.onNodeWithTag("projects_grid").assertIsDisplayed()
        composeRule.onNodeWithTag("load_sample_button").performClick()

        // Wait for background IO project creation + Room load to finish
        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("preview_canvas").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()

        // Verify Editor Screen opened with preview canvas, transport, and export button
        composeRule.onNodeWithTag("preview_canvas").assertIsDisplayed()
        composeRule.onNodeWithTag("play_pause_button").assertIsDisplayed()
        composeRule.onNodeWithTag("export_button").assertIsDisplayed()

        // Step forward frame & verify timecode updates
        composeRule.onNodeWithTag("step_forward_button").performClick()
        composeRule.waitForIdle()

        // Switch through Transform (2D & 3D), Graph Editor, Effects, and Trim tabs
        composeRule.onNodeWithTag("inspector_tab_TRANSFORM").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("transform_3d_tab").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("kf_toggle_ROTATION_Y").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("inspector_tab_GRAPH").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("graph_bezier_canvas").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("inspector_tab_EFFECTS").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("add_effect_VIGNETTE").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("inspector_tab_TRIM").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("trim_split_button").performScrollTo().assertIsDisplayed()

        // Open Export Dialog and verify 1080p / 4K and MP4 / PNG options
        composeRule.onNodeWithTag("export_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("export_format_MP4_VIDEO").assertIsDisplayed()
        composeRule.onNodeWithTag("export_format_PNG_IMAGE").assertIsDisplayed()
        composeRule.onNodeWithTag("export_res_FHD_1080P").assertIsDisplayed()
        composeRule.onNodeWithTag("export_res_UHD_4K").performClick()
        composeRule.waitForIdle()
        composeRule.onAllNodesWithText("3840×2160").onFirst().assertIsDisplayed()
    }

    @Test
    fun `editor viewmodel supports reorder undo redo split and filter rendering`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val exporter = MediaExporter(context, mediaManager)
            val sample = repo.createSampleMotionProject()
            val vm = com.example.viewmodel.EditorViewModel(sample.id, repo, mediaManager, exporter)

            // Wait for async init loadProject() on viewModelScope (MainLooper)
            var attempts = 0
            while (vm.uiState.value.isLoading && attempts < 60) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }
            val initialLayers = vm.uiState.value.project.layers.sortedByDescending { it.zIndex }
            assertTrue(initialLayers.size >= 4)

            val topLayerId = initialLayers.first().id
            vm.reorderLayerToVisualIndex(topLayerId, 2)
            val reordered = vm.uiState.value.project.layers.sortedByDescending { it.zIndex }
            assertEquals(topLayerId, reordered[2].id)

            // Undo restores previous order; Redo reapplies
            vm.undo()
            val afterUndo = vm.uiState.value.project.layers.sortedByDescending { it.zIndex }
            assertEquals(topLayerId, afterUndo[0].id)
            vm.redo()
            val afterRedo = vm.uiState.value.project.layers.sortedByDescending { it.zIndex }
            assertEquals(topLayerId, afterRedo[2].id)

            // Split selected layer at 2000ms
            vm.selectLayer(topLayerId)
            vm.seekTo(2000L)
            val countBeforeSplit = vm.uiState.value.project.layers.size
            vm.splitLayerAtPlayhead(topLayerId)
            assertEquals(countBeforeSplit + 1, vm.uiState.value.project.layers.size)

            // Apply Noir & Sepia filter and verify renderToBitmap succeeds
            vm.addEffect(com.example.model.EffectType.MONO_NOIR)
            vm.addEffect(com.example.model.EffectType.SEPIA)
            val bmp = CompositionRenderer.renderToBitmap(
                project = vm.uiState.value.project,
                timeMs = 2000L,
                width = 640,
                height = 360,
                mediaManager = mediaManager
            )
            assertEquals(640, bmp.width)
            bmp.recycle()
        } finally {
            db.close()
        }
    }

    @Test
    fun `new project fab opens dialog and creates project in editor`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("new_project_fab").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("new_project_name_input").assertIsDisplayed()
        composeRule.onNodeWithTag("ratio_option_9:16").performClick()
        composeRule.onNodeWithTag("fps_option_60").performScrollTo().performClick()
        composeRule.onNodeWithTag("confirm_create_project_button").performScrollTo().performClick()

        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("preview_canvas").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("preview_canvas").assertIsDisplayed()
    }

    @Test
    fun `project dao persists retrieves and deletes project metadata`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.projectDao()
            val entity = com.example.data.Project(
                id = "dao-meta-1",
                name = "Neon Intro",
                aspectRatioLabel = "16:9",
                resolutionWidth = 1920,
                resolutionHeight = 1080,
                resolution = "1920×1080",
                frameRate = 60,
                durationMs = 12000L,
                layerCount = 5,
                thumbnailPath = null,
                projectJson = com.example.data.ProjectSerializer.toJson(
                    SampleProjectFactory.createShowcaseProject().copy(id = "dao-meta-1", name = "Neon Intro")
                ),
                lastModified = 1_700_000_000_000L
            )
            dao.upsertProject(entity)

            val loaded: com.example.data.Project? = dao.getProjectById("dao-meta-1")
            assertNotNull(loaded)
            assertEquals("Neon Intro", loaded!!.name)
            assertEquals("16:9", loaded.aspectRatioLabel)
            assertEquals(1920, loaded.resolutionWidth)
            assertEquals(1080, loaded.resolutionHeight)
            assertEquals("1920×1080", loaded.resolution)
            assertEquals(60, loaded.frameRate)
            assertEquals(12000L, loaded.durationMs)
            assertEquals(5, loaded.layerCount)
            assertEquals(1_700_000_000_000L, loaded.lastModified)

            dao.updateProjectMetadata("dao-meta-1", "Neon Intro v2", 1_700_000_005_000L)
            val updated = dao.getProjectById("dao-meta-1")
            assertEquals("Neon Intro v2", updated!!.name)
            assertEquals(1_700_000_005_000L, updated.lastModified)

            val allFlowList = dao.observeAllProjects().first()
            assertEquals(1, allFlowList.size)
            assertEquals("dao-meta-1", allFlowList.first().id)

            dao.deleteProjectById("dao-meta-1")
            val afterDelete = dao.getProjectById("dao-meta-1")
            assertEquals(null, afterDelete)
        } finally {
            db.close()
        }
    }

    @Test
    fun `hilt database module injects singleton AppDatabase and ProjectDao`() {
        assertTrue(::injectedDatabase.isInitialized)
        assertTrue(::injectedProjectDao.isInitialized)
        assertNotNull(injectedDatabase.projectDao())
    }

    @Test
    fun `hub fetches existing room projects and displays them in grid`() {
        val created = runBlocking {
            injectedRepository.createBlankProject(
                name = "Hilt Room Grid Demo",
                aspectRatio = AspectRatioPreset.RATIO_16_9,
                fps = 60,
                durationMs = 6000L
            )
        }
        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("project_card_${created.id}").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("project_card_${created.id}").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Hilt Room Grid Demo").assertIsDisplayed()
        composeRule.onNodeWithTag("new_project_fab").assertIsDisplayed()
    }

    @Test
    fun `projects viewmodel exposes reactive stateflow updating on create rename delete`() {
        val vm = com.example.viewmodel.ProjectsViewModel(injectedRepository)
        val collectorJob = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined).launch {
            vm.projects.collect {}
        }
        try {
            var createdId = ""
            vm.createNewProject("Dynamic Flow Demo", AspectRatioPreset.RATIO_16_9, 30, 5000L) { id ->
                createdId = id
            }
            var attempts = 0
            while ((createdId.isEmpty() || vm.projects.value.none { it.id == createdId }) && attempts < 80) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }
            assertTrue("Expected ProjectsViewModel.projects StateFlow to contain newly created project", vm.projects.value.any { it.id == createdId && it.name == "Dynamic Flow Demo" })

            vm.renameProject(createdId, "Renamed Flow Demo")
            attempts = 0
            while (vm.projects.value.none { it.id == createdId && it.name == "Renamed Flow Demo" } && attempts < 80) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }
            assertTrue(vm.projects.value.any { it.id == createdId && it.name == "Renamed Flow Demo" })

            vm.deleteProject(createdId)
            attempts = 0
            while (vm.projects.value.any { it.id == createdId } && attempts < 80) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }
            assertTrue(vm.projects.value.none { it.id == createdId })
        } finally {
            collectorJob.cancel()
        }
    }

    @Test
    fun `media manager imports image and audio files generates thumbnails and handles errors`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val mediaManager = MediaManager(context)
        val tempDir = File(context.cacheDir, "media_test_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            // 1. Missing/unreadable URI returns Error result gracefully
            val missingUri = android.net.Uri.fromFile(File(tempDir, "non_existent_clip.mp4"))
            val missingRes = mediaManager.importMediaResult("proj-media-1", missingUri, com.example.model.LayerType.VIDEO)
            assertTrue("Expected MediaImportResult.Error for missing file", missingRes is com.example.engine.MediaImportResult.Error)

            // 2. Empty 0-byte file returns Error result
            val emptyImg = File(tempDir, "empty.png").apply { writeBytes(ByteArray(0)) }
            val emptyRes = mediaManager.importMediaResult("proj-media-1", android.net.Uri.fromFile(emptyImg), com.example.model.LayerType.IMAGE)
            assertTrue("Expected MediaImportResult.Error for empty file", emptyRes is com.example.engine.MediaImportResult.Error)

            // 3. Valid PNG image imports cleanly and produces a thumbnail bitmap
            val pngFile = File(tempDir, "sample_photo.png")
            val bmp = Bitmap.createBitmap(120, 80, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.MAGENTA)
            java.io.FileOutputStream(pngFile).use { out ->
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            bmp.recycle()

            val imgRes = mediaManager.importMediaResult("proj-media-1", android.net.Uri.fromFile(pngFile), com.example.model.LayerType.IMAGE)
            assertTrue("Expected MediaImportResult.Success for valid PNG", imgRes is com.example.engine.MediaImportResult.Success)
            val imgMeta = (imgRes as com.example.engine.MediaImportResult.Success).metadata
            assertEquals(com.example.model.LayerType.IMAGE, imgMeta.layerType)
            assertEquals(120, imgMeta.width)
            assertEquals(80, imgMeta.height)

            val imageLayer = com.example.model.MotionLayer(
                id = "img-layer-1",
                name = imgMeta.displayName,
                type = com.example.model.LayerType.IMAGE,
                mediaPath = imgMeta.localPath
            )
            val thumb = mediaManager.getLayerThumbnail(imageLayer, maxDimension = 96)
            assertNotNull("Expected non-null thumbnail bitmap for imported image layer", thumb)

            // 4. Valid WAV audio imports cleanly via MediaManager and EditorViewModel
            val wavFile = File(tempDir, "beat_loop.wav")
            java.io.FileOutputStream(wavFile).use { out ->
                // Minimal 44-byte WAV header + 256 bytes PCM silence/samples
                val sampleRate = 8000
                val dataSize = 256
                val byteRate = sampleRate * 2
                val header = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN).apply {
                    put("RIFF".toByteArray())
                    putInt(36 + dataSize)
                    put("WAVE".toByteArray())
                    put("fmt ".toByteArray())
                    putInt(16)
                    putShort(1) // PCM
                    putShort(1) // Mono
                    putInt(sampleRate)
                    putInt(byteRate)
                    putShort(2)
                    putShort(16)
                    put("data".toByteArray())
                    putInt(dataSize)
                }
                out.write(header.array())
                out.write(ByteArray(dataSize) { (it % 64).toByte() })
            }

            val audioRes = mediaManager.importMediaResult("proj-media-1", android.net.Uri.fromFile(wavFile), com.example.model.LayerType.AUDIO)
            assertTrue("Expected MediaImportResult.Success for valid WAV", audioRes is com.example.engine.MediaImportResult.Success)
            val audioMeta = (audioRes as com.example.engine.MediaImportResult.Success).metadata
            assertEquals(com.example.model.LayerType.AUDIO, audioMeta.layerType)
            assertTrue("Expected waveform samples for imported audio", audioMeta.waveformSamples.isNotEmpty())
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun `timeline drag trim session keyframe interpolation zoom and delete undo work reliably`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val exporter = MediaExporter(context, mediaManager)
            val sample = repo.createSampleMotionProject()
            val vm = com.example.viewmodel.EditorViewModel(sample.id, repo, mediaManager, exporter)

            var attempts = 0
            while (vm.uiState.value.isLoading && attempts < 60) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }

            val layer = vm.uiState.value.project.layers.first()
            vm.selectLayer(layer.id)
            val origStart = layer.startTimeMs
            val origEnd = layer.endTimeMs

            // Simulate timeline clip drag/trim edit session + undo/redo
            vm.beginTimelineEditSession()
            vm.trimLayer(layer.id, origStart + 400L, origEnd - 300L, recordUndo = false)
            vm.endTimelineEditSession()
            val edited = vm.uiState.value.project.layers.first { it.id == layer.id }
            assertEquals(origStart + 400L, edited.startTimeMs)
            assertEquals(origEnd - 300L, edited.endTimeMs)

            vm.undo()
            val undone = vm.uiState.value.project.layers.first { it.id == layer.id }
            assertEquals(origStart, undone.startTimeMs)
            assertEquals(origEnd, undone.endTimeMs)

            vm.redo()
            val redone = vm.uiState.value.project.layers.first { it.id == layer.id }
            assertEquals(origStart + 400L, redone.startTimeMs)

            // Keyframe animation evaluation
            vm.seekTo(500L)
            vm.updateTransformProperty(com.example.model.AnimatableProperty.OPACITY, 0.25f)
            vm.seekTo(1500L)
            vm.updateTransformProperty(com.example.model.AnimatableProperty.OPACITY, 0.95f)
            val updatedLayer = vm.uiState.value.project.layers.first { it.id == layer.id }
            val midOpacity = com.example.engine.KeyframeEvaluator.evaluateProperty(
                updatedLayer,
                com.example.model.AnimatableProperty.OPACITY,
                1000L
            )
            assertTrue("Expected interpolated opacity between 0.25 and 0.95", midOpacity in 0.25f..0.95f)

            // Timeline zoom clamping
            vm.setTimelineZoom(2.0f)
            assertEquals(2.0f, vm.uiState.value.timelineZoom, 0.01f)
            vm.setTimelineZoom(9.0f)
            assertEquals(3.5f, vm.uiState.value.timelineZoom, 0.01f)

            // Delete layer & undo restores it
            val countBeforeDelete = vm.uiState.value.project.layers.size
            vm.deleteLayer(layer.id)
            assertEquals(countBeforeDelete - 1, vm.uiState.value.project.layers.size)
            vm.undo()
            assertEquals(countBeforeDelete, vm.uiState.value.project.layers.size)
        } finally {
            db.close()
        }
    }

    @Test
    fun `editor layout exposes timeline zoom inspector media import and layer controls`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("load_sample_button").performClick()

        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("preview_canvas").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()

        // Verify Timeline Ruler, Playhead Handle, Zoom controls, and Reset
        composeRule.onNodeWithTag("timeline_ruler").assertIsDisplayed()
        composeRule.onNodeWithTag("timeline_playhead_handle").assertIsDisplayed()
        composeRule.onNodeWithTag("timeline_zoom_label").assertIsDisplayed()
        composeRule.onNodeWithTag("timeline_zoom_in_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("125%").assertIsDisplayed()
        composeRule.onNodeWithTag("timeline_zoom_label").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("100%").assertIsDisplayed()

        // Verify Playback speed button cycles 1x -> 1.5x
        composeRule.onNodeWithTag("playback_speed_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("1.5x").assertIsDisplayed()

        // Verify Layers inspector exposes Video, Image, Audio, and Files import buttons
        composeRule.onNodeWithTag("inspector_tab_LAYERS").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("import_video_button").assertIsDisplayed()
        composeRule.onNodeWithTag("import_image_button").assertIsDisplayed()
        composeRule.onNodeWithTag("import_audio_button").assertIsDisplayed()
        composeRule.onNodeWithTag("import_file_button").assertIsDisplayed()

        // Verify Play/Pause toggles playback cleanly without hanging Compose idling clock
        composeRule.mainClock.autoAdvance = false
        composeRule.onNodeWithTag("play_pause_button").performClick()
        composeRule.mainClock.advanceTimeBy(40L)
        composeRule.onNodeWithContentDescription("Pause").assertIsDisplayed()
        composeRule.onNodeWithTag("play_pause_button").performClick()
        composeRule.mainClock.autoAdvance = true
        composeRule.waitForIdle()
        composeRule.onNodeWithContentDescription("Play").assertIsDisplayed()
    }

    @Test
    fun `media3 preview controller and viewmodel release resources and add bin assets to timeline`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val tempDir = File(context.cacheDir, "media3_test_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val exporter = MediaExporter(context, mediaManager)
            val project = repo.createBlankProject("Media3 Studio", AspectRatioPreset.RATIO_16_9, 30, 6000L)
            val vm = com.example.viewmodel.EditorViewModel(project.id, repo, mediaManager, exporter)

            var attempts = 0
            while (vm.uiState.value.isLoading && attempts < 60) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }

            // Create PNG file and import via MediaManager -> add via Project Media Bin
            val pngFile = File(tempDir, "hero_backdrop.png")
            val bmp = Bitmap.createBitmap(160, 90, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.CYAN)
            java.io.FileOutputStream(pngFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()

            val importRes = mediaManager.importMediaResult(project.id, android.net.Uri.fromFile(pngFile), com.example.model.LayerType.IMAGE)
            assertTrue(importRes is com.example.engine.MediaImportResult.Success)
            val asset = (importRes as com.example.engine.MediaImportResult.Success).metadata
            assertTrue("Expected fileName to end with .png", asset.fileName.endsWith(".png"))

            vm.seekTo(1000L)
            vm.addImportedMediaAssetToTimeline(asset)
            assertTrue(vm.uiState.value.project.layers.any { it.mediaPath == asset.localPath && it.startTimeMs == 1000L })
            assertTrue(vm.uiState.value.projectMediaBin.any { it.localPath == asset.localPath })

            // Playback speed updates cleanly
            vm.setPlaybackSpeed(1.5f)
            assertEquals(1.5f, vm.uiState.value.playbackSpeed, 0.01f)

            // Video preview controller releases ExoPlayer cleanly
            val videoController = com.example.engine.Media3VideoPreviewController(context)
            videoController.pause()
            videoController.release()
            org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
            assertTrue(videoController.isReleased)
            assertEquals(null, videoController.player)
        } finally {
            tempDir.deleteRecursively()
            db.close()
        }
    }

    @Test
    fun `exports repository lists renames shares and deletes exported files`() {
        val exportsDir = injectedExportsRepository.exportsDir()
        val videoFile = File(exportsDir, "demo_cut.mp4").apply { writeBytes(ByteArray(1024) { 1 }) }
        val pngFile = File(exportsDir, "still_frame.png")
        val bmp = Bitmap.createBitmap(128, 72, Bitmap.Config.ARGB_8888)
        java.io.FileOutputStream(pngFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()

        try {
            val items = injectedExportsRepository.listExports()
            val mp4Item = items.firstOrNull { it.fileName == "demo_cut.mp4" }
            val pngItem = items.firstOrNull { it.fileName == "still_frame.png" }
            assertNotNull(mp4Item)
            assertNotNull(pngItem)
            assertEquals(com.example.data.ExportFileType.MP4, mp4Item!!.type)
            assertEquals(com.example.data.ExportFileType.PNG, pngItem!!.type)

            val shareIntent = injectedExportsRepository.createShareIntent(mp4Item)
            assertEquals(android.content.Intent.ACTION_SEND, shareIntent.action)
            assertEquals("video/mp4", shareIntent.type)
            assertTrue(shareIntent.flags and android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION != 0)

            val renamed = injectedExportsRepository.renameExport(mp4Item.filePath, "final_cut_4k")
            assertNotNull(renamed)
            assertEquals("final_cut_4k.mp4", renamed!!.fileName)
            assertTrue(File(renamed.filePath).exists())

            assertTrue(injectedExportsRepository.deleteExport(renamed.filePath))
            assertTrue(injectedExportsRepository.deleteExport(pngItem.filePath))
            assertTrue(injectedExportsRepository.listExports().none { it.fileName == "final_cut_4k.mp4" })
        } finally {
            videoFile.delete()
            pngFile.delete()
            File(exportsDir, "final_cut_4k.mp4").delete()
        }
    }

    @Test
    fun `exports gallery screen opens plays with media3 filters renames and deletes exports`() {
        val exportsDir = injectedExportsRepository.exportsDir()
        val sampleMp4 = File(exportsDir, "reel_teaser.mp4").apply { writeBytes(ByteArray(2048) { 2 }) }
        val samplePng = File(exportsDir, "poster_art.png")
        val bmp = Bitmap.createBitmap(120, 68, Bitmap.Config.ARGB_8888)
        java.io.FileOutputStream(samplePng).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()

        try {
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("open_exports_gallery_button").performScrollTo().performClick()

            composeRule.waitUntil(timeoutMillis = 8_000L) {
                composeRule.onAllNodesWithTag("export_card_reel_teaser.mp4").fetchSemanticsNodes().isNotEmpty()
            }
            composeRule.onNodeWithTag("export_card_reel_teaser.mp4").assertIsDisplayed()
            composeRule.onNodeWithTag("export_card_poster_art.png").assertIsDisplayed()

            // Filter to Images only, then back to All
            composeRule.onNodeWithTag("exports_filter_IMAGES").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("export_card_poster_art.png").assertIsDisplayed()
            assertTrue(composeRule.onAllNodesWithTag("export_card_reel_teaser.mp4").fetchSemanticsNodes().isEmpty())

            composeRule.onNodeWithTag("exports_filter_ALL").performClick()
            composeRule.waitForIdle()

            // Open Media3 Player Dialog on the MP4 export
            composeRule.onNodeWithTag("export_card_reel_teaser.mp4").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("export_player_dialog").assertIsDisplayed()
            composeRule.onNodeWithTag("media3_gallery_play_pause").assertIsDisplayed()
            composeRule.onNodeWithTag("media3_gallery_seek_slider").assertIsDisplayed()
            composeRule.onNodeWithTag("media3_gallery_speed").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithText("1.5x").assertIsDisplayed()
            composeRule.onNodeWithTag("player_share_button").assertIsDisplayed()

            // Rename directly from Player dialog
            composeRule.onNodeWithTag("player_rename_button").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("rename_export_input").performTextReplacement("studio_master")
            composeRule.onNodeWithTag("confirm_rename_export_button").performClick()

            composeRule.waitUntil(timeoutMillis = 6_000L) {
                composeRule.onAllNodesWithTag("export_card_studio_master.mp4").fetchSemanticsNodes().isNotEmpty()
            }

            // Delete directly from Player dialog
            composeRule.onNodeWithTag("player_delete_button").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("confirm_delete_export_button").performClick()

            composeRule.waitUntil(timeoutMillis = 6_000L) {
                composeRule.onAllNodesWithTag("export_card_studio_master.mp4").fetchSemanticsNodes().isEmpty()
            }
        } finally {
            sampleMp4.delete()
            samplePng.delete()
            File(exportsDir, "studio_master.mp4").delete()
        }
    }

    @Test
    fun `chroma key processor keys green background preserves foreground and suppresses green spill`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "chroma_test_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            // Build synthetic 40x40 green-screen frame: #00FF00 background, white core, and green-spill gray border
            val src = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888)
            src.eraseColor(android.graphics.Color.rgb(0, 255, 0))
            for (y in 12..27) {
                for (x in 12..27) {
                    src.setPixel(x, y, android.graphics.Color.WHITE)
                }
            }
            // Spill pixel with green light cast: (110, 185, 110)
            src.setPixel(10, 20, android.graphics.Color.rgb(110, 185, 110))

            val keyedNoSpill = com.example.engine.ChromaKeyProcessor.applyChromaKey(
                source = src,
                keyColorHex = 0xFF00FF00L,
                tolerance = 0.35f,
                spillSuppression = 0.0f,
                useCache = false
            )
            val keyedWithSpill = com.example.engine.ChromaKeyProcessor.applyChromaKey(
                source = src,
                keyColorHex = 0xFF00FF00L,
                tolerance = 0.35f,
                spillSuppression = 0.9f,
                useCache = false
            )

            // Green background pixel keyed out to transparent
            assertEquals(0, android.graphics.Color.alpha(keyedWithSpill.getPixel(2, 2)))
            // Foreground white subject preserved opaque
            assertEquals(255, android.graphics.Color.alpha(keyedWithSpill.getPixel(20, 20)))

            // Spill pixel should have much lower green excess when spillSuppression = 0.9f vs 0.0f
            val noSpillPx = keyedNoSpill.getPixel(10, 20)
            val suppressedPx = keyedWithSpill.getPixel(10, 20)
            val excessBefore = android.graphics.Color.green(noSpillPx) - android.graphics.Color.red(noSpillPx)
            val excessAfter = android.graphics.Color.green(suppressedPx) - android.graphics.Color.red(suppressedPx)
            assertTrue("Expected spill suppression to reduce green cast (before=$excessBefore, after=$excessAfter)", excessAfter < excessBefore)

            // Verify CompositionRenderer composites underlying red background through keyed green pixels
            val greenFile = File(tempDir, "greenscreen_frame.png")
            java.io.FileOutputStream(greenFile).use { src.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val mediaManager = MediaManager(context)
            val project = com.example.model.MotionProject(
                name = "Chroma Render Test",
                backgroundColorHex = 0xFFCC2233L,
                layers = listOf(
                    com.example.model.MotionLayer(
                        id = "gs-layer",
                        name = "Green Screen Clip",
                        type = com.example.model.LayerType.IMAGE,
                        mediaPath = greenFile.absolutePath,
                        mediaWidth = 40,
                        mediaHeight = 40,
                        effects = listOf(
                            com.example.model.LayerEffect(
                                type = com.example.model.EffectType.CHROMA_KEY,
                                intensity = 0.4f,
                                keyColorHex = 0xFF00FF00L,
                                spillSuppression = 0.65f
                            )
                        )
                    )
                )
            )
            val composed = CompositionRenderer.renderToBitmap(
                project = project,
                timeMs = 0L,
                width = 160,
                height = 90,
                mediaManager = mediaManager,
                showGuides = false
            )
            assertEquals(160, composed.width)
            assertEquals(90, composed.height)

            // Verify ChromaKeyProcessor also handles Blue Screen (0xFF0047FF) and Tolerance expansion
            val blueSrc = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
            blueSrc.eraseColor(android.graphics.Color.rgb(0, 71, 255))
            blueSrc.setPixel(8, 8, android.graphics.Color.rgb(240, 200, 160)) // skin tone foreground
            val keyedBlue = com.example.engine.ChromaKeyProcessor.applyChromaKey(
                source = blueSrc,
                keyColorHex = 0xFF0047FFL,
                tolerance = 0.35f,
                spillSuppression = 0.6f,
                useCache = false
            )
            assertEquals(0, android.graphics.Color.alpha(keyedBlue.getPixel(1, 1)))
            assertEquals(255, android.graphics.Color.alpha(keyedBlue.getPixel(8, 8)))

            src.recycle()
            blueSrc.recycle()
            keyedBlue.recycle()
            keyedNoSpill.recycle()
            keyedWithSpill.recycle()
            composed.recycle()
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun `chroma key component configures key color tolerance and spill suppression on video layer`() {
        // 1. Verify ViewModel & JSON serialization on a VIDEO layer
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val exporter = MediaExporter(context, mediaManager)
            val videoLayer = com.example.model.MotionLayer(
                id = "vid-chroma-1",
                name = "Talent Green Screen.mp4",
                type = com.example.model.LayerType.VIDEO,
                startTimeMs = 0L,
                endTimeMs = 4000L
            )
            val project = com.example.model.MotionProject(
                id = "chroma-vm-proj",
                name = "Chroma VM Test",
                layers = listOf(videoLayer)
            )
            runBlocking { repo.saveProject(project) }
            val vm = com.example.viewmodel.EditorViewModel(project.id, repo, mediaManager, exporter)
            var attempts = 0
            while (vm.uiState.value.isLoading && attempts < 60) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }

            vm.selectLayer("vid-chroma-1")
            vm.addEffect(com.example.model.EffectType.CHROMA_KEY)
            val fx = vm.uiState.value.selectedLayer!!.effects.first { it.type == com.example.model.EffectType.CHROMA_KEY }
            vm.updateChromaKey(
                effectId = fx.id,
                keyColorHex = 0xFF0047FFL,
                tolerance = 0.62f,
                spillSuppression = 0.78f,
                recordUndo = true
            )

            val updatedFx = vm.uiState.value.selectedLayer!!.effects.first { it.id == fx.id }
            assertEquals(0xFF0047FFL, updatedFx.keyColorHex)
            assertEquals(0.62f, updatedFx.intensity, 0.01f)
            assertEquals(0.78f, updatedFx.spillSuppression, 0.01f)

            val roundTrip = com.example.data.ProjectSerializer.fromJson(
                com.example.data.ProjectSerializer.toJson(vm.uiState.value.project)
            )
            val restoredFx = roundTrip!!.layers.first().effects.first()
            assertEquals(0xFF0047FFL, restoredFx.keyColorHex)
            assertEquals(0.78f, restoredFx.spillSuppression, 0.01f)
        } finally {
            db.close()
        }

        // 2. Verify Compose Chroma Key Effect Component UI
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("load_sample_button").performClick()
        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("preview_canvas").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("inspector_tab_EFFECTS").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("add_effect_CHROMA_KEY").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("chroma_key_color_hex").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("chroma_key_tolerance_slider").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("chroma_key_spill_slider").performScrollTo().assertIsDisplayed()

        // Select Chroma Blue swatch (#0047FF)
        composeRule.onNodeWithTag("chroma_swatch_2").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("#0047FF").performScrollTo().assertIsDisplayed()

        // Open Color Picker dialog and apply color
        composeRule.onNodeWithTag("chroma_key_picker_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("chroma_color_picker_dialog").assertIsDisplayed()
        composeRule.onNodeWithTag("confirm_chroma_color_button").performClick()
        composeRule.waitForIdle()
    }

    @Test
    fun `audio mixer master volume track mute solo and voiceover timeline insertion work cleanly`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val tempDir = File(context.cacheDir, "voiceover_test_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val mediaManager = MediaManager(context)
            val repo = ProjectRepository(context, db.projectDao(), mediaManager)
            val exporter = MediaExporter(context, mediaManager)
            val musicLayer = com.example.model.MotionLayer(
                id = "bgm-track-1",
                name = "Synth Bass",
                type = com.example.model.LayerType.AUDIO,
                startTimeMs = 0L,
                endTimeMs = 5000L,
                volume = 0.8f
            )
            val project = com.example.model.MotionProject(
                id = "mixer-vm-proj",
                name = "Mixer Test",
                masterVolume = 1.0f,
                layers = listOf(musicLayer)
            )
            repo.saveProject(project)

            val vm = com.example.viewmodel.EditorViewModel(project.id, repo, mediaManager, exporter)
            var attempts = 0
            while (vm.uiState.value.isLoading && attempts < 60) {
                org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                Thread.sleep(30L)
                attempts++
            }

            // Master volume & per-track volume/mute/solo
            vm.setMasterVolume(0.72f, recordUndo = true)
            assertEquals(0.72f, vm.uiState.value.project.masterVolume, 0.01f)

            vm.setLayerVolume("bgm-track-1", 0.45f)
            vm.toggleLayerMute("bgm-track-1")
            vm.toggleLayerSolo("bgm-track-1")
            val updatedMusic = vm.uiState.value.project.layers.first { it.id == "bgm-track-1" }
            assertEquals(0.45f, updatedMusic.volume, 0.01f)
            assertTrue(updatedMusic.isMuted)
            assertTrue(updatedMusic.isSolo)

            // Voiceover insertion at playhead 1200ms
            val fakeVoiceFile = File(tempDir, "voiceover_clip.m4a").apply { writeBytes(ByteArray(512) { 7 }) }
            vm.seekTo(1200L)
            vm.addRecordedVoiceoverToTimeline(
                filePath = fakeVoiceFile.absolutePath,
                displayName = "Voiceover 10:15",
                durationMs = 2400L,
                waveformSamples = listOf(0.2f, 0.8f, 0.5f, 0.9f)
            )
            val voLayer = vm.uiState.value.project.layers.firstOrNull { it.name == "Voiceover 10:15" }
            assertNotNull(voLayer)
            assertEquals(com.example.model.LayerType.AUDIO, voLayer!!.type)
            assertEquals(1200L, voLayer.startTimeMs)
            assertEquals(3600L, voLayer.endTimeMs)

            // JSON round-trip preserves masterVolume & voiceover track
            val restored = com.example.data.ProjectSerializer.fromJson(
                com.example.data.ProjectSerializer.toJson(vm.uiState.value.project)
            )
            assertEquals(0.72f, restored!!.masterVolume, 0.01f)
            assertTrue(restored.layers.any { it.name == "Voiceover 10:15" && it.type == com.example.model.LayerType.AUDIO })

            // Recorder cancels safely even when not active
            val recorder = com.example.engine.VoiceoverRecorder(context)
            recorder.cancelAndRelease()
            assertEquals(false, recorder.isRecording)
        } finally {
            tempDir.deleteRecursively()
            db.close()
        }
    }

    @Test
    fun `trim and mix panel renders voiceover studio and multi track audio mixer`() {
        val created = runBlocking {
            val base = SampleProjectFactory.createShowcaseProject()
            val audioTrack = com.example.model.MotionLayer(
                id = "mix-audio-ui-1",
                name = "Narration Track",
                type = com.example.model.LayerType.AUDIO,
                startTimeMs = 0L,
                endTimeMs = 4000L,
                volume = 0.85f
            )
            val withAudio = base.copy(
                id = "mix-ui-proj",
                name = "Audio Mix UI",
                layers = base.layers + audioTrack
            )
            injectedRepository.saveProject(withAudio)
            withAudio
        }

        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("project_card_${created.id}").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("project_card_${created.id}").performScrollTo().performClick()

        composeRule.waitUntil(timeoutMillis = 8_000L) {
            composeRule.onAllNodesWithTag("preview_canvas").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("inspector_tab_TRIM").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("voiceover_studio_card").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("voiceover_record_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("audio_mixer_card").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("mixer_master_volume_slider").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("mixer_track_slider_mix-audio-ui-1").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("mixer_mute_mix-audio-ui-1").performScrollTo().performClick()
        composeRule.onNodeWithTag("mixer_solo_mix-audio-ui-1").performScrollTo().performClick()
        composeRule.waitForIdle()
    }
}
