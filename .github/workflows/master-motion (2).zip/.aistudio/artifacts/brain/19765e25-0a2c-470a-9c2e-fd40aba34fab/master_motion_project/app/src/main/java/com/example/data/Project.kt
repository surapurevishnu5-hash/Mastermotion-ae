package com.example.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "motion_projects")
data class Project(
    @PrimaryKey val id: String,
    val name: String,
    val aspectRatioLabel: String = "16:9",
    val resolutionWidth: Int = 1920,
    val resolutionHeight: Int = 1080,
    @ColumnInfo(name = "resolutionLabel")
    val resolution: String = "${resolutionWidth}×${resolutionHeight}",
    @ColumnInfo(name = "fps")
    val frameRate: Int = 30,
    val durationMs: Long = 8000L,
    val layerCount: Int = 0,
    val thumbnailPath: String? = null,
    val projectJson: String = "",
    @ColumnInfo(name = "updatedAt")
    val lastModified: Long = System.currentTimeMillis()
)

typealias ProjectEntity = Project
