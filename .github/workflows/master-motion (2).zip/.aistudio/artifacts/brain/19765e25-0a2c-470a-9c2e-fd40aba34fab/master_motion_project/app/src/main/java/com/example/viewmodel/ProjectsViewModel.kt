package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectRepository
import com.example.data.ProjectSummary
import com.example.model.AspectRatioPreset
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val repository: ProjectRepository
) : ViewModel() {

    val projects: StateFlow<List<ProjectSummary>> = repository.projects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _isCreating = MutableStateFlow(false)
    val isCreating: StateFlow<Boolean> = _isCreating.asStateFlow()

    init {
        refreshLocalProjects()
    }

    fun refreshLocalProjects() {
        viewModelScope.launch {
            repository.scanLocalProjectsIntoDatabase()
        }
    }

    fun createNewProject(
        name: String,
        aspectRatio: AspectRatioPreset,
        fps: Int,
        durationMs: Long,
        onCreated: (String) -> Unit
    ) {
        if (_isCreating.value) return
        viewModelScope.launch {
            _isCreating.value = true
            try {
                val created = repository.createBlankProject(
                    name = name,
                    aspectRatio = aspectRatio,
                    fps = fps,
                    durationMs = durationMs
                )
                onCreated(created.id)
            } finally {
                _isCreating.value = false
            }
        }
    }

    fun loadSampleMotionProject(onCreated: (String) -> Unit) {
        if (_isCreating.value) return
        viewModelScope.launch {
            _isCreating.value = true
            try {
                val created = repository.createSampleMotionProject()
                onCreated(created.id)
            } finally {
                _isCreating.value = false
            }
        }
    }

    fun renameProject(projectId: String, newName: String) {
        viewModelScope.launch {
            repository.renameProject(projectId, newName)
        }
    }

    fun duplicateProject(projectId: String) {
        viewModelScope.launch {
            repository.duplicateProject(projectId)
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
        }
    }
}

typealias ProjectsHubViewModel = ProjectsViewModel
