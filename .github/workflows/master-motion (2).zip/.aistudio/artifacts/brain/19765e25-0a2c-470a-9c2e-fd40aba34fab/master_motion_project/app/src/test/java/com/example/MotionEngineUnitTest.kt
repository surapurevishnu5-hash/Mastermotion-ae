package com.example

import com.example.data.ProjectSerializer
import com.example.data.SampleProjectFactory
import com.example.engine.KeyframeEvaluator
import com.example.model.AnimatableProperty
import com.example.model.AspectRatioPreset
import com.example.model.CubicBezierCurve
import com.example.model.ExportResolution
import com.example.model.Keyframe
import com.example.model.LayerTransition
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.TransitionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MotionEngineUnitTest {

    @Test
    fun `cubic bezier solver matches endpoints and overshoot`() {
        assertEquals(0f, KeyframeEvaluator.evaluateBezier(0f, CubicBezierCurve.EASE_IN_OUT), 0.001f)
        assertEquals(1f, KeyframeEvaluator.evaluateBezier(1f, CubicBezierCurve.EASE_IN_OUT), 0.001f)
        assertEquals(0.5f, KeyframeEvaluator.evaluateBezier(0.5f, CubicBezierCurve.LINEAR), 0.01f)

        // Hold step curve stays at 0 until x == 1
        assertEquals(0f, KeyframeEvaluator.evaluateBezier(0.95f, CubicBezierCurve.HOLD), 0.001f)
        assertEquals(1f, KeyframeEvaluator.evaluateBezier(1f, CubicBezierCurve.HOLD), 0.001f)

        // Overshoot curve exceeds 1.0 around t=0.65..0.8
        val overshootMid = KeyframeEvaluator.evaluateBezier(0.65f, CubicBezierCurve.OVERSHOOT)
        assertTrue("Expected overshoot > 1.0, was $overshootMid", overshootMid > 1.0f)
    }

    @Test
    fun `keyframe evaluator interpolates 2D and 3D properties`() {
        val layer = MotionLayer(
            name = "Test",
            type = LayerType.SHAPE,
            startTimeMs = 0L,
            endTimeMs = 4000L,
            keyframeTracks = mapOf(
                AnimatableProperty.POSITION_X.name to listOf(
                    Keyframe(timeMs = 0L, value = -0.5f, curve = CubicBezierCurve.LINEAR),
                    Keyframe(timeMs = 2000L, value = 0.5f, curve = CubicBezierCurve.LINEAR)
                ),
                AnimatableProperty.ROTATION_Y.name to listOf(
                    Keyframe(timeMs = 0L, value = 0f, curve = CubicBezierCurve.LINEAR),
                    Keyframe(timeMs = 2000L, value = 90f, curve = CubicBezierCurve.LINEAR)
                )
            )
        )

        val midX = KeyframeEvaluator.evaluateProperty(layer, AnimatableProperty.POSITION_X, 1000L)
        val midYaw = KeyframeEvaluator.evaluateProperty(layer, AnimatableProperty.ROTATION_Y, 1000L)
        assertEquals(0f, midX, 0.02f)
        assertEquals(45f, midYaw, 1.0f)
    }

    @Test
    fun `in and out fade transition modulates opacity`() {
        val layer = MotionLayer(
            name = "FadeLayer",
            type = LayerType.TEXT,
            startTimeMs = 0L,
            endTimeMs = 4000L,
            inTransition = LayerTransition(TransitionType.FADE, 1000L),
            outTransition = LayerTransition(TransitionType.FADE, 1000L)
        )

        val atStart = KeyframeEvaluator.evaluateLayerState(layer, 0L)
        val atMid = KeyframeEvaluator.evaluateLayerState(layer, 2000L)
        val atEnd = KeyframeEvaluator.evaluateLayerState(layer, 4000L)

        assertEquals(0f, atStart.transform.opacity, 0.02f)
        assertEquals(1f, atMid.transform.opacity, 0.02f)
        assertEquals(0f, atEnd.transform.opacity, 0.02f)
    }

    @Test
    fun `project serializer round trips sample 3D project cleanly`() {
        val original = SampleProjectFactory.createShowcaseProject()
        val json = ProjectSerializer.toJson(original)
        val decoded = ProjectSerializer.fromJson(json)
        assertNotNull(decoded)
        assertEquals(original.id, decoded!!.id)
        assertEquals(original.name, decoded.name)
        assertEquals(original.layers.size, decoded.layers.size)
        assertEquals(original.layers.first().keyframeTracks.size, decoded.layers.first().keyframeTracks.size)
    }

    @Test
    fun `aspect ratio presets provide accurate 1080p and 4K dimensions`() {
        assertEquals(1920 to 1080, AspectRatioPreset.RATIO_16_9.dimensionsFor(ExportResolution.FHD_1080P))
        assertEquals(3840 to 2160, AspectRatioPreset.RATIO_16_9.dimensionsFor(ExportResolution.UHD_4K))
        assertEquals(1080 to 1920, AspectRatioPreset.RATIO_9_16.dimensionsFor(ExportResolution.FHD_1080P))
        assertEquals(2160 to 3840, AspectRatioPreset.RATIO_9_16.dimensionsFor(ExportResolution.UHD_4K))
    }
}
