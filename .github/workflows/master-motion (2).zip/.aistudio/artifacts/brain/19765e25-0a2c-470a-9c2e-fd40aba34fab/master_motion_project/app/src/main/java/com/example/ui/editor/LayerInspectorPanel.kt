package com.example.ui.editor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.ImportedMediaMetadata
import com.example.engine.MediaManager
import com.example.model.BlendModeType
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.ShapeType
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.KeyframeMagenta
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackAudioColor
import com.example.ui.theme.TrackImageColor
import com.example.ui.theme.TrackShapeColor
import com.example.ui.theme.TrackTextColor
import com.example.ui.theme.TrackVideoColor

private val studioColorSwatches = listOf(
    0xFF8B5CF6L to 0xFF3B82F6L, // Purple -> Blue
    0xFF3B82F6L to 0xFF38BDF8L, // Blue -> Cyan
    0xFFEC4899L to 0xFF8B5CF6L, // Magenta -> Purple
    0xFF10B981L to 0xFF06B6D4L, // Emerald -> Cyan
    0xFFF59E0BL to 0xFFEF4444L, // Amber -> Coral
    0xFFFFFFFFL to 0xFF9CA3AFL  // Pure White -> Silver
)

@Composable
fun LayerInspectorPanel(
    layer: MotionLayer?,
    mediaManager: MediaManager? = null,
    projectMediaBin: List<ImportedMediaMetadata> = emptyList(),
    onAddAssetToTimeline: (ImportedMediaMetadata) -> Unit = {},
    onImportVideo: () -> Unit,
    onImportImage: () -> Unit,
    onImportAudio: () -> Unit,
    onBrowseMediaFile: () -> Unit = {},
    onAddShape: (ShapeType) -> Unit,
    onAddText: () -> Unit,
    onToggleVisibility: (String) -> Unit,
    onToggleLock: (String) -> Unit,
    onToggleMute: (String) -> Unit,
    onToggleSolo: (String) -> Unit,
    onMoveZOrder: (String, Int) -> Unit,
    onDuplicate: (String) -> Unit,
    onDelete: (String) -> Unit,
    onRenameLayer: (String, String) -> Unit,
    onUpdateTextContent: (String, String, Float?) -> Unit,
    onUpdateShapeType: (String, ShapeType) -> Unit,
    onUpdateColors: (String, Long, Long) -> Unit,
    onUpdateBlendMode: (String, BlendModeType) -> Unit,
    modifier: Modifier = Modifier
) {
    val scroll = rememberScrollState()

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(12.dp)
    ) {
        // Media & Element Import Strip
        Text("Import Media & Add Elements", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            AddSourceChip("Video", Icons.Filled.Videocam, TrackVideoColor, "import_video_button", onImportVideo)
            AddSourceChip("Image", Icons.Filled.Image, TrackImageColor, "import_image_button", onImportImage)
            AddSourceChip("Audio", Icons.Filled.Audiotrack, TrackAudioColor, "import_audio_button", onImportAudio)
            AddSourceChip("Files", Icons.Filled.FolderOpen, CyberCyan, "import_file_button", onBrowseMediaFile)
            AddSourceChip("Shape", Icons.Filled.Category, TrackShapeColor, "add_shape_button") {
                onAddShape(ShapeType.ROUNDED_CARD)
            }
            AddSourceChip("Text", Icons.Filled.TextFields, TrackTextColor, "add_text_button", onAddText)
        }

        if (projectMediaBin.isNotEmpty()) {
            Text("Project Media Library (${projectMediaBin.size})", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .testTag("project_media_bin")
            ) {
                projectMediaBin.forEach { asset ->
                    MediaBinItemCard(
                        asset = asset,
                        mediaManager = mediaManager,
                        onAddToTimeline = { onAddAssetToTimeline(asset) }
                    )
                }
            }
        }

        if (layer == null) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = StudioSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Tap any source above to create a layer, or select an existing layer on the timeline to edit its properties.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(16.dp)
                )
            }
            return
        }

        // Selected Layer Controls Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = StudioSurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "${layer.type.label} Controls",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        IconButton(
                            onClick = { onMoveZOrder(layer.id, 1) },
                            modifier = Modifier.size(34.dp).testTag("layer_up_button")
                        ) {
                            Icon(Icons.Filled.ArrowUpward, contentDescription = "Bring Forward", tint = CyberCyan, modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { onMoveZOrder(layer.id, -1) },
                            modifier = Modifier.size(34.dp).testTag("layer_down_button")
                        ) {
                            Icon(Icons.Filled.ArrowDownward, contentDescription = "Send Backward", tint = CyberCyan, modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { onToggleVisibility(layer.id) },
                            modifier = Modifier.size(34.dp).testTag("layer_visibility_button")
                        ) {
                            Icon(
                                if (layer.isVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = "Visibility",
                                tint = if (layer.isVisible) TextPrimary else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { onToggleLock(layer.id) },
                            modifier = Modifier.size(34.dp).testTag("layer_lock_button")
                        ) {
                            Icon(
                                if (layer.isLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                contentDescription = "Lock Layer",
                                tint = if (layer.isLocked) KeyframeMagenta else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { onDuplicate(layer.id) },
                            modifier = Modifier.size(34.dp).testTag("layer_duplicate_button")
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Duplicate Layer", tint = ElectricPurple, modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { onDelete(layer.id) },
                            modifier = Modifier.size(34.dp).testTag("layer_delete_button")
                        ) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete Layer", tint = ErrorCoral, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Quick Solo & Mute pills
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (layer.isSolo) CyberBlue.copy(alpha = 0.25f) else StudioInspector,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (layer.isSolo) CyberCyan else StudioBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onToggleSolo(layer.id) }
                            .testTag("layer_solo_button")
                    ) {
                        Text(
                            text = if (layer.isSolo) "SOLO ON" else "Solo",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (layer.isSolo) Color.White else TextSecondary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    if (layer.type == LayerType.AUDIO || layer.type == LayerType.VIDEO) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (layer.isMuted) ErrorCoral.copy(alpha = 0.22f) else StudioInspector,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (layer.isMuted) ErrorCoral else StudioBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onToggleMute(layer.id) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    if (layer.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    tint = if (layer.isMuted) ErrorCoral else TextPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (layer.isMuted) "Muted" else "Audio On",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }

                // Media Thumbnail & Source Metadata Preview
                if (layer.mediaPath != null) {
                    val mediaThumb by produceState<android.graphics.Bitmap?>(initialValue = null, layer.mediaPath, layer.type) {
                        value = if (mediaManager != null && (layer.type == LayerType.IMAGE || layer.type == LayerType.VIDEO)) {
                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                mediaManager.getLayerThumbnail(layer, maxDimension = 240)
                            }
                        } else null
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(StudioInspector)
                            .border(1.dp, StudioBorder, RoundedCornerShape(10.dp))
                            .padding(8.dp)
                            .testTag("inspector_media_preview")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(width = 72.dp, height = 44.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(com.example.ui.theme.ObsidianBg)
                        ) {
                            if (mediaThumb != null && !mediaThumb!!.isRecycled) {
                                Image(
                                    bitmap = mediaThumb!!.asImageBitmap(),
                                    contentDescription = "${layer.name} preview thumbnail",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("inspector_media_thumbnail")
                                )
                            } else {
                                Icon(
                                    imageVector = layerTypeIcon(layer.type),
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (layer.type == LayerType.AUDIO) "Audio Clip" else "${layer.mediaWidth}×${layer.mediaHeight}",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary
                            )
                            Text(
                                text = "Clip: ${String.format(java.util.Locale.US, "%.1fs", (layer.endTimeMs - layer.startTimeMs) / 1000f)} • Media: ${String.format(java.util.Locale.US, "%.1fs", layer.mediaDurationMs / 1000f)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                    }
                }

                // Rename field
                OutlinedTextField(
                    value = layer.name,
                    onValueChange = { onRenameLayer(layer.id, it) },
                    label = { Text("Layer Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricPurple,
                        unfocusedBorderColor = StudioBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Text Content & Size Editor
                if (layer.type == LayerType.TEXT) {
                    OutlinedTextField(
                        value = layer.textContent,
                        onValueChange = { onUpdateTextContent(layer.id, it, null) },
                        label = { Text("Text Content") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = StudioBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("layer_text_content_input")
                    )
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Font Size", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                        Text("${layer.textSizeSp.toInt()}sp", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    }
                    Slider(
                        value = layer.textSizeSp.coerceIn(16f, 96f),
                        onValueChange = { onUpdateTextContent(layer.id, layer.textContent, it) },
                        valueRange = 16f..96f,
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = CyberCyan)
                    )
                }

                // Shape Selector
                if (layer.type == LayerType.SHAPE) {
                    Text("Shape Geometry", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        ShapeType.entries.forEach { st ->
                            val selected = st == layer.shapeType
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selected) ElectricPurple.copy(alpha = 0.25f) else StudioInspector,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (selected) ElectricPurple else StudioBorder
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onUpdateShapeType(layer.id, st) }
                            ) {
                                Text(
                                    text = st.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color.White else TextSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                // Color & Gradient Swatches (for Shape / Text / Glow)
                if (layer.type == LayerType.SHAPE || layer.type == LayerType.TEXT) {
                    Text("Color Palette", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        studioColorSwatches.forEach { (primary, secondary) ->
                            val selected = layer.colorHex == primary && layer.secondaryColorHex == secondary
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(
                                        androidx.compose.ui.graphics.Brush.linearGradient(
                                            listOf(Color(primary), Color(secondary))
                                        )
                                    )
                                    .border(
                                        width = if (selected) 2.5.dp else 1.dp,
                                        color = if (selected) Color.White else StudioBorder,
                                        shape = CircleShape
                                    )
                                    .clickable { onUpdateColors(layer.id, primary, secondary) }
                            )
                        }
                    }
                }

                // Blend Mode Selector
                if (layer.type != LayerType.AUDIO) {
                    Text("Blend Mode", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BlendModeType.entries.forEach { mode ->
                            val selected = layer.blendMode == mode
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selected) CyberBlue.copy(alpha = 0.28f) else StudioInspector,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (selected) CyberBlue else StudioBorder
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onUpdateBlendMode(layer.id, mode) }
                            ) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color.White else TextSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddSourceChip(
    label: String,
    icon: ImageVector,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = accent.copy(alpha = 0.16f),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.65f)),
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
        ) {
            Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White)
        }
    }
}

@Composable
private fun MediaBinItemCard(
    asset: ImportedMediaMetadata,
    mediaManager: MediaManager?,
    onAddToTimeline: () -> Unit
) {
    val thumb by produceState<android.graphics.Bitmap?>(initialValue = null, asset.localPath, asset.layerType) {
        value = if (mediaManager != null && (asset.layerType == LayerType.IMAGE || asset.layerType == LayerType.VIDEO)) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                mediaManager.getThumbnailForMetadata(asset, maxDimension = 180)
            }
        } else null
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = StudioSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .width(126.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onAddToTimeline)
            .testTag("media_bin_card_${asset.fileName}")
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(com.example.ui.theme.ObsidianBg)
            ) {
                if (thumb != null && !thumb!!.isRecycled) {
                    Image(
                        bitmap = thumb!!.asImageBitmap(),
                        contentDescription = "${asset.fileName} thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = layerTypeIcon(asset.layerType),
                        contentDescription = asset.fileName,
                        tint = layerTrackColor(asset.layerType),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = asset.fileName,
                style = MaterialTheme.typography.labelSmall,
                color = TextPrimary,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
            Text(
                text = "+ Timeline (${String.format(java.util.Locale.US, "%.1fs", asset.durationMs / 1000f)})",
                style = MaterialTheme.typography.labelSmall,
                color = CyberCyan,
                maxLines = 1
            )
        }
    }
}
