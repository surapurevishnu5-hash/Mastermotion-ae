package com.example.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectRepository
import com.example.engine.AudioPlaybackController
import com.example.engine.ExportConfig
import com.example.engine.ExportProgress
import com.example.engine.ExportResult
import com.example.engine.ImportedMediaMetadata
import com.example.engine.KeyframeEvaluator
import com.example.engine.Media3VideoPreviewController
import com.example.engine.MediaExporter
import com.example.engine.MediaManager
import com.example.engine.VoiceoverRecorder
import com.example.model.AnimatableProperty
import com.example.model.BlendModeType
import com.example.model.CubicBezierCurve
import com.example.model.EffectType
import com.example.model.LayerEffect
import com.example.model.LayerTransition
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.MotionProject
import com.example.model.ShapeType
import com.example.model.TransformValues
import com.example.model.TransitionType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class InspectorTab(val label: String) {
    LAYERS("Layers"),
    TRANSFORM("Transform"),
    GRAPH("Graph"),
    EFFECTS("FX & Trans"),
    TRIM("Trim & Mix")
}

sealed interface ExportUiState {
    data object Idle : ExportUiState
    data class Running(val progress: ExportProgress) : ExportUiState
    data class Completed(val result: ExportResult) : ExportUiState
    data class Failed(val message: String) : ExportUiState
}

data class VoiceoverRecorderUiState(
    val isRecording: Boolean = false,
    val elapsedMs: Long = 0L,
    val currentLevel: Float = 0f,
    val liveBars: List<Float> = emptyList(),
    val permissionDenied: Boolean = false
)

data class EditorUiState(
    val isLoading: Boolean = true,
    val project: MotionProject = MotionProject(),
    val selectedLayerId: String? = null,
    val playheadMs: Long = 0L,
    val isPlaying: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val showGuides: Boolean = true,
    val autoKeyframe: Boolean = true,
    val activeTab: InspectorTab = InspectorTab.LAYERS,
    val transformMode3D: Boolean = false,
    val linkScale: Boolean = true,
    val selectedGraphProperty: AnimatableProperty = AnimatableProperty.POSITION_X,
    val selectedSegmentIndex: Int = 0,
    val timelineZoom: Float = 1.0f,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isSaving: Boolean = false,
    val hasUnsavedChanges: Boolean = false,
    val statusBanner: String? = null,
    val projectMediaBin: List<ImportedMediaMetadata> = emptyList(),
    val exportState: ExportUiState = ExportUiState.Idle,
    val voiceoverState: VoiceoverRecorderUiState = VoiceoverRecorderUiState()
) {
    val selectedLayer: MotionLayer?
        get() = project.layers.firstOrNull { it.id == selectedLayerId }
}

class EditorViewModel(
    private val projectId: String,
    private val repository: ProjectRepository,
    val mediaManager: MediaManager,
    private val mediaExporter: MediaExporter
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    val videoPreviewController = Media3VideoPreviewController(mediaManager.appContext)
    private val audioController = AudioPlaybackController(mediaManager.appContext)
    private val voiceoverRecorder = VoiceoverRecorder(mediaManager.appContext)
    private val undoStack = ArrayDeque<MotionProject>()
    private val redoStack = ArrayDeque<MotionProject>()
    private var pendingTimelineBaseline: MotionProject? = null

    private var autoSaveJob: Job? = null
    private var exportJob: Job? = null
    private var voiceoverTickerJob: Job? = null

    init {
        loadProject()
    }

    private fun loadProject() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val loaded = repository.loadProject(projectId) ?: repository.createBlankProject(
                name = "New Studio Project",
                aspectRatio = com.example.model.AspectRatioPreset.RATIO_16_9
            )
            val mediaBin = mediaManager.listProjectMedia(loaded.id, loaded.layers)
            undoStack.clear()
            redoStack.clear()
            _uiState.update {
                it.copy(
                    isLoading = false,
                    project = loaded,
                    selectedLayerId = loaded.layers.maxByOrNull { l -> l.zIndex }?.id,
                    playheadMs = 0L,
                    hasUnsavedChanges = false,
                    projectMediaBin = mediaBin
                )
            }
            mediaManager.prewarmProjectMedia(loaded.layers)
            syncMediaPlayers(playheadMs = 0L, isPlaying = false)
        }
    }

    private fun commitProjectEdit(
        recordUndo: Boolean = true,
        transform: (MotionProject) -> MotionProject
    ) {
        val current = _uiState.value.project
        val next = transform(current).copy(updatedAt = System.currentTimeMillis())
        if (next == current) return

        if (recordUndo) {
            if (undoStack.size >= 35) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
        }

        _uiState.update { state ->
            val validSelected = if (next.layers.any { it.id == state.selectedLayerId }) {
                state.selectedLayerId
            } else {
                next.layers.maxByOrNull { it.zIndex }?.id
            }
            state.copy(
                project = next,
                selectedLayerId = validSelected,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                hasUnsavedChanges = true
            )
        }
        scheduleAutoSave()
    }

    fun beginTimelineEditSession() {
        if (pendingTimelineBaseline == null) {
            pendingTimelineBaseline = _uiState.value.project
        }
    }

    fun endTimelineEditSession() {
        val baseline = pendingTimelineBaseline ?: return
        pendingTimelineBaseline = null
        val current = _uiState.value.project
        if (current != baseline) {
            if (undoStack.size >= 35) undoStack.removeFirst()
            undoStack.addLast(baseline)
            redoStack.clear()
            _uiState.update { it.copy(canUndo = undoStack.isNotEmpty(), canRedo = false) }
        }
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(_uiState.value.project)
        _uiState.update { state ->
            state.copy(
                project = prev,
                selectedLayerId = prev.layers.firstOrNull { it.id == state.selectedLayerId }?.id
                    ?: prev.layers.maxByOrNull { it.zIndex }?.id,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                hasUnsavedChanges = true
            )
        }
        scheduleAutoSave()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(_uiState.value.project)
        _uiState.update { state ->
            state.copy(
                project = next,
                selectedLayerId = next.layers.firstOrNull { it.id == state.selectedLayerId }?.id
                    ?: next.layers.maxByOrNull { it.zIndex }?.id,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                hasUnsavedChanges = true
            )
        }
        scheduleAutoSave()
    }

    fun saveProjectNow(showToastBanner: Boolean = true) {
        autoSaveJob?.cancel()
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            withContext(NonCancellable) {
                repository.saveProject(_uiState.value.project)
            }
            _uiState.update {
                it.copy(
                    isSaving = false,
                    hasUnsavedChanges = false,
                    statusBanner = if (showToastBanner) "Project saved" else it.statusBanner
                )
            }
        }
    }

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1400L)
            repository.saveProject(_uiState.value.project)
            _uiState.update { it.copy(hasUnsavedChanges = false, isSaving = false) }
        }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    // --- Playback & Timeline Scrubbing (Media3 ExoPlayer Sync) ---

    fun activeVideoLayerAt(timeMs: Long, layers: List<MotionLayer> = _uiState.value.project.layers): MotionLayer? {
        val anySolo = layers.any { it.type != LayerType.AUDIO && it.isSolo }
        return layers
            .filter {
                it.type == LayerType.VIDEO &&
                    !it.mediaPath.isNullOrBlank() &&
                    it.isVisible &&
                    (!anySolo || it.isSolo) &&
                    it.isActiveAt(timeMs)
            }
            .maxByOrNull { it.zIndex }
    }

    private fun syncMediaPlayers(playheadMs: Long, isPlaying: Boolean) {
        val state = _uiState.value
        val layers = state.project.layers
        val activeVideo = activeVideoLayerAt(playheadMs, layers)
        val anyVisualSolo = layers.any { it.type != LayerType.AUDIO && it.isSolo }
        val masterVol = state.project.masterVolume.coerceIn(0f, 1f)
        videoPreviewController.syncVideoPreview(
            activeVideoLayer = activeVideo,
            playheadMs = playheadMs,
            isPlaying = isPlaying,
            anySolo = anyVisualSolo,
            playbackSpeed = state.playbackSpeed,
            masterVolume = masterVol
        )
        audioController.syncPlayback(
            layers = layers,
            playheadMs = playheadMs,
            isPlaying = isPlaying,
            playbackSpeed = state.playbackSpeed,
            excludeVideoLayerId = activeVideo?.id,
            masterVolume = masterVol
        )
    }

    fun togglePlayPause() {
        val currentlyPlaying = _uiState.value.isPlaying
        if (!currentlyPlaying) {
            val dur = _uiState.value.project.durationMs
            val startAt = if (_uiState.value.playheadMs >= dur - 20L) 0L else _uiState.value.playheadMs
            _uiState.update { it.copy(isPlaying = true, playheadMs = startAt) }
            syncMediaPlayers(startAt, true)
        } else {
            _uiState.update { it.copy(isPlaying = false) }
            videoPreviewController.pause()
            audioController.pauseAll()
        }
    }

    fun pausePlayback() {
        if (_uiState.value.isPlaying) {
            _uiState.update { it.copy(isPlaying = false) }
            videoPreviewController.pause()
            audioController.pauseAll()
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _uiState.update { it.copy(playbackSpeed = clamped) }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    fun onPlaybackTick(deltaMs: Long) {
        val state = _uiState.value
        if (!state.isPlaying) return
        val scaledDelta = (deltaMs * state.playbackSpeed).toLong().coerceAtLeast(1L)
        val next = state.playheadMs + scaledDelta
        if (next >= state.project.durationMs) {
            _uiState.update { it.copy(playheadMs = 0L) }
            syncMediaPlayers(0L, true)
        } else {
            _uiState.update { it.copy(playheadMs = next) }
            syncMediaPlayers(next, true)
        }
    }

    fun seekTo(timeMs: Long) {
        val clamped = timeMs.coerceIn(0L, _uiState.value.project.durationMs)
        _uiState.update { it.copy(playheadMs = clamped) }
        syncMediaPlayers(clamped, _uiState.value.isPlaying)
    }

    fun stepFrame(direction: Int) {
        pausePlayback()
        val fps = _uiState.value.project.fps.coerceAtLeast(1)
        val stepMs = (1000L / fps).coerceAtLeast(16L)
        seekTo(_uiState.value.playheadMs + direction * stepMs)
    }

    fun setTimelineZoom(zoom: Float) {
        _uiState.update { it.copy(timelineZoom = zoom.coerceIn(0.4f, 3.5f)) }
    }

    fun toggleGuides() {
        _uiState.update { it.copy(showGuides = !it.showGuides) }
    }

    fun toggleAutoKeyframe() {
        _uiState.update { it.copy(autoKeyframe = !it.autoKeyframe) }
    }

    fun setInspectorTab(tab: InspectorTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun setTransformMode3D(is3D: Boolean) {
        _uiState.update { it.copy(transformMode3D = is3D) }
    }

    fun toggleLinkScale() {
        _uiState.update { it.copy(linkScale = !it.linkScale) }
    }

    // --- Project Properties ---

    fun renameProject(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        commitProjectEdit { it.copy(name = clean) }
    }

    fun setProjectDuration(durationMs: Long, recordUndo: Boolean = true) {
        val clamped = durationMs.coerceIn(2000L, 120_000L)
        commitProjectEdit(recordUndo = recordUndo) { proj ->
            proj.copy(durationMs = clamped)
        }
        if (_uiState.value.playheadMs > clamped) {
            seekTo(clamped)
        }
    }

    fun setProjectBackgroundColor(colorHex: Long) {
        commitProjectEdit { it.copy(backgroundColorHex = colorHex) }
    }

    // --- Media Import & Layer Creation ---

    fun importMedia(uri: Uri, requestedType: LayerType) {
        val projectId = _uiState.value.project.id
        viewModelScope.launch {
            _uiState.update { it.copy(statusBanner = "Importing ${requestedType.label.lowercase()}...") }
            val result = mediaManager.importMediaResult(projectId, uri, requestedType)
            val meta = when (result) {
                is com.example.engine.MediaImportResult.Success -> result.metadata
                is com.example.engine.MediaImportResult.Error -> {
                    _uiState.update { it.copy(statusBanner = result.message) }
                    return@launch
                }
            }
            addImportedMediaToTimelineInternal(meta)
        }
    }

    fun addImportedMediaAssetToTimeline(meta: ImportedMediaMetadata) {
        addImportedMediaToTimelineInternal(meta)
    }

    private fun addImportedMediaToTimelineInternal(meta: ImportedMediaMetadata) {
        val startAt = _uiState.value.playheadMs
        val clipEnd = (startAt + meta.durationMs).coerceAtLeast(startAt + 500L)
        val newLayerId = UUID.randomUUID().toString()

        commitProjectEdit { proj ->
            val nextZ = (proj.layers.maxOfOrNull { it.zIndex } ?: -1) + 1
            val newLayer = MotionLayer(
                id = newLayerId,
                name = meta.displayName.take(24),
                type = meta.layerType,
                startTimeMs = startAt,
                endTimeMs = clipEnd,
                mediaPath = meta.localPath,
                mediaTrimStartMs = 0L,
                mediaDurationMs = meta.durationMs,
                mediaWidth = meta.width,
                mediaHeight = meta.height,
                waveformSamples = meta.waveformSamples,
                zIndex = nextZ
            )
            proj.copy(
                durationMs = max(proj.durationMs, clipEnd),
                layers = proj.layers + newLayer
            )
        }
        val refreshedBin = mediaManager.listProjectMedia(_uiState.value.project.id, _uiState.value.project.layers)
        _uiState.update {
            it.copy(
                selectedLayerId = newLayerId,
                projectMediaBin = refreshedBin,
                statusBanner = "Added ${meta.layerType.label}: ${meta.fileName}"
            )
        }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    fun addShapeLayer(shapeType: ShapeType = ShapeType.ROUNDED_CARD) {
        val startAt = _uiState.value.playheadMs
        val projectDur = _uiState.value.project.durationMs
        val endAt = min(projectDur, startAt + 4000L).coerceAtLeast(startAt + 1000L)
        val newId = UUID.randomUUID().toString()
        commitProjectEdit { proj ->
            val nextZ = (proj.layers.maxOfOrNull { it.zIndex } ?: -1) + 1
            val layer = MotionLayer(
                id = newId,
                name = shapeType.label,
                type = LayerType.SHAPE,
                startTimeMs = startAt,
                endTimeMs = max(endAt, startAt + 1000L),
                zIndex = nextZ,
                shapeType = shapeType,
                colorHex = 0xFF8B5CF6L,
                secondaryColorHex = 0xFF3B82F6L
            )
            proj.copy(
                durationMs = max(proj.durationMs, layer.endTimeMs),
                layers = proj.layers + layer
            )
        }
        _uiState.update { it.copy(selectedLayerId = newId, statusBanner = "Added ${shapeType.label}") }
    }

    fun addTextLayer(initialText: String = "MASTER MOTION") {
        val startAt = _uiState.value.playheadMs
        val projectDur = _uiState.value.project.durationMs
        val endAt = min(projectDur, startAt + 4000L).coerceAtLeast(startAt + 1000L)
        val newId = UUID.randomUUID().toString()
        commitProjectEdit { proj ->
            val nextZ = (proj.layers.maxOfOrNull { it.zIndex } ?: -1) + 1
            val layer = MotionLayer(
                id = newId,
                name = "Text Title",
                type = LayerType.TEXT,
                startTimeMs = startAt,
                endTimeMs = max(endAt, startAt + 1000L),
                zIndex = nextZ,
                textContent = initialText,
                colorHex = 0xFFFFFFFFL,
                secondaryColorHex = 0xFF38BDF8L
            )
            proj.copy(
                durationMs = max(proj.durationMs, layer.endTimeMs),
                layers = proj.layers + layer
            )
        }
        _uiState.update { it.copy(selectedLayerId = newId, statusBanner = "Added Text layer") }
    }

    // --- Layer Management ---

    fun selectLayer(layerId: String?) {
        _uiState.update { it.copy(selectedLayerId = layerId) }
    }

    fun toggleLayerVisibility(layerId: String) {
        updateLayer(layerId) { it.copy(isVisible = !it.isVisible) }
    }

    fun toggleLayerLock(layerId: String) {
        updateLayer(layerId) { it.copy(isLocked = !it.isLocked) }
    }

    fun toggleLayerMute(layerId: String) {
        updateLayer(layerId) { it.copy(isMuted = !it.isMuted) }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    fun toggleLayerSolo(layerId: String) {
        updateLayer(layerId) { it.copy(isSolo = !it.isSolo) }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    fun moveLayerZOrder(layerId: String, delta: Int) {
        commitProjectEdit { proj ->
            val sorted = proj.layers.sortedBy { it.zIndex }.toMutableList()
            val idx = sorted.indexOfFirst { it.id == layerId }
            if (idx < 0) return@commitProjectEdit proj
            val targetIdx = (idx + delta).coerceIn(0, sorted.lastIndex)
            if (idx == targetIdx) return@commitProjectEdit proj
            val moved = sorted.removeAt(idx)
            sorted.add(targetIdx, moved)
            val reindexed = sorted.mapIndexed { index, layer -> layer.copy(zIndex = index) }
            proj.copy(layers = reindexed)
        }
    }

    /**
     * Reorders a layer based on timeline visual row index (0 = top-most / highest zIndex).
     */
    fun reorderLayerToVisualIndex(layerId: String, targetVisualIndex: Int) {
        commitProjectEdit { proj ->
            val descending = proj.layers.sortedByDescending { it.zIndex }.toMutableList()
            val currentIdx = descending.indexOfFirst { it.id == layerId }
            if (currentIdx < 0) return@commitProjectEdit proj
            val clampedTarget = targetVisualIndex.coerceIn(0, descending.lastIndex)
            if (currentIdx == clampedTarget) return@commitProjectEdit proj
            val moved = descending.removeAt(currentIdx)
            descending.add(clampedTarget, moved)
            val count = descending.size
            val reindexed = descending.mapIndexed { visualIdx, layer ->
                layer.copy(zIndex = (count - 1) - visualIdx)
            }
            proj.copy(layers = reindexed)
        }
    }

    fun duplicateLayer(layerId: String) {
        val newId = UUID.randomUUID().toString()
        commitProjectEdit { proj ->
            val target = proj.layers.firstOrNull { it.id == layerId } ?: return@commitProjectEdit proj
            val nextZ = (proj.layers.maxOfOrNull { it.zIndex } ?: -1) + 1
            val copy = target.copy(
                id = newId,
                name = "${target.name} Copy",
                zIndex = nextZ,
                baseTransform = target.baseTransform.copy(
                    posX = (target.baseTransform.posX + 0.08f).coerceIn(-1f, 1f),
                    posY = (target.baseTransform.posY + 0.08f).coerceIn(-1f, 1f)
                )
            )
            proj.copy(layers = proj.layers + copy)
        }
        _uiState.update { it.copy(selectedLayerId = newId) }
    }

    fun deleteLayer(layerId: String) {
        commitProjectEdit { proj ->
            proj.copy(layers = proj.layers.filterNot { it.id == layerId })
        }
    }

    fun renameLayer(layerId: String, name: String) {
        val clean = name.trim()
        if (clean.isNotEmpty()) {
            updateLayer(layerId) { it.copy(name = clean) }
        }
    }

    fun updateTextContent(layerId: String, text: String, textSizeSp: Float? = null) {
        updateLayer(layerId) { layer ->
            layer.copy(
                textContent = text,
                textSizeSp = textSizeSp ?: layer.textSizeSp
            )
        }
    }

    fun updateLayerColors(layerId: String, primaryHex: Long, secondaryHex: Long) {
        updateLayer(layerId) { it.copy(colorHex = primaryHex, secondaryColorHex = secondaryHex) }
    }

    fun updateLayerBlendMode(layerId: String, blendMode: BlendModeType) {
        updateLayer(layerId) { it.copy(blendMode = blendMode) }
    }

    fun updateShapeType(layerId: String, shapeType: ShapeType) {
        updateLayer(layerId) { it.copy(shapeType = shapeType) }
    }

    // --- Trimming & Splitting ---

    fun trimLayer(layerId: String, newStartMs: Long, newEndMs: Long, recordUndo: Boolean = true) {
        val minLen = 250L
        val projDur = _uiState.value.project.durationMs
        val clampedStart = newStartMs.coerceIn(0L, projDur - minLen)
        val clampedEnd = newEndMs.coerceIn(clampedStart + minLen, projDur)
        commitProjectEdit(recordUndo = recordUndo) { proj ->
            proj.copy(
                layers = proj.layers.map { l ->
                    if (l.id == layerId && !l.isLocked) {
                        val deltaStart = clampedStart - l.startTimeMs
                        val nextMediaTrim = if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) {
                            (l.mediaTrimStartMs + deltaStart).coerceIn(0L, max(0L, l.mediaDurationMs - minLen))
                        } else {
                            l.mediaTrimStartMs
                        }
                        l.copy(
                            startTimeMs = clampedStart,
                            endTimeMs = clampedEnd,
                            mediaTrimStartMs = nextMediaTrim
                        )
                    } else l
                }
            )
        }
    }

    fun trimStartToPlayhead(layerId: String) {
        val layer = _uiState.value.project.layers.firstOrNull { it.id == layerId } ?: return
        val playhead = _uiState.value.playheadMs
        if (playhead < layer.endTimeMs - 250L) {
            trimLayer(layerId, playhead, layer.endTimeMs)
        }
    }

    fun trimEndToPlayhead(layerId: String) {
        val layer = _uiState.value.project.layers.firstOrNull { it.id == layerId } ?: return
        val playhead = _uiState.value.playheadMs
        if (playhead > layer.startTimeMs + 250L) {
            trimLayer(layerId, layer.startTimeMs, playhead)
        }
    }

    fun splitLayerAtPlayhead(layerId: String) {
        val layer = _uiState.value.project.layers.firstOrNull { it.id == layerId } ?: return
        if (layer.isLocked) return
        val splitAt = _uiState.value.playheadMs
        if (splitAt <= layer.startTimeMs + 200L || splitAt >= layer.endTimeMs - 200L) {
            _uiState.update { it.copy(statusBanner = "Move playhead inside clip to split") }
            return
        }
        val rightId = UUID.randomUUID().toString()
        commitProjectEdit { proj ->
            val nextZ = (proj.layers.maxOfOrNull { it.zIndex } ?: 0) + 1
            val leftPart = layer.copy(endTimeMs = splitAt)
            val rightOffset = splitAt - layer.startTimeMs
            val rightPart = layer.copy(
                id = rightId,
                name = "${layer.name} (2)",
                startTimeMs = splitAt,
                mediaTrimStartMs = layer.mediaTrimStartMs + rightOffset,
                zIndex = nextZ
            )
            proj.copy(layers = proj.layers.map { if (it.id == layerId) leftPart else it } + rightPart)
        }
        _uiState.update { it.copy(selectedLayerId = rightId, statusBanner = "Clip split at playhead") }
    }

    fun setLayerVolume(layerId: String, volume: Float, recordUndo: Boolean = false) {
        updateLayer(layerId, recordUndo = recordUndo) { it.copy(volume = volume.coerceIn(0f, 1f)) }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    fun setMasterVolume(volume: Float, recordUndo: Boolean = false) {
        val clamped = volume.coerceIn(0f, 1f)
        commitProjectEdit(recordUndo = recordUndo) { it.copy(masterVolume = clamped) }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    // --- Voiceover Recording ---

    fun onVoiceoverPermissionDenied() {
        _uiState.update {
            it.copy(
                voiceoverState = it.voiceoverState.copy(permissionDenied = true),
                statusBanner = "Microphone permission is required to record voiceover"
            )
        }
    }

    fun startVoiceoverRecording() {
        if (_uiState.value.voiceoverState.isRecording) return
        pausePlayback()
        val projectId = _uiState.value.project.id
        val started = voiceoverRecorder.startRecording(projectId)
        if (!started) {
            _uiState.update {
                it.copy(
                    voiceoverState = VoiceoverRecorderUiState(isRecording = false),
                    statusBanner = "Unable to start microphone recorder on this device"
                )
            }
            return
        }
        _uiState.update {
            it.copy(
                voiceoverState = VoiceoverRecorderUiState(
                    isRecording = true,
                    elapsedMs = 0L,
                    currentLevel = 0.15f,
                    liveBars = listOf(0.15f),
                    permissionDenied = false
                ),
                statusBanner = "Recording voiceover..."
            )
        }
        voiceoverTickerJob?.cancel()
        voiceoverTickerJob = viewModelScope.launch {
            while (voiceoverRecorder.isRecording) {
                val level = voiceoverRecorder.pollAmplitude()
                val elapsed = voiceoverRecorder.elapsedMs()
                _uiState.update { state ->
                    state.copy(
                        voiceoverState = state.voiceoverState.copy(
                            elapsedMs = elapsed,
                            currentLevel = level,
                            liveBars = (state.voiceoverState.liveBars + level).takeLast(28)
                        )
                    )
                }
                delay(80L)
            }
        }
    }

    fun stopVoiceoverRecording() {
        if (!_uiState.value.voiceoverState.isRecording && !voiceoverRecorder.isRecording) return
        voiceoverTickerJob?.cancel()
        voiceoverTickerJob = null
        val recorded = voiceoverRecorder.stopRecording()
        _uiState.update { it.copy(voiceoverState = VoiceoverRecorderUiState()) }
        if (recorded == null) {
            _uiState.update { it.copy(statusBanner = "Voiceover clip was too short or empty") }
            return
        }
        addRecordedVoiceoverToTimeline(
            filePath = recorded.filePath,
            displayName = recorded.displayName,
            durationMs = recorded.durationMs,
            waveformSamples = recorded.waveformSamples
        )
    }

    fun cancelVoiceoverRecording() {
        voiceoverTickerJob?.cancel()
        voiceoverTickerJob = null
        voiceoverRecorder.cancelAndRelease()
        _uiState.update {
            it.copy(
                voiceoverState = VoiceoverRecorderUiState(),
                statusBanner = "Voiceover recording cancelled"
            )
        }
    }

    fun addRecordedVoiceoverToTimeline(
        filePath: String,
        displayName: String = "Voiceover",
        durationMs: Long,
        waveformSamples: List<Float>
    ) {
        val safeDuration = durationMs.coerceAtLeast(500L)
        val startAt = _uiState.value.playheadMs
        val clipEnd = startAt + safeDuration
        val newLayerId = UUID.randomUUID().toString()

        commitProjectEdit { proj ->
            val nextZ = (proj.layers.maxOfOrNull { it.zIndex } ?: -1) + 1
            val layer = MotionLayer(
                id = newLayerId,
                name = displayName.take(24),
                type = LayerType.AUDIO,
                startTimeMs = startAt,
                endTimeMs = clipEnd,
                mediaPath = filePath,
                mediaTrimStartMs = 0L,
                mediaDurationMs = safeDuration,
                volume = 1f,
                waveformSamples = if (waveformSamples.isNotEmpty()) waveformSamples else List(32) { 0.45f },
                colorHex = 0xFFF59E0BL,
                secondaryColorHex = 0xFFFB7185L,
                zIndex = nextZ
            )
            proj.copy(
                durationMs = max(proj.durationMs, clipEnd),
                layers = proj.layers + layer
            )
        }
        val refreshedBin = mediaManager.listProjectMedia(_uiState.value.project.id, _uiState.value.project.layers)
        _uiState.update {
            it.copy(
                selectedLayerId = newLayerId,
                projectMediaBin = refreshedBin,
                statusBanner = "Voiceover added to timeline"
            )
        }
        syncMediaPlayers(_uiState.value.playheadMs, _uiState.value.isPlaying)
    }

    // --- 2D & 3D Transform + Keyframes ---

    fun updateTransformProperty(
        property: AnimatableProperty,
        value: Float,
        recordUndo: Boolean = true
    ) {
        val state = _uiState.value
        val layer = state.selectedLayer ?: return
        if (layer.isLocked) return

        val clamped = value.coerceIn(property.minValue, property.maxValue)
        val playhead = state.playheadMs

        commitProjectEdit(recordUndo = recordUndo) { proj ->
            proj.copy(
                layers = proj.layers.map { l ->
                    if (l.id != layer.id) return@map l
                    val existingTrack = l.keyframesFor(property)
                    val shouldKeyframe = existingTrack.isNotEmpty() || state.autoKeyframe
                    if (shouldKeyframe) {
                        val updatedTrack = KeyframeEvaluator.upsertKeyframe(
                            existing = existingTrack,
                            timeMs = playhead,
                            value = clamped
                        )
                        val tracks = l.keyframeTracks.toMutableMap()
                        tracks[property.name] = updatedTrack
                        // Also keep baseTransform synced if this was the only keyframe
                        val updatedBase = if (updatedTrack.size == 1) {
                            l.baseTransform.withProperty(property, clamped)
                        } else l.baseTransform
                        l.copy(keyframeTracks = tracks, baseTransform = updatedBase)
                    } else {
                        l.copy(baseTransform = l.baseTransform.withProperty(property, clamped))
                    }
                }
            )
        }
    }

    fun updateLinkedScale(newScale: Float, recordUndo: Boolean = true) {
        updateTransformProperty(AnimatableProperty.SCALE_X, newScale, recordUndo)
        updateTransformProperty(AnimatableProperty.SCALE_Y, newScale, recordUndo = false)
    }

    fun applyCanvasGestureTransform(
        deltaPosX: Float,
        deltaPosY: Float,
        scaleFactor: Float = 1f,
        deltaRotationZ: Float = 0f
    ) {
        val state = _uiState.value
        val layer = state.selectedLayer ?: return
        if (layer.isLocked) return
        val playhead = state.playheadMs
        val current = KeyframeEvaluator.evaluateLayerState(layer, playhead).transform

        if (abs(deltaPosX) > 0.0001f) {
            updateTransformProperty(AnimatableProperty.POSITION_X, current.posX + deltaPosX, recordUndo = false)
        }
        if (abs(deltaPosY) > 0.0001f) {
            updateTransformProperty(AnimatableProperty.POSITION_Y, current.posY + deltaPosY, recordUndo = false)
        }
        if (abs(scaleFactor - 1f) > 0.001f) {
            updateTransformProperty(AnimatableProperty.SCALE_X, current.scaleX * scaleFactor, recordUndo = false)
            updateTransformProperty(AnimatableProperty.SCALE_Y, current.scaleY * scaleFactor, recordUndo = false)
        }
        if (abs(deltaRotationZ) > 0.05f) {
            updateTransformProperty(AnimatableProperty.ROTATION_Z, current.rotationZ + deltaRotationZ, recordUndo = false)
        }
    }

    fun toggleKeyframeAtPlayhead(property: AnimatableProperty) {
        val state = _uiState.value
        val layer = state.selectedLayer ?: return
        if (layer.isLocked) return
        val playhead = state.playheadMs

        commitProjectEdit { proj ->
            proj.copy(
                layers = proj.layers.map { l ->
                    if (l.id != layer.id) return@map l
                    val currentKfs = l.keyframesFor(property)
                    val tracks = l.keyframeTracks.toMutableMap()
                    val existingIdx = currentKfs.indexOfFirst { abs(it.timeMs - playhead) <= 40L }
                    if (existingIdx >= 0) {
                        val remaining = currentKfs.toMutableList().apply { removeAt(existingIdx) }
                        if (remaining.isEmpty()) tracks.remove(property.name) else tracks[property.name] = remaining
                    } else {
                        val evaluatedVal = KeyframeEvaluator.evaluateProperty(l, property, playhead)
                        tracks[property.name] = KeyframeEvaluator.upsertKeyframe(
                            existing = currentKfs,
                            timeMs = playhead,
                            value = evaluatedVal
                        )
                    }
                    l.copy(keyframeTracks = tracks)
                }
            )
        }
    }

    fun jumpToAdjacentKeyframe(property: AnimatableProperty, direction: Int) {
        val layer = _uiState.value.selectedLayer ?: return
        val kfs = layer.keyframesFor(property)
        if (kfs.isEmpty()) return
        val now = _uiState.value.playheadMs
        val target = if (direction < 0) {
            kfs.lastOrNull { it.timeMs < now - 40L }
        } else {
            kfs.firstOrNull { it.timeMs > now + 40L }
        }
        if (target != null) {
            pausePlayback()
            seekTo(target.timeMs)
        }
    }

    fun updateCameraDistance(distance: Float, recordUndo: Boolean = false) {
        val layer = _uiState.value.selectedLayer ?: return
        updateLayer(layer.id, recordUndo = recordUndo) {
            it.copy(baseTransform = it.baseTransform.copy(cameraDistance = distance.coerceIn(3f, 28f)))
        }
    }

    fun resetTransform() {
        val layer = _uiState.value.selectedLayer ?: return
        if (layer.isLocked) return
        updateLayer(layer.id) {
            it.copy(baseTransform = TransformValues(), keyframeTracks = emptyMap())
        }
    }

    // --- Graph Editor ---

    fun selectGraphProperty(property: AnimatableProperty) {
        _uiState.update { it.copy(selectedGraphProperty = property, selectedSegmentIndex = 0) }
    }

    fun selectGraphSegment(index: Int) {
        _uiState.update { it.copy(selectedSegmentIndex = index.coerceAtLeast(0)) }
    }

    fun updateSegmentCurve(
        property: AnimatableProperty,
        segmentIndex: Int,
        curve: CubicBezierCurve,
        recordUndo: Boolean = true
    ) {
        val layer = _uiState.value.selectedLayer ?: return
        if (layer.isLocked) return
        commitProjectEdit(recordUndo = recordUndo) { proj ->
            proj.copy(
                layers = proj.layers.map { l ->
                    if (l.id != layer.id) return@map l
                    val kfs = l.keyframesFor(property).toMutableList()
                    if (segmentIndex in 0 until kfs.size - 1) {
                        kfs[segmentIndex] = kfs[segmentIndex].copy(curve = curve)
                        val tracks = l.keyframeTracks.toMutableMap()
                        tracks[property.name] = kfs
                        l.copy(keyframeTracks = tracks)
                    } else l
                }
            )
        }
    }

    // --- Effects & Transitions ---

    fun addEffect(type: EffectType) {
        val layer = _uiState.value.selectedLayer ?: return
        if (layer.isLocked) return
        updateLayer(layer.id) { l ->
            if (l.effects.any { it.type == type }) l
            else l.copy(effects = l.effects + LayerEffect(type = type))
        }
    }

    fun toggleEffect(effectId: String) {
        val layer = _uiState.value.selectedLayer ?: return
        updateLayer(layer.id) { l ->
            l.copy(effects = l.effects.map { fx -> if (fx.id == effectId) fx.copy(enabled = !fx.enabled) else fx })
        }
    }

    fun updateEffectIntensity(effectId: String, intensity: Float, recordUndo: Boolean = false) {
        val layer = _uiState.value.selectedLayer ?: return
        updateLayer(layer.id, recordUndo = recordUndo) { l ->
            l.copy(effects = l.effects.map { fx ->
                if (fx.id == effectId) fx.copy(intensity = intensity.coerceIn(0f, 1f)) else fx
            })
        }
    }

    fun updateChromaKey(
        effectId: String,
        keyColorHex: Long? = null,
        tolerance: Float? = null,
        spillSuppression: Float? = null,
        recordUndo: Boolean = false
    ) {
        val layer = _uiState.value.selectedLayer ?: return
        if (layer.isLocked) return
        updateLayer(layer.id, recordUndo = recordUndo) { l ->
            l.copy(
                effects = l.effects.map { fx ->
                    if (fx.id != effectId) fx
                    else fx.copy(
                        keyColorHex = keyColorHex ?: fx.keyColorHex,
                        intensity = tolerance?.coerceIn(0f, 1f) ?: fx.intensity,
                        spillSuppression = spillSuppression?.coerceIn(0f, 1f) ?: fx.spillSuppression
                    )
                }
            )
        }
    }

    fun removeEffect(effectId: String) {
        val layer = _uiState.value.selectedLayer ?: return
        updateLayer(layer.id) { l ->
            l.copy(effects = l.effects.filterNot { it.id == effectId })
        }
    }

    fun updateInTransition(type: TransitionType, durationMs: Long, recordUndo: Boolean = true) {
        val layer = _uiState.value.selectedLayer ?: return
        updateLayer(layer.id, recordUndo = recordUndo) {
            it.copy(inTransition = LayerTransition(type, durationMs.coerceIn(100L, 2500L)))
        }
    }

    fun updateOutTransition(type: TransitionType, durationMs: Long, recordUndo: Boolean = true) {
        val layer = _uiState.value.selectedLayer ?: return
        updateLayer(layer.id, recordUndo = recordUndo) {
            it.copy(outTransition = LayerTransition(type, durationMs.coerceIn(100L, 2500L)))
        }
    }

    // --- Export ---

    fun startExport(config: ExportConfig) {
        pausePlayback()
        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    exportState = ExportUiState.Running(
                        ExportProgress(0.02f, "Preparing ${config.resolution.badge} ${config.format.label}...")
                    )
                )
            }
            try {
                val result = mediaExporter.export(
                    project = _uiState.value.project,
                    playheadMs = _uiState.value.playheadMs,
                    config = config
                ) { progress ->
                    _uiState.update { it.copy(exportState = ExportUiState.Running(progress)) }
                }
                _uiState.update { it.copy(exportState = ExportUiState.Completed(result)) }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                _uiState.update {
                    it.copy(exportState = ExportUiState.Failed(t.message ?: "Export failed"))
                }
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        exportJob = null
        _uiState.update { it.copy(exportState = ExportUiState.Idle) }
    }

    fun resetExportState() {
        _uiState.update { it.copy(exportState = ExportUiState.Idle) }
    }

    private fun updateLayer(
        layerId: String,
        recordUndo: Boolean = true,
        transform: (MotionLayer) -> MotionLayer
    ) {
        commitProjectEdit(recordUndo = recordUndo) { proj ->
            proj.copy(layers = proj.layers.map { if (it.id == layerId) transform(it) else it })
        }
    }

    override fun onCleared() {
        super.onCleared()
        if (_uiState.value.hasUnsavedChanges) {
            val snapshot = _uiState.value.project
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                runCatching { repository.saveProject(snapshot) }
            }
        }
        voiceoverTickerJob?.cancel()
        voiceoverRecorder.cancelAndRelease()
        videoPreviewController.release()
        audioController.releaseAll()
    }

    class Factory(
        private val projectId: String,
        private val repository: ProjectRepository,
        private val mediaManager: MediaManager,
        private val mediaExporter: MediaExporter
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return EditorViewModel(projectId, repository, mediaManager, mediaExporter) as T
        }
    }
}
