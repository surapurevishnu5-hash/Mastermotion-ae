package com.example.ui.editor

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.LayerType
import com.example.model.ShapeType
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.ExportUiState
import com.example.viewmodel.InspectorTab
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onOpenExportsGallery: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showExportDialog by remember { mutableStateOf(false) }
    var showAddLayerDialog by remember { mutableStateOf(false) }
    var showRenameProjectDialog by remember { mutableStateOf(false) }

    // Android Photo Picker for Video & Image (zero storage permission)
    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importMedia(uri, LayerType.VIDEO)
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.importMedia(uri, LayerType.IMAGE)
    }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importMedia(uri, LayerType.AUDIO)
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.importMedia(uri, LayerType.VIDEO)
    }

    // Real-time Compose frame clock loop during playback
    LaunchedEffect(state.isPlaying) {
        if (state.isPlaying) {
            var lastNanos = 0L
            while (state.isPlaying) {
                withFrameNanos { frameNanos ->
                    if (lastNanos != 0L) {
                        val deltaMs = ((frameNanos - lastNanos) / 1_000_000L).coerceIn(1L, 100L)
                        viewModel.onPlaybackTick(deltaMs)
                    }
                    lastNanos = frameNanos
                }
            }
        }
    }

    // Auto-dismiss transient status banner
    LaunchedEffect(state.statusBanner) {
        if (state.statusBanner != null) {
            delay(2200L)
            viewModel.clearStatusBanner()
        }
    }

    DisposableEffect(viewModel) {
        onDispose {
            viewModel.pausePlayback()
        }
    }

    BackHandler {
        viewModel.pausePlayback()
        viewModel.saveProjectNow(showToastBanner = false)
        onNavigateBack()
    }

    Scaffold(
        containerColor = ObsidianBg,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        if (state.isLoading) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                CircularProgressIndicator(color = ElectricPurple)
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Top Studio Action Bar
            EditorTopBar(
                projectName = state.project.name,
                canUndo = state.canUndo,
                canRedo = state.canRedo,
                hasUnsavedChanges = state.hasUnsavedChanges,
                isSaving = state.isSaving,
                onBack = {
                    viewModel.pausePlayback()
                    viewModel.saveProjectNow(showToastBanner = false)
                    onNavigateBack()
                },
                onRenameClick = { showRenameProjectDialog = true },
                onUndo = viewModel::undo,
                onRedo = viewModel::redo,
                onSave = { viewModel.saveProjectNow(showToastBanner = true) },
                onExportClick = {
                    viewModel.resetExportState()
                    showExportDialog = true
                }
            )

            // Status toast strip
            AnimatedVisibility(visible = state.statusBanner != null) {
                Surface(
                    color = ElectricPurple.copy(alpha = 0.2f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = state.statusBanner.orEmpty(),
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                    )
                }
            }

            // Adaptive Editor Workspace (Compact vertical stack vs Expanded tablet split)
            BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                val isWide = maxWidth >= 840.dp

                if (isWide) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        Column(modifier = Modifier.weight(1.25f).fillMaxHeight()) {
                            PreviewStage(
                                project = state.project,
                                mediaManager = viewModel.mediaManager,
                                selectedLayerId = state.selectedLayerId,
                                playheadMs = state.playheadMs,
                                isPlaying = state.isPlaying,
                                playbackSpeed = state.playbackSpeed,
                                showGuides = state.showGuides,
                                autoKeyframe = state.autoKeyframe,
                                videoPreviewController = viewModel.videoPreviewController,
                                onTogglePlayPause = viewModel::togglePlayPause,
                                onSeekTo = viewModel::seekTo,
                                onStepFrame = viewModel::stepFrame,
                                onChangePlaybackSpeed = viewModel::setPlaybackSpeed,
                                onToggleGuides = viewModel::toggleGuides,
                                onToggleAutoKeyframe = viewModel::toggleAutoKeyframe,
                                onCanvasTransform = { dx, dy, zoom, rot ->
                                    viewModel.applyCanvasGestureTransform(dx, dy, zoom, rot)
                                },
                                onCanvasTransformStart = viewModel::beginTimelineEditSession,
                                onCanvasTransformEnd = viewModel::endTimelineEditSession,
                                modifier = Modifier.weight(0.55f)
                            )

                            TimelinePanel(
                                project = state.project,
                                selectedLayerId = state.selectedLayerId,
                                playheadMs = state.playheadMs,
                                timelineZoom = state.timelineZoom,
                                mediaManager = viewModel.mediaManager,
                                onSeekTo = viewModel::seekTo,
                                onSelectLayer = viewModel::selectLayer,
                                onToggleVisibility = viewModel::toggleLayerVisibility,
                                onTrimLayer = viewModel::trimLayer,
                                onBeginTimelineEdit = viewModel::beginTimelineEditSession,
                                onEndTimelineEdit = viewModel::endTimelineEditSession,
                                onReorderLayer = viewModel::reorderLayerToVisualIndex,
                                onSplitSelected = {
                                    state.selectedLayerId?.let { viewModel.splitLayerAtPlayhead(it) }
                                },
                                onDeleteSelected = {
                                    state.selectedLayerId?.let { viewModel.deleteLayer(it) }
                                },
                                onChangeZoom = viewModel::setTimelineZoom,
                                onAddLayerClick = { showAddLayerDialog = true },
                                modifier = Modifier.weight(0.45f)
                            )
                        }

                        InspectorHost(
                            state = state,
                            viewModel = viewModel,
                            onImportVideo = {
                                videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            },
                            onImportImage = {
                                imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onImportAudio = { audioPicker.launch(arrayOf("audio/*")) },
                            onBrowseMediaFile = { filePicker.launch(arrayOf("video/*", "image/*", "audio/*")) },
                            modifier = Modifier
                                .weight(0.85f)
                                .fillMaxHeight()
                                .border(0.5.dp, StudioBorder)
                        )
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        PreviewStage(
                            project = state.project,
                            mediaManager = viewModel.mediaManager,
                            selectedLayerId = state.selectedLayerId,
                            playheadMs = state.playheadMs,
                            isPlaying = state.isPlaying,
                            playbackSpeed = state.playbackSpeed,
                            showGuides = state.showGuides,
                            autoKeyframe = state.autoKeyframe,
                            videoPreviewController = viewModel.videoPreviewController,
                            onTogglePlayPause = viewModel::togglePlayPause,
                            onSeekTo = viewModel::seekTo,
                            onStepFrame = viewModel::stepFrame,
                            onChangePlaybackSpeed = viewModel::setPlaybackSpeed,
                            onToggleGuides = viewModel::toggleGuides,
                            onToggleAutoKeyframe = viewModel::toggleAutoKeyframe,
                            onCanvasTransform = { dx, dy, zoom, rot ->
                                viewModel.applyCanvasGestureTransform(dx, dy, zoom, rot)
                            },
                            onCanvasTransformStart = viewModel::beginTimelineEditSession,
                            onCanvasTransformEnd = viewModel::endTimelineEditSession,
                            modifier = Modifier.weight(0.34f)
                        )

                        TimelinePanel(
                            project = state.project,
                            selectedLayerId = state.selectedLayerId,
                            playheadMs = state.playheadMs,
                            timelineZoom = state.timelineZoom,
                            mediaManager = viewModel.mediaManager,
                            onSeekTo = viewModel::seekTo,
                            onSelectLayer = viewModel::selectLayer,
                            onToggleVisibility = viewModel::toggleLayerVisibility,
                            onTrimLayer = viewModel::trimLayer,
                            onBeginTimelineEdit = viewModel::beginTimelineEditSession,
                            onEndTimelineEdit = viewModel::endTimelineEditSession,
                            onReorderLayer = viewModel::reorderLayerToVisualIndex,
                            onSplitSelected = {
                                state.selectedLayerId?.let { viewModel.splitLayerAtPlayhead(it) }
                            },
                            onDeleteSelected = {
                                state.selectedLayerId?.let { viewModel.deleteLayer(it) }
                            },
                            onChangeZoom = viewModel::setTimelineZoom,
                            onAddLayerClick = { showAddLayerDialog = true },
                            modifier = Modifier.weight(0.26f)
                        )

                        InspectorHost(
                            state = state,
                            viewModel = viewModel,
                            onImportVideo = {
                                videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            },
                            onImportImage = {
                                imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onImportAudio = { audioPicker.launch(arrayOf("audio/*")) },
                            onBrowseMediaFile = { filePicker.launch(arrayOf("video/*", "image/*", "audio/*")) },
                            modifier = Modifier.weight(0.40f)
                        )
                    }
                }
            }
        }
    }

    if (showAddLayerDialog) {
        AddLayerModal(
            onDismiss = { showAddLayerDialog = false },
            onImportVideo = {
                showAddLayerDialog = false
                videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            },
            onImportImage = {
                showAddLayerDialog = false
                imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onImportAudio = {
                showAddLayerDialog = false
                audioPicker.launch(arrayOf("audio/*"))
            },
            onBrowseMediaFile = {
                showAddLayerDialog = false
                filePicker.launch(arrayOf("video/*", "image/*", "audio/*"))
            },
            onAddShape = {
                showAddLayerDialog = false
                viewModel.addShapeLayer(ShapeType.ROUNDED_CARD)
            },
            onAddText = {
                showAddLayerDialog = false
                viewModel.addTextLayer()
            }
        )
    }

    if (showExportDialog) {
        ExportDialog(
            project = state.project,
            exportState = state.exportState,
            onStartExport = viewModel::startExport,
            onCancelExport = viewModel::cancelExport,
            onOpenExportsGallery = onOpenExportsGallery,
            onDismiss = {
                if (state.exportState !is ExportUiState.Running) {
                    showExportDialog = false
                    viewModel.resetExportState()
                }
            }
        )
    }

    if (showRenameProjectDialog) {
        var nameInput by remember(state.project.name) { mutableStateOf(state.project.name) }
        AlertDialog(
            onDismissRequest = { showRenameProjectDialog = false },
            containerColor = StudioSurface,
            title = { Text("Rename Composition", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    singleLine = true,
                    label = { Text("Project Name") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.renameProject(nameInput)
                    showRenameProjectDialog = false
                }) {
                    Text("Save", color = ElectricPurple)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameProjectDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun EditorTopBar(
    projectName: String,
    canUndo: Boolean,
    canRedo: Boolean,
    hasUnsavedChanges: Boolean,
    isSaving: Boolean,
    onBack: () -> Unit,
    onRenameClick: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSave: () -> Unit,
    onExportClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioSurface)
            .border(0.5.dp, StudioBorder)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(40.dp).testTag("editor_back_button")
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Projects", tint = TextPrimary)
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onRenameClick)
                .padding(horizontal = 4.dp)
        ) {
            Text(
                text = projectName,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = when {
                    isSaving -> "Saving..."
                    hasUnsavedChanges -> "Edited"
                    else -> "Saved"
                },
                style = MaterialTheme.typography.labelSmall,
                color = if (hasUnsavedChanges) CyberCyan else SuccessGreen
            )
        }

        IconButton(
            onClick = onUndo,
            enabled = canUndo,
            modifier = Modifier.size(36.dp).testTag("undo_button")
        ) {
            Icon(
                Icons.AutoMirrored.Filled.Undo,
                contentDescription = "Undo",
                tint = if (canUndo) TextPrimary else TextSecondary.copy(alpha = 0.35f),
                modifier = Modifier.size(19.dp)
            )
        }

        IconButton(
            onClick = onRedo,
            enabled = canRedo,
            modifier = Modifier.size(36.dp).testTag("redo_button")
        ) {
            Icon(
                Icons.AutoMirrored.Filled.Redo,
                contentDescription = "Redo",
                tint = if (canRedo) TextPrimary else TextSecondary.copy(alpha = 0.35f),
                modifier = Modifier.size(19.dp)
            )
        }

        IconButton(
            onClick = onSave,
            modifier = Modifier.size(36.dp).testTag("save_project_button")
        ) {
            Icon(
                imageVector = if (hasUnsavedChanges) Icons.Filled.Save else Icons.Filled.Check,
                contentDescription = "Save Project",
                tint = if (hasUnsavedChanges) CyberCyan else SuccessGreen,
                modifier = Modifier.size(19.dp)
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.Transparent,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(ElectricPurple, CyberBlue)))
                .clickable(onClick = onExportClick)
                .testTag("export_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Filled.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Export", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun InspectorHost(
    state: com.example.viewmodel.EditorUiState,
    viewModel: EditorViewModel,
    onImportVideo: () -> Unit,
    onImportImage: () -> Unit,
    onImportAudio: () -> Unit,
    onBrowseMediaFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurface)
    ) {
        // Tab Switcher Row
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurfaceElevated)
                .border(0.5.dp, StudioBorder)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            InspectorTab.entries.forEach { tab ->
                val selected = tab == state.activeTab
                val icon = when (tab) {
                    InspectorTab.LAYERS -> Icons.Filled.Layers
                    InspectorTab.TRANSFORM -> Icons.Filled.Tune
                    InspectorTab.GRAPH -> Icons.AutoMirrored.Filled.ShowChart
                    InspectorTab.EFFECTS -> Icons.Filled.AutoFixHigh
                    InspectorTab.TRIM -> Icons.Filled.ContentCut
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (selected) ElectricPurple.copy(alpha = 0.28f) else StudioInspector,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selected) ElectricPurple else StudioBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { viewModel.setInspectorTab(tab) }
                        .testTag("inspector_tab_${tab.name}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (selected) Color.White else TextSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) Color.White else TextSecondary
                        )
                    }
                }
            }
        }

        // Active Inspector Content
        Box(modifier = Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            when (state.activeTab) {
                InspectorTab.LAYERS -> LayerInspectorPanel(
                    layer = state.selectedLayer,
                    mediaManager = viewModel.mediaManager,
                    projectMediaBin = state.projectMediaBin,
                    onAddAssetToTimeline = viewModel::addImportedMediaAssetToTimeline,
                    onImportVideo = onImportVideo,
                    onImportImage = onImportImage,
                    onImportAudio = onImportAudio,
                    onBrowseMediaFile = onBrowseMediaFile,
                    onAddShape = viewModel::addShapeLayer,
                    onAddText = { viewModel.addTextLayer() },
                    onToggleVisibility = viewModel::toggleLayerVisibility,
                    onToggleLock = viewModel::toggleLayerLock,
                    onToggleMute = viewModel::toggleLayerMute,
                    onToggleSolo = viewModel::toggleLayerSolo,
                    onMoveZOrder = viewModel::moveLayerZOrder,
                    onDuplicate = viewModel::duplicateLayer,
                    onDelete = viewModel::deleteLayer,
                    onRenameLayer = viewModel::renameLayer,
                    onUpdateTextContent = { id, text, sizeSp -> viewModel.updateTextContent(id, text, sizeSp) },
                    onUpdateShapeType = viewModel::updateShapeType,
                    onUpdateColors = viewModel::updateLayerColors,
                    onUpdateBlendMode = viewModel::updateLayerBlendMode
                )

                InspectorTab.TRANSFORM -> TransformPanel(
                    layer = state.selectedLayer,
                    playheadMs = state.playheadMs,
                    is3DMode = state.transformMode3D,
                    linkScale = state.linkScale,
                    onSet3DMode = viewModel::setTransformMode3D,
                    onToggleLinkScale = viewModel::toggleLinkScale,
                    onUpdateProperty = { prop, value -> viewModel.updateTransformProperty(prop, value, recordUndo = false) },
                    onUpdateLinkedScale = { s -> viewModel.updateLinkedScale(s, recordUndo = false) },
                    onUpdateCameraDistance = { d -> viewModel.updateCameraDistance(d, recordUndo = false) },
                    onBeginSliderEdit = viewModel::beginTimelineEditSession,
                    onEndSliderEdit = viewModel::endTimelineEditSession,
                    onToggleKeyframe = viewModel::toggleKeyframeAtPlayhead,
                    onJumpKeyframe = viewModel::jumpToAdjacentKeyframe,
                    onResetTransform = viewModel::resetTransform
                )

                InspectorTab.GRAPH -> GraphEditorPanel(
                    layer = state.selectedLayer,
                    selectedProperty = state.selectedGraphProperty,
                    selectedSegmentIndex = state.selectedSegmentIndex,
                    onSelectProperty = viewModel::selectGraphProperty,
                    onSelectSegment = viewModel::selectGraphSegment,
                    onUpdateCurve = viewModel::updateSegmentCurve,
                    onBeginBezierEdit = viewModel::beginTimelineEditSession,
                    onEndBezierEdit = viewModel::endTimelineEditSession
                )

                InspectorTab.EFFECTS -> EffectsTransitionsPanel(
                    layer = state.selectedLayer,
                    playheadMs = state.playheadMs,
                    mediaManager = viewModel.mediaManager,
                    onAddEffect = viewModel::addEffect,
                    onToggleEffect = viewModel::toggleEffect,
                    onUpdateEffectIntensity = { id, intensity -> viewModel.updateEffectIntensity(id, intensity, recordUndo = false) },
                    onUpdateChromaKey = viewModel::updateChromaKey,
                    onBeginSliderEdit = viewModel::beginTimelineEditSession,
                    onEndSliderEdit = viewModel::endTimelineEditSession,
                    onRemoveEffect = viewModel::removeEffect,
                    onUpdateInTransition = { type, dur, record -> viewModel.updateInTransition(type, dur, recordUndo = record) },
                    onUpdateOutTransition = { type, dur, record -> viewModel.updateOutTransition(type, dur, recordUndo = record) }
                )

                InspectorTab.TRIM -> TrimAudioPanel(
                    project = state.project,
                    layer = state.selectedLayer,
                    playheadMs = state.playheadMs,
                    voiceoverState = state.voiceoverState,
                    onTrimLayer = viewModel::trimLayer,
                    onTrimStartToPlayhead = viewModel::trimStartToPlayhead,
                    onTrimEndToPlayhead = viewModel::trimEndToPlayhead,
                    onSplitAtPlayhead = viewModel::splitLayerAtPlayhead,
                    onSetVolume = { id, vol -> viewModel.setLayerVolume(id, vol, recordUndo = false) },
                    onToggleMute = viewModel::toggleLayerMute,
                    onToggleSolo = viewModel::toggleLayerSolo,
                    onSetMasterVolume = { vol -> viewModel.setMasterVolume(vol, recordUndo = false) },
                    onSetProjectDuration = { dur -> viewModel.setProjectDuration(dur, recordUndo = false) },
                    onBeginSliderEdit = viewModel::beginTimelineEditSession,
                    onEndSliderEdit = viewModel::endTimelineEditSession,
                    onStartVoiceover = viewModel::startVoiceoverRecording,
                    onStopVoiceover = viewModel::stopVoiceoverRecording,
                    onCancelVoiceover = viewModel::cancelVoiceoverRecording,
                    onVoiceoverPermissionDenied = viewModel::onVoiceoverPermissionDenied
                )
            }
        }
    }
}

@Composable
private fun AddLayerModal(
    onDismiss: () -> Unit,
    onImportVideo: () -> Unit,
    onImportImage: () -> Unit,
    onImportAudio: () -> Unit,
    onBrowseMediaFile: () -> Unit,
    onAddShape: () -> Unit,
    onAddText: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface,
        title = { Text("Add Layer to Timeline", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ModalSourceRow("Import Video (MP4 / MOV)", Icons.Filled.Videocam, onImportVideo, "modal_import_video")
                ModalSourceRow("Import Image (PNG / JPG)", Icons.Filled.Image, onImportImage, "modal_import_image")
                ModalSourceRow("Import Audio (MP3 / M4A / WAV)", Icons.Filled.Audiotrack, onImportAudio, "modal_import_audio")
                ModalSourceRow("Browse Files (Video / Image / Audio)", Icons.Filled.FolderOpen, onBrowseMediaFile, "modal_browse_files")
                ModalSourceRow("Add 2D/3D Vector Shape", Icons.Filled.Category, onAddShape, "modal_add_shape")
                ModalSourceRow("Add Kinetic Text Title", Icons.Filled.TextFields, onAddText, "modal_add_text")
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun ModalSourceRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = StudioSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Icon(icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
        }
    }
}
