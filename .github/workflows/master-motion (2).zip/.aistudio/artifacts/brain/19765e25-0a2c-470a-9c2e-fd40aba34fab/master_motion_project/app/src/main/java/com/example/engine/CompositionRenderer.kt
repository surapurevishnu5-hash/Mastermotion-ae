package com.example.engine

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.example.model.BlendModeType
import com.example.model.EffectType
import com.example.model.LayerEffect
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.MotionProject
import com.example.model.ShapeType
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object CompositionRenderer {

    fun renderToBitmap(
        project: MotionProject,
        timeMs: Long,
        width: Int,
        height: Int,
        mediaManager: MediaManager?,
        selectedLayerId: String? = null,
        showGuides: Boolean = false,
        exactVideoFrames: Boolean = false
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width.coerceAtLeast(2), height.coerceAtLeast(2), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        renderToCanvas(
            canvas = canvas,
            project = project,
            timeMs = timeMs,
            width = width,
            height = height,
            mediaManager = mediaManager,
            selectedLayerId = selectedLayerId,
            showGuides = showGuides,
            exactVideoFrames = exactVideoFrames
        )
        return bitmap
    }

    fun renderToCanvas(
        canvas: Canvas,
        project: MotionProject,
        timeMs: Long,
        width: Int,
        height: Int,
        mediaManager: MediaManager?,
        selectedLayerId: String? = null,
        showGuides: Boolean = false,
        exactVideoFrames: Boolean = false,
        drawBackground: Boolean = true,
        layerPredicate: (MotionLayer) -> Boolean = { true }
    ) {
        val w = width.toFloat().coerceAtLeast(2f)
        val h = height.toFloat().coerceAtLeast(2f)

        // 1. Background
        if (drawBackground) {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = project.backgroundColorHex.toInt()
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, w, h, bgPaint)

            // Subtle studio guide grid in editor preview
            if (showGuides) {
                drawStudioGuideGrid(canvas, w, h)
            }
        }

        val visualLayers = project.layers
            .filter { it.type != LayerType.AUDIO }
            .sortedBy { it.zIndex }

        val anySolo = visualLayers.any { it.isSolo }

        // 2. Render each active layer in z-order
        for (layer in visualLayers) {
            if (!layerPredicate(layer)) continue
            if (anySolo && !layer.isSolo) continue
            val evaluated = KeyframeEvaluator.evaluateLayerState(layer, timeMs)
            if (!evaluated.isActive || evaluated.transform.opacity <= 0.005f) continue

            drawLayer(
                canvas = canvas,
                layer = layer,
                evaluated = evaluated,
                timeMs = timeMs,
                canvasW = w,
                canvasH = h,
                mediaManager = mediaManager,
                isSelected = showGuides && layer.id == selectedLayerId,
                exactVideoFrames = exactVideoFrames
            )
        }
    }

    private fun drawStudioGuideGrid(canvas: Canvas, w: Float, h: Float) {
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(24, 139, 92, 246)
            strokeWidth = max(1f, w * 0.0015f)
            style = Paint.Style.STROKE
        }
        val cols = 6
        val rows = 6
        for (i in 1 until cols) {
            val x = w * i / cols
            canvas.drawLine(x, 0f, x, h, gridPaint)
        }
        for (j in 1 until rows) {
            val y = h * j / rows
            canvas.drawLine(0f, y, w, y, gridPaint)
        }
        val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(40, 56, 189, 248)
            strokeWidth = max(1f, w * 0.002f)
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }
        canvas.drawLine(w / 2f, 0f, w / 2f, h, centerPaint)
        canvas.drawLine(0f, h / 2f, w, h / 2f, centerPaint)
    }

    private fun drawLayer(
        canvas: Canvas,
        layer: MotionLayer,
        evaluated: EvaluatedLayerState,
        timeMs: Long,
        canvasW: Float,
        canvasH: Float,
        mediaManager: MediaManager?,
        isSelected: Boolean,
        exactVideoFrames: Boolean
    ) {
        val tr = evaluated.transform
        val layerBox = computeBaseLayerSize(layer, canvasW, canvasH, mediaManager)
        val boxW = layerBox.first
        val boxH = layerBox.second

        // Prepare 2D + 3D Matrix via android.graphics.Camera
        val camera = Camera()
        val matrix = Matrix()

        camera.save()
        camera.setLocation(0f, 0f, -tr.cameraDistance.coerceAtLeast(2f))
        camera.translate(0f, 0f, -tr.depthZ * min(canvasW, canvasH) * 0.45f)
        camera.rotateX(tr.rotationX)
        camera.rotateY(tr.rotationY)
        camera.rotateZ(-tr.rotationZ)
        camera.getMatrix(matrix)
        camera.restore()

        matrix.preScale(tr.scaleX, tr.scaleY)
        val centerX = canvasW / 2f + tr.posX * (canvasW / 2f)
        val centerY = canvasH / 2f + tr.posY * (canvasH / 2f)
        matrix.postTranslate(centerX, centerY)

        val saveCount = canvas.save()
        canvas.concat(matrix)

        // Apply wipe transition clipping if active
        if (evaluated.wipeProgress < 0.999f) {
            val halfW = boxW / 2f
            val halfH = boxH / 2f
            val wipeRight = -halfW + boxW * evaluated.wipeProgress
            canvas.clipRect(-halfW * 1.3f, -halfH * 1.3f, wipeRight, halfH * 1.3f)
        }

        val activeEffects = layer.effects.filter { it.enabled }
        val colorFilter = buildColorMatrixFilter(activeEffects)
        val chromaKeyEffect = activeEffects.firstOrNull { it.type == EffectType.CHROMA_KEY }
        val glowEffect = activeEffects.firstOrNull { it.type == EffectType.GLOW }
        val blurEffect = activeEffects.firstOrNull { it.type == EffectType.BLUR }
        val vignetteEffect = activeEffects.firstOrNull { it.type == EffectType.VIGNETTE }
        val pixelateEffect = activeEffects.firstOrNull { it.type == EffectType.PIXELATE }

        val alphaInt = (tr.opacity * 255f).toInt().coerceIn(0, 255)
        val blendXfermode = when (layer.blendMode) {
            BlendModeType.NORMAL -> null
            BlendModeType.ADD -> PorterDuffXfermode(PorterDuff.Mode.ADD)
            BlendModeType.SCREEN -> PorterDuffXfermode(PorterDuff.Mode.SCREEN)
            BlendModeType.MULTIPLY -> PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
        }

        val halfW = boxW / 2f
        val halfH = boxH / 2f
        val localRect = RectF(-halfW, -halfH, halfW, halfH)

        when (layer.type) {
            LayerType.SHAPE -> {
                drawShapeLayer(
                    canvas = canvas,
                    layer = layer,
                    rect = localRect,
                    alphaInt = alphaInt,
                    colorFilter = colorFilter,
                    xfermode = blendXfermode,
                    glowEffect = glowEffect,
                    blurEffect = blurEffect
                )
            }
            LayerType.TEXT -> {
                drawTextLayer(
                    canvas = canvas,
                    layer = layer,
                    canvasW = canvasW,
                    alphaInt = alphaInt,
                    colorFilter = colorFilter,
                    xfermode = blendXfermode,
                    glowEffect = glowEffect,
                    blurEffect = blurEffect
                )
            }
            LayerType.IMAGE -> {
                val targetDim = max(canvasW, canvasH).toInt().let {
                    if (exactVideoFrames) it.coerceAtLeast(720) else it.coerceIn(480, 1080)
                }
                val bmp = layer.mediaPath?.let { path ->
                    mediaManager?.getImageBitmap(path, maxDimension = targetDim)
                }
                drawBitmapLayer(
                    canvas = canvas,
                    bitmap = bmp,
                    rect = localRect,
                    alphaInt = alphaInt,
                    colorFilter = colorFilter,
                    xfermode = blendXfermode,
                    chromaKeyEffect = chromaKeyEffect,
                    glowEffect = glowEffect,
                    blurEffect = blurEffect,
                    pixelateEffect = pixelateEffect,
                    useChromaCache = !exactVideoFrames,
                    fallbackLabel = layer.name,
                    fallbackColor = layer.colorHex.toInt()
                )
            }
            LayerType.VIDEO -> {
                val mediaTime = (layer.mediaTrimStartMs + (timeMs - layer.startTimeMs)).coerceAtLeast(0L)
                val targetDim = max(canvasW, canvasH).toInt().let {
                    if (exactVideoFrames) it.coerceAtLeast(720) else it.coerceIn(420, 720)
                }
                val bmp = layer.mediaPath?.let { path ->
                    mediaManager?.getVideoFrame(
                        path = path,
                        mediaTimeMs = mediaTime,
                        exactFrame = exactVideoFrames,
                        maxDimension = targetDim
                    )
                }
                drawBitmapLayer(
                    canvas = canvas,
                    bitmap = bmp,
                    rect = localRect,
                    alphaInt = alphaInt,
                    colorFilter = colorFilter,
                    xfermode = blendXfermode,
                    chromaKeyEffect = chromaKeyEffect,
                    glowEffect = glowEffect,
                    blurEffect = blurEffect,
                    pixelateEffect = pixelateEffect,
                    useChromaCache = !exactVideoFrames,
                    fallbackLabel = layer.name,
                    fallbackColor = layer.colorHex.toInt()
                )
            }
            LayerType.AUDIO -> Unit
        }

        // Vignette overlay if applied
        if (vignetteEffect != null && vignetteEffect.intensity > 0.01f) {
            val radius = max(halfW, halfH) * 1.15f
            val vigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    0f, 0f, radius.coerceAtLeast(10f),
                    intArrayOf(
                        Color.TRANSPARENT,
                        Color.argb((vignetteEffect.intensity * alphaInt * 0.85f).toInt().coerceIn(0, 255), 8, 8, 16)
                    ),
                    floatArrayOf(0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(localRect, vigPaint)
        }

        // Selection Gizmo in Editor Preview
        if (isSelected) {
            drawSelectionGizmo(canvas, localRect, canvasW)
        }

        canvas.restoreToCount(saveCount)
    }

    private fun computeBaseLayerSize(
        layer: MotionLayer,
        canvasW: Float,
        canvasH: Float,
        mediaManager: MediaManager?
    ): Pair<Float, Float> {
        val base = min(canvasW, canvasH)
        return when (layer.type) {
            LayerType.SHAPE -> (base * 0.42f) to (base * 0.42f)
            LayerType.TEXT -> (canvasW * 0.72f) to (base * 0.24f)
            LayerType.IMAGE, LayerType.VIDEO -> {
                val mw = layer.mediaWidth
                val mh = layer.mediaHeight
                if (mw > 0 && mh > 0) {
                    val mediaRatio = mw.toFloat() / mh.toFloat()
                    val targetH = canvasH * 0.85f
                    val targetW = targetH * mediaRatio
                    if (targetW > canvasW * 0.9f) {
                        (canvasW * 0.9f) to ((canvasW * 0.9f) / mediaRatio)
                    } else {
                        targetW to targetH
                    }
                } else {
                    (canvasW * 0.75f) to (canvasH * 0.75f)
                }
            }
            LayerType.AUDIO -> 0f to 0f
        }
    }

    private fun drawShapeLayer(
        canvas: Canvas,
        layer: MotionLayer,
        rect: RectF,
        alphaInt: Int,
        colorFilter: ColorMatrixColorFilter?,
        xfermode: PorterDuffXfermode?,
        glowEffect: LayerEffect?,
        blurEffect: LayerEffect?
    ) {
        val path = buildShapePath(layer.shapeType, rect)
        val primary = layer.colorHex.toInt()
        val secondary = layer.secondaryColorHex.toInt()

        if (glowEffect != null && glowEffect.intensity > 0.01f) {
            val glowRadius = (min(rect.width(), rect.height()) * 0.14f * glowEffect.intensity).coerceAtLeast(4f)
            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = primary
                alpha = (alphaInt * 0.65f * glowEffect.intensity).toInt().coerceIn(0, 255)
                maskFilter = BlurMaskFilter(glowRadius, BlurMaskFilter.Blur.OUTER)
            }
            canvas.drawPath(path, glowPaint)
        }

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                primary, secondary, Shader.TileMode.CLAMP
            )
            alpha = alphaInt
            this.colorFilter = colorFilter
            this.xfermode = xfermode
            if (blurEffect != null && blurEffect.intensity > 0.02f) {
                val blurRad = (min(rect.width(), rect.height()) * 0.12f * blurEffect.intensity).coerceAtLeast(2f)
                maskFilter = BlurMaskFilter(blurRad, BlurMaskFilter.Blur.NORMAL)
            }
        }
        canvas.drawPath(path, fillPaint)

        // Subtle crisp studio rim stroke for rounded cards & shapes
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(2f, rect.width() * 0.012f)
            color = Color.argb((alphaInt * 0.45f).toInt().coerceIn(0, 255), 255, 255, 255)
        }
        canvas.drawPath(path, strokePaint)
    }

    private fun buildShapePath(shapeType: ShapeType, rect: RectF): Path {
        val path = Path()
        val w = rect.width()
        val h = rect.height()
        when (shapeType) {
            ShapeType.RECTANGLE -> path.addRect(rect, Path.Direction.CW)
            ShapeType.ROUNDED_CARD -> {
                val radius = min(w, h) * 0.16f
                path.addRoundRect(rect, radius, radius, Path.Direction.CW)
            }
            ShapeType.CIRCLE -> {
                val r = min(w, h) / 2f
                path.addCircle(0f, 0f, r, Path.Direction.CW)
            }
            ShapeType.DIAMOND -> {
                path.moveTo(0f, rect.top)
                path.lineTo(rect.right, 0f)
                path.lineTo(0f, rect.bottom)
                path.lineTo(rect.left, 0f)
                path.close()
            }
            ShapeType.STAR -> {
                val points = 5
                val outerR = min(w, h) * 0.5f
                val innerR = outerR * 0.44f
                for (i in 0 until points * 2) {
                    val r = if (i % 2 == 0) outerR else innerR
                    val angle = Math.toRadians((i * 36.0) - 90.0)
                    val x = (r * cos(angle)).toFloat()
                    val y = (r * sin(angle)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
            }
        }
        return path
    }

    private fun drawTextLayer(
        canvas: Canvas,
        layer: MotionLayer,
        canvasW: Float,
        alphaInt: Int,
        colorFilter: ColorMatrixColorFilter?,
        xfermode: PorterDuffXfermode?,
        glowEffect: LayerEffect?,
        blurEffect: LayerEffect?
    ) {
        val scaleFactor = canvasW / 1080f
        val pxSize = (layer.textSizeSp * 2.1f * scaleFactor).coerceAtLeast(18f)

        if (glowEffect != null && glowEffect.intensity > 0.01f) {
            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = pxSize
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                color = layer.secondaryColorHex.toInt()
                alpha = (alphaInt * 0.75f * glowEffect.intensity).toInt().coerceIn(0, 255)
                maskFilter = BlurMaskFilter((pxSize * 0.25f * glowEffect.intensity).coerceAtLeast(3f), BlurMaskFilter.Blur.OUTER)
            }
            drawMultilineCenteredText(canvas, layer.textContent, glowPaint)
        }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = pxSize
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = layer.colorHex.toInt()
            alpha = alphaInt
            this.colorFilter = colorFilter
            this.xfermode = xfermode
            if (blurEffect != null && blurEffect.intensity > 0.02f) {
                maskFilter = BlurMaskFilter((pxSize * 0.16f * blurEffect.intensity).coerceAtLeast(2f), BlurMaskFilter.Blur.NORMAL)
            }
        }
        drawMultilineCenteredText(canvas, layer.textContent, textPaint)
    }

    private fun drawMultilineCenteredText(canvas: Canvas, text: String, paint: Paint) {
        val lines = text.ifEmpty { "TEXT" }.split('\n')
        val lineHeight = paint.fontSpacing
        val totalHeight = lineHeight * lines.size
        var y = -totalHeight / 2f - paint.ascent() * 0.8f
        for (line in lines) {
            canvas.drawText(line, 0f, y, paint)
            y += lineHeight
        }
    }

    private fun drawBitmapLayer(
        canvas: Canvas,
        bitmap: Bitmap?,
        rect: RectF,
        alphaInt: Int,
        colorFilter: ColorMatrixColorFilter?,
        xfermode: PorterDuffXfermode?,
        chromaKeyEffect: LayerEffect?,
        glowEffect: LayerEffect?,
        blurEffect: LayerEffect?,
        pixelateEffect: LayerEffect?,
        useChromaCache: Boolean,
        fallbackLabel: String,
        fallbackColor: Int
    ) {
        if (glowEffect != null && glowEffect.intensity > 0.01f) {
            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = fallbackColor
                alpha = (alphaInt * 0.5f * glowEffect.intensity).toInt().coerceIn(0, 255)
                maskFilter = BlurMaskFilter((min(rect.width(), rect.height()) * 0.08f * glowEffect.intensity).coerceAtLeast(4f), BlurMaskFilter.Blur.OUTER)
            }
            canvas.drawRect(rect, glowPaint)
        }

        if (bitmap == null || bitmap.isRecycled) {
            val placeholderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(alphaInt, Color.red(fallbackColor), Color.green(fallbackColor), Color.blue(fallbackColor))
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(rect, 16f, 16f, placeholderPaint)
            val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                alpha = alphaInt
                textSize = max(20f, rect.width() * 0.06f)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(fallbackLabel, 0f, 0f, labelPaint)
            return
        }

        var workingBitmap = bitmap
        var shouldRecycleWorking = false

        if (chromaKeyEffect != null) {
            workingBitmap = ChromaKeyProcessor.applyChromaKey(
                source = workingBitmap,
                keyColorHex = chromaKeyEffect.keyColorHex,
                tolerance = chromaKeyEffect.intensity,
                spillSuppression = chromaKeyEffect.spillSuppression,
                useCache = useChromaCache
            )
            shouldRecycleWorking = !useChromaCache
        }

        if (pixelateEffect != null && pixelateEffect.intensity > 0.05f) {
            val factor = (1f - pixelateEffect.intensity * 0.88f).coerceIn(0.04f, 0.5f)
            val lowW = (workingBitmap.width * factor).toInt().coerceAtLeast(6)
            val lowH = (workingBitmap.height * factor).toInt().coerceAtLeast(6)
            val nextBitmap = Bitmap.createScaledBitmap(workingBitmap, lowW, lowH, false)
            if (shouldRecycleWorking && !workingBitmap.isRecycled) workingBitmap.recycle()
            workingBitmap = nextBitmap
            shouldRecycleWorking = true
        } else if (blurEffect != null && blurEffect.intensity > 0.04f) {
            val blurFactor = (1f - blurEffect.intensity * 0.85f).coerceIn(0.06f, 0.45f)
            val downW = (workingBitmap.width * blurFactor).toInt().coerceAtLeast(8)
            val downH = (workingBitmap.height * blurFactor).toInt().coerceAtLeast(8)
            val small = Bitmap.createScaledBitmap(workingBitmap, downW, downH, true)
            val nextBitmap = Bitmap.createScaledBitmap(small, max(16, workingBitmap.width / 2), max(16, workingBitmap.height / 2), true)
            small.recycle()
            if (shouldRecycleWorking && !workingBitmap.isRecycled) workingBitmap.recycle()
            workingBitmap = nextBitmap
            shouldRecycleWorking = true
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            alpha = alphaInt
            this.colorFilter = colorFilter
            this.xfermode = xfermode
            isFilterBitmap = pixelateEffect == null
        }
        canvas.drawBitmap(workingBitmap, null, rect, paint)

        if (shouldRecycleWorking && !workingBitmap.isRecycled) {
            workingBitmap.recycle()
        }
    }

    private fun buildColorMatrixFilter(effects: List<LayerEffect>): ColorMatrixColorFilter? {
        val brightnessFx = effects.firstOrNull { it.type == EffectType.BRIGHTNESS }
        val contrastFx = effects.firstOrNull { it.type == EffectType.CONTRAST }
        val saturationFx = effects.firstOrNull { it.type == EffectType.SATURATION }
        val noirFx = effects.firstOrNull { it.type == EffectType.MONO_NOIR }
        val sepiaFx = effects.firstOrNull { it.type == EffectType.SEPIA }
        if (brightnessFx == null && contrastFx == null && saturationFx == null && noirFx == null && sepiaFx == null) {
            return null
        }

        val matrix = ColorMatrix()

        if (noirFx != null) {
            val sat = (1f - noirFx.intensity).coerceIn(0f, 1f)
            val noirMat = ColorMatrix().apply { setSaturation(sat) }
            matrix.postConcat(noirMat)
        }

        if (sepiaFx != null) {
            val s = sepiaFx.intensity.coerceIn(0f, 1f)
            val inv = 1f - s
            val sepiaMatrix = ColorMatrix(
                floatArrayOf(
                    inv + s * 0.393f, s * 0.769f, s * 0.189f, 0f, 0f,
                    s * 0.349f, inv + s * 0.686f, s * 0.168f, 0f, 0f,
                    s * 0.272f, s * 0.534f, inv + s * 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(sepiaMatrix)
        }

        if (saturationFx != null) {
            val satMatrix = ColorMatrix()
            // 0f..1f intensity maps to 0x..2.5x saturation
            satMatrix.setSaturation((saturationFx.intensity * 2.2f).coerceIn(0f, 3f))
            matrix.postConcat(satMatrix)
        }

        if (contrastFx != null) {
            // 0.5 = 1.0x normal contrast, 1.0 = 2.2x contrast
            val c = (0.4f + contrastFx.intensity * 1.8f).coerceIn(0.2f, 2.5f)
            val t = (1f - c) * 127.5f
            val contrastMatrix = ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(contrastMatrix)
        }

        if (brightnessFx != null) {
            // 0.5 = neutral, 0 = dark (-100), 1.0 = bright (+100)
            val offset = (brightnessFx.intensity - 0.5f) * 200f
            val brightMatrix = ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, offset,
                    0f, 1f, 0f, 0f, offset,
                    0f, 0f, 1f, 0f, offset,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.postConcat(brightMatrix)
        }

        return ColorMatrixColorFilter(matrix)
    }

    private fun drawSelectionGizmo(canvas: Canvas, rect: RectF, canvasW: Float) {
        val stroke = max(2f, canvasW * 0.003f)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(56, 189, 248) // Cyber Cyan
            style = Paint.Style.STROKE
            strokeWidth = stroke
        }
        canvas.drawRect(rect, borderPaint)

        val handleRadius = max(7f, canvasW * 0.011f)
        val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(139, 92, 246)
            style = Paint.Style.STROKE
            strokeWidth = stroke * 0.9f
        }
        val corners = listOf(
            rect.left to rect.top,
            rect.right to rect.top,
            rect.left to rect.bottom,
            rect.right to rect.bottom
        )
        for ((cx, cy) in corners) {
            canvas.drawCircle(cx, cy, handleRadius, handleFill)
            canvas.drawCircle(cx, cy, handleRadius, handleStroke)
        }
    }
}
