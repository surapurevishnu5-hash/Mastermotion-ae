package com.example.data

import com.example.model.AnimatableProperty
import com.example.model.AspectRatioPreset
import com.example.model.BlendModeType
import com.example.model.CubicBezierCurve
import com.example.model.EffectType
import com.example.model.Keyframe
import com.example.model.LayerEffect
import com.example.model.LayerTransition
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.MotionProject
import com.example.model.ShapeType
import com.example.model.TransformValues
import com.example.model.TransitionType
import java.util.UUID

object SampleProjectFactory {
    fun createShowcaseProject(): MotionProject {
        val now = System.currentTimeMillis()
        val cardLayer = MotionLayer(
            id = UUID.randomUUID().toString(),
            name = "3D Prism Card",
            type = LayerType.SHAPE,
            startTimeMs = 0L,
            endTimeMs = 6000L,
            zIndex = 1,
            shapeType = ShapeType.ROUNDED_CARD,
            colorHex = 0xFF8B5CF6L,
            secondaryColorHex = 0xFF3B82F6L,
            baseTransform = TransformValues(scaleX = 0.8f, scaleY = 0.8f),
            keyframeTracks = mapOf(
                AnimatableProperty.ROTATION_Y.name to listOf(
                    Keyframe(timeMs = 0L, value = -38f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 3000L, value = 32f, curve = CubicBezierCurve.OVERSHOOT),
                    Keyframe(timeMs = 6000L, value = 0f, curve = CubicBezierCurve.EASE_OUT)
                ),
                AnimatableProperty.ROTATION_X.name to listOf(
                    Keyframe(timeMs = 0L, value = 16f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 3000L, value = -12f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 6000L, value = 0f, curve = CubicBezierCurve.EASE_OUT)
                ),
                AnimatableProperty.SCALE_X.name to listOf(
                    Keyframe(timeMs = 0L, value = 0.55f, curve = CubicBezierCurve.OVERSHOOT),
                    Keyframe(timeMs = 1500L, value = 1.05f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 6000L, value = 0.9f, curve = CubicBezierCurve.EASE_OUT)
                ),
                AnimatableProperty.SCALE_Y.name to listOf(
                    Keyframe(timeMs = 0L, value = 0.55f, curve = CubicBezierCurve.OVERSHOOT),
                    Keyframe(timeMs = 1500L, value = 1.05f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 6000L, value = 0.9f, curve = CubicBezierCurve.EASE_OUT)
                )
            ),
            effects = listOf(
                LayerEffect(type = EffectType.GLOW, intensity = 0.7f, enabled = true)
            ),
            inTransition = LayerTransition(TransitionType.ZOOM_POP, 600L),
            outTransition = LayerTransition(TransitionType.FADE, 500L)
        )

        val orbLayer = MotionLayer(
            id = UUID.randomUUID().toString(),
            name = "Cyber Halo Ring",
            type = LayerType.SHAPE,
            startTimeMs = 300L,
            endTimeMs = 6000L,
            zIndex = 0,
            blendMode = BlendModeType.ADD,
            shapeType = ShapeType.CIRCLE,
            colorHex = 0xFF38BDF8L,
            secondaryColorHex = 0xFF6D28D9L,
            baseTransform = TransformValues(opacity = 0.45f, scaleX = 1.25f, scaleY = 1.25f),
            keyframeTracks = mapOf(
                AnimatableProperty.POSITION_X.name to listOf(
                    Keyframe(timeMs = 300L, value = -0.35f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 3200L, value = 0.35f, curve = CubicBezierCurve.EASE_IN_OUT),
                    Keyframe(timeMs = 6000L, value = 0f, curve = CubicBezierCurve.EASE_OUT)
                ),
                AnimatableProperty.ROTATION_Z.name to listOf(
                    Keyframe(timeMs = 300L, value = 0f, curve = CubicBezierCurve.LINEAR),
                    Keyframe(timeMs = 6000L, value = 180f, curve = CubicBezierCurve.LINEAR)
                )
            ),
            effects = listOf(
                LayerEffect(type = EffectType.BLUR, intensity = 0.45f, enabled = true)
            )
        )

        val titleLayer = MotionLayer(
            id = UUID.randomUUID().toString(),
            name = "Kinetic Title",
            type = LayerType.TEXT,
            startTimeMs = 450L,
            endTimeMs = 5800L,
            zIndex = 2,
            textContent = "MASTER MOTION",
            textSizeSp = 46f,
            colorHex = 0xFFFFFFFFL,
            secondaryColorHex = 0xFF38BDF8L,
            keyframeTracks = mapOf(
                AnimatableProperty.POSITION_Y.name to listOf(
                    Keyframe(timeMs = 450L, value = 0.25f, curve = CubicBezierCurve.ELASTIC_SNAP),
                    Keyframe(timeMs = 1600L, value = 0f, curve = CubicBezierCurve.EASE_OUT)
                ),
                AnimatableProperty.OPACITY.name to listOf(
                    Keyframe(timeMs = 450L, value = 0f, curve = CubicBezierCurve.EASE_OUT),
                    Keyframe(timeMs = 1100L, value = 1f, curve = CubicBezierCurve.LINEAR)
                )
            ),
            effects = listOf(
                LayerEffect(type = EffectType.GLOW, intensity = 0.5f, enabled = true)
            ),
            inTransition = LayerTransition(TransitionType.SLIDE_UP, 450L),
            outTransition = LayerTransition(TransitionType.FLIP_3D, 500L)
        )

        val starAccent = MotionLayer(
            id = UUID.randomUUID().toString(),
            name = "Key Star",
            type = LayerType.SHAPE,
            startTimeMs = 800L,
            endTimeMs = 5500L,
            zIndex = 3,
            shapeType = ShapeType.STAR,
            colorHex = 0xFFEC4899L,
            secondaryColorHex = 0xFF8B5CF6L,
            baseTransform = TransformValues(posX = 0.42f, posY = -0.36f, scaleX = 0.22f, scaleY = 0.22f),
            keyframeTracks = mapOf(
                AnimatableProperty.ROTATION_Z.name to listOf(
                    Keyframe(timeMs = 800L, value = 0f, curve = CubicBezierCurve.LINEAR),
                    Keyframe(timeMs = 5500L, value = 360f, curve = CubicBezierCurve.LINEAR)
                )
            ),
            inTransition = LayerTransition(TransitionType.ZOOM_POP, 400L)
        )

        return MotionProject(
            id = UUID.randomUUID().toString(),
            name = "3D Neon Title Demo",
            aspectRatio = AspectRatioPreset.RATIO_16_9,
            fps = 30,
            durationMs = 6000L,
            backgroundColorHex = 0xFF0A0B10L,
            layers = listOf(orbLayer, cardLayer, titleLayer, starAccent),
            createdAt = now,
            updatedAt = now
        )
    }
}
