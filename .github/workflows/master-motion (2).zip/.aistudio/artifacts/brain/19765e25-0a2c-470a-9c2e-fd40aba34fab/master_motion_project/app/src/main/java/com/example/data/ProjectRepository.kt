package com.example.data

import android.content.Context
import android.graphics.Bitmap
import com.example.engine.CompositionRenderer
import com.example.engine.MediaManager
import com.example.model.AspectRatioPreset
import com.example.model.ExportResolution
import com.example.model.MotionProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ProjectSummary(
    val id: String,
    val name: String,
    val aspectRatioLabel: String,
    val resolutionLabel: String,
    val fps: Int,
    val durationMs: Long,
    val layerCount: Int,
    val thumbnailPath: String?,
    val updatedAt: Long
)

class ProjectRepository(
    private val context: Context,
    private val projectDao: ProjectDao,
    private val mediaManager: MediaManager
) {
    val projects: Flow<List<ProjectSummary>> = projectDao.observeAllProjects().map { list ->
        list.map { entity ->
            ProjectSummary(
                id = entity.id,
                name = entity.name,
                aspectRatioLabel = entity.aspectRatioLabel,
                resolutionLabel = entity.resolution,
                fps = entity.frameRate,
                durationMs = entity.durationMs,
                layerCount = entity.layerCount,
                thumbnailPath = entity.thumbnailPath,
                updatedAt = entity.lastModified
            )
        }
    }

    suspend fun createBlankProject(
        name: String,
        aspectRatio: AspectRatioPreset,
        fps: Int = 30,
        durationMs: Long = 8000L
    ): MotionProject {
        val now = System.currentTimeMillis()
        val project = MotionProject(
            name = name.ifBlank { "Untitled Motion" },
            aspectRatio = aspectRatio,
            fps = fps,
            durationMs = durationMs,
            createdAt = now,
            updatedAt = now
        )
        saveProject(project)
        return project
    }

    suspend fun createSampleMotionProject(): MotionProject {
        val project = SampleProjectFactory.createShowcaseProject()
        saveProject(project)
        return project
    }

    suspend fun loadProject(projectId: String): MotionProject? = withContext(Dispatchers.IO) {
        val entity = projectDao.getProjectById(projectId)
        if (entity != null) {
            return@withContext ProjectSerializer.fromJson(entity.projectJson)
        }
        val localFile = File(localProjectsDir(), "$projectId.mmproj")
        if (localFile.exists()) {
            return@withContext runCatching { ProjectSerializer.fromJson(localFile.readText()) }.getOrNull()
        }
        null
    }

    /**
     * Lists all saved project files from the local projects directory.
     */
    fun listLocalProjectFiles(): List<File> {
        val files = localProjectsDir().listFiles { file ->
            file.isFile && (file.extension.equals("mmproj", ignoreCase = true) || file.extension.equals("json", ignoreCase = true))
        } ?: return emptyList()
        return files.sortedByDescending { it.lastModified() }
    }

    /**
     * Scans saved project files in the local directory and ensures they are indexed in Room.
     */
    suspend fun scanLocalProjectsIntoDatabase(): Int = withContext(Dispatchers.IO) {
        val files = listLocalProjectFiles()
        var synced = 0
        for (file in files) {
            val parsed = runCatching { ProjectSerializer.fromJson(file.readText()) }.getOrNull() ?: continue
            val existing = projectDao.getProjectById(parsed.id)
            if (existing == null || existing.lastModified < parsed.updatedAt) {
                val (resW, resH) = parsed.aspectRatio.dimensionsFor(ExportResolution.FHD_1080P)
                val thumbPath = renderAndSaveThumbnail(parsed)
                projectDao.upsertProject(
                    Project(
                        id = parsed.id,
                        name = parsed.name,
                        aspectRatioLabel = parsed.aspectRatio.label,
                        resolutionWidth = resW,
                        resolutionHeight = resH,
                        resolution = "${resW}×${resH}",
                        frameRate = parsed.fps,
                        durationMs = parsed.durationMs,
                        layerCount = parsed.layers.size,
                        thumbnailPath = thumbPath,
                        projectJson = file.readText(),
                        lastModified = parsed.updatedAt
                    )
                )
                synced++
            }
        }
        synced
    }

    suspend fun saveProject(project: MotionProject) = withContext(Dispatchers.IO) {
        val updated = project.copy(updatedAt = System.currentTimeMillis())
        val json = ProjectSerializer.toJson(updated)
        runCatching {
            File(localProjectsDir(), "${updated.id}.mmproj").writeText(json)
        }
        val (resW, resH) = updated.aspectRatio.dimensionsFor(ExportResolution.FHD_1080P)
        val thumbPath = renderAndSaveThumbnail(updated)
        val entity = Project(
            id = updated.id,
            name = updated.name,
            aspectRatioLabel = updated.aspectRatio.label,
            resolutionWidth = resW,
            resolutionHeight = resH,
            resolution = "${resW}×${resH}",
            frameRate = updated.fps,
            durationMs = updated.durationMs,
            layerCount = updated.layers.size,
            thumbnailPath = thumbPath,
            projectJson = json,
            lastModified = updated.updatedAt
        )
        projectDao.upsertProject(entity)
    }

    suspend fun duplicateProject(projectId: String): MotionProject? = withContext(Dispatchers.IO) {
        val original = loadProject(projectId) ?: return@withContext null
        val now = System.currentTimeMillis()
        val copy = original.copy(
            id = java.util.UUID.randomUUID().toString(),
            name = "${original.name} Copy",
            createdAt = now,
            updatedAt = now
        )
        saveProject(copy)
        copy
    }

    suspend fun renameProject(projectId: String, newName: String) = withContext(Dispatchers.IO) {
        val project = loadProject(projectId) ?: return@withContext
        val trimmed = newName.trim()
        if (trimmed.isNotEmpty()) {
            saveProject(project.copy(name = trimmed))
        }
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        projectDao.deleteProjectById(projectId)
        val projFile = File(localProjectsDir(), "$projectId.mmproj")
        if (projFile.exists()) projFile.delete()
        val thumbFile = File(thumbnailsDir(), "$projectId.png")
        if (thumbFile.exists()) thumbFile.delete()
        mediaManager.deleteProjectMedia(projectId)
    }

    private fun renderAndSaveThumbnail(project: MotionProject): String? = runCatching {
        val thumbW = 480
        val thumbH = (thumbW / project.aspectRatio.ratio).toInt().coerceIn(200, 720)
        val previewMs = (project.durationMs / 3L).coerceAtLeast(0L)
        val bitmap = CompositionRenderer.renderToBitmap(
            project = project,
            timeMs = previewMs,
            width = thumbW,
            height = thumbH,
            mediaManager = mediaManager,
            selectedLayerId = null,
            showGuides = false
        )
        val outFile = File(thumbnailsDir(), "${project.id}.png")
        FileOutputStream(outFile).use { fos ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, fos)
        }
        bitmap.recycle()
        outFile.absolutePath
    }.getOrNull()

    fun localProjectsDir(): File = File(context.filesDir, "projects").apply {
        if (!exists()) mkdirs()
    }

    private fun thumbnailsDir(): File = File(context.filesDir, "project_thumbs").apply {
        if (!exists()) mkdirs()
    }
}
