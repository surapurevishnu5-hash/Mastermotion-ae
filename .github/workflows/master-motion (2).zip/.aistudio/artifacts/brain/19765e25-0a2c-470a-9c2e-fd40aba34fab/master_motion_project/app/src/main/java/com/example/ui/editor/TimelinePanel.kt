package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.engine.MediaManager
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.MotionProject
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.KeyframeMagenta
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackAudioColor
import com.example.ui.theme.TrackImageColor
import com.example.ui.theme.TrackShapeColor
import com.example.ui.theme.TrackTextColor
import com.example.ui.theme.TrackVideoColor
import kotlin.math.roundToInt
import kotlin.math.roundToLong

@Composable
fun TimelinePanel(
    project: MotionProject,
    selectedLayerId: String?,
    playheadMs: Long,
    timelineZoom: Float,
    mediaManager: MediaManager? = null,
    onSeekTo: (Long) -> Unit,
    onSelectLayer: (String) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onTrimLayer: (layerId: String, startMs: Long, endMs: Long, recordUndo: Boolean) -> Unit,
    onBeginTimelineEdit: () -> Unit = {},
    onEndTimelineEdit: () -> Unit = {},
    onReorderLayer: (layerId: String, targetVisualIndex: Int) -> Unit,
    onSplitSelected: () -> Unit,
    onDeleteSelected: () -> Unit,
    onChangeZoom: (Float) -> Unit,
    onAddLayerClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val baseDpPerSecond = 88.dp
    val dpPerSecond = baseDpPerSecond * timelineZoom
    val pxPerMs = with(density) { dpPerSecond.toPx() / 1000f }
    val totalTimelineWidthDp = ((project.durationMs / 1000f) * dpPerSecond.value).dp.coerceAtLeast(320.dp)

    val rowHeightDp = 46.dp
    val rowHeightPx = with(density) { rowHeightDp.toPx() }
    val headerWidth = 118.dp

    val horizontalScroll = rememberScrollState()
    val verticalScroll = rememberScrollState()

    val sortedLayers = remember(project.layers) {
        project.layers.sortedByDescending { it.zIndex }
    }

    // Drag-and-drop vertical reorder state
    var draggingLayerId by remember { mutableStateOf<String?>(null) }
    var draggingStartIndex by remember { mutableIntStateOf(-1) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurface)
    ) {
        // Timeline Toolbar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurfaceElevated)
                .border(0.5.dp, StudioBorder)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ElectricPurple.copy(alpha = 0.22f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElectricPurple),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onAddLayerClick)
                        .testTag("timeline_add_layer_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Layer", style = MaterialTheme.typography.labelLarge, color = Color.White)
                    }
                }

                IconButton(
                    onClick = onSplitSelected,
                    enabled = selectedLayerId != null,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("timeline_split_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.ContentCut,
                        contentDescription = "Split Layer at Playhead",
                        tint = if (selectedLayerId != null) CyberCyan else TextSecondary.copy(alpha = 0.4f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onDeleteSelected,
                    enabled = selectedLayerId != null,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("timeline_delete_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Delete Selected Layer",
                        tint = if (selectedLayerId != null) ErrorCoral else TextSecondary.copy(alpha = 0.35f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = { onChangeZoom(timelineZoom - 0.25f) },
                    modifier = Modifier.size(34.dp).testTag("timeline_zoom_out_button")
                ) {
                    Icon(Icons.Filled.ZoomOut, contentDescription = "Zoom Out Timeline", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "${(timelineZoom * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { onChangeZoom(1.0f) }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                        .testTag("timeline_zoom_label")
                )
                IconButton(
                    onClick = { onChangeZoom(timelineZoom + 0.25f) },
                    modifier = Modifier.size(34.dp).testTag("timeline_zoom_in_button")
                ) {
                    Icon(Icons.Filled.ZoomIn, contentDescription = "Zoom In Timeline", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }

        val currentPlayhead by rememberUpdatedState(playheadMs)
        val currentPxPerMs by rememberUpdatedState(pxPerMs)
        val currentDuration by rememberUpdatedState(project.durationMs)

        Column(modifier = Modifier.fillMaxSize()) {
            // Fixed Top Ruler Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .background(ObsidianBg)
            ) {
                Box(
                    contentAlignment = Alignment.CenterStart,
                    modifier = Modifier
                        .width(headerWidth)
                        .fillMaxHeight()
                        .border(0.5.dp, StudioBorder)
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "${project.layers.size} LAYERS",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .horizontalScroll(horizontalScroll)
                        .pointerInput(project.durationMs, timelineZoom) {
                            detectTapGestures { offset ->
                                val ms = (offset.x / currentPxPerMs).roundToLong().coerceIn(0L, currentDuration)
                                onSeekTo(ms)
                            }
                        }
                        .pointerInput(project.durationMs, timelineZoom) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val ms = (change.position.x / currentPxPerMs).roundToLong().coerceIn(0L, currentDuration)
                                onSeekTo(ms)
                            }
                        }
                        .testTag("timeline_ruler")
                ) {
                    val rulerTextPaint = remember {
                        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.parseColor("#9CA3AF")
                            textSize = 24f
                        }
                    }
                    Canvas(
                        modifier = Modifier
                            .width(totalTimelineWidthDp + 48.dp)
                            .fillMaxHeight()
                    ) {
                        val durMs = project.durationMs
                        val stepMs = if (timelineZoom >= 1.5f) 500L else 1000L
                        var t = 0L
                        while (t <= durMs) {
                            val x = t * pxPerMs
                            val isMajor = t % 1000L == 0L
                            drawLine(
                                color = if (isMajor) Color(0xFF4B5563) else Color(0xFF2D3348),
                                start = Offset(x, if (isMajor) 4f else size.height * 0.55f),
                                end = Offset(x, size.height),
                                strokeWidth = if (isMajor) 2f else 1f
                            )
                            if (isMajor) {
                                val totalSec = t / 1000L
                                val mins = totalSec / 60L
                                val secs = totalSec % 60L
                                val stamp = String.format(java.util.Locale.US, "%02d:%02d", mins, secs)
                                drawIntoCanvas { c ->
                                    c.nativeCanvas.drawText(stamp, x + 4f, size.height - 8f, rulerTextPaint)
                                }
                            }
                            t += stepMs
                        }
                        val playX = currentPlayhead * pxPerMs
                        val headPath = Path().apply {
                            moveTo(playX - 8f, 0f)
                            lineTo(playX + 8f, 0f)
                            lineTo(playX, 14f)
                            close()
                        }
                        drawPath(headPath, color = CyberCyan)
                        drawLine(
                            color = CyberCyan,
                            start = Offset(playX, 12f),
                            end = Offset(playX, size.height),
                            strokeWidth = 2.5f
                        )
                    }

                    // Explicit Draggable Playhead Scrub Handle on Ruler
                    val playheadHandleOffsetDp = with(density) { (currentPlayhead * pxPerMs).toDp() } - 10.dp
                    Box(
                        modifier = Modifier
                            .offset(x = playheadHandleOffsetDp)
                            .width(20.dp)
                            .fillMaxHeight()
                            .pointerInput(project.durationMs, timelineZoom) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaMs = (dragAmount.x / currentPxPerMs).roundToLong()
                                    onSeekTo((currentPlayhead + deltaMs).coerceIn(0L, currentDuration))
                                }
                            }
                            .testTag("timeline_playhead_handle")
                    )
                }
            }

            // Tracks Area (synchronized vertical & single horizontal scroll)
            if (sortedLayers.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "Tap '+ Layer' to add Video, Image, Audio, Shape, or Text",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(verticalScroll)
                ) {
                    // Left Track Headers Column with Drag-and-Drop Reorder
                    Column(
                        modifier = Modifier.width(headerWidth)
                    ) {
                        sortedLayers.forEachIndexed { visualIdx, layer ->
                            val isSelected = layer.id == selectedLayerId
                            val isDragging = layer.id == draggingLayerId
                            val trackColor = layerTrackColor(layer.type)

                            val targetVisualIdx = if (draggingLayerId != null && draggingStartIndex >= 0) {
                                (draggingStartIndex + (dragOffsetY / rowHeightPx).roundToInt())
                                    .coerceIn(0, sortedLayers.lastIndex)
                            } else -1

                            val isDropTarget = draggingLayerId != null && !isDragging && targetVisualIdx == visualIdx

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(rowHeightDp)
                                    .zIndex(if (isDragging) 10f else 0f)
                                    .graphicsLayer {
                                        translationY = if (isDragging) dragOffsetY else 0f
                                        scaleX = if (isDragging) 1.03f else 1f
                                        scaleY = if (isDragging) 1.03f else 1f
                                    }
                                    .background(
                                        when {
                                            isDragging -> ElectricPurple.copy(alpha = 0.35f)
                                            isDropTarget -> CyberCyan.copy(alpha = 0.22f)
                                            isSelected -> ElectricPurple.copy(alpha = 0.14f)
                                            else -> StudioSurface
                                        }
                                    )
                                    .border(
                                        width = if (isDragging || isDropTarget) 1.dp else 0.5.dp,
                                        color = when {
                                            isDragging -> ElectricPurple
                                            isDropTarget -> CyberCyan
                                            else -> StudioBorder.copy(alpha = 0.5f)
                                        }
                                    )
                                    .clickable { onSelectLayer(layer.id) }
                                    .padding(horizontal = 4.dp)
                                    .testTag("timeline_header_${layer.id}")
                            ) {
                                // Drag Handle for Vertical Reordering
                                Icon(
                                    imageVector = Icons.Filled.DragIndicator,
                                    contentDescription = "Drag to Reorder Layer",
                                    tint = if (isDragging) Color.White else TextSecondary,
                                    modifier = Modifier
                                        .size(18.dp)
                                        .pointerInput(layer.id, sortedLayers.size) {
                                            detectVerticalDragGestures(
                                                onDragStart = {
                                                    draggingLayerId = layer.id
                                                    draggingStartIndex = visualIdx
                                                    dragOffsetY = 0f
                                                    onSelectLayer(layer.id)
                                                },
                                                onVerticalDrag = { change, dragAmount ->
                                                    change.consume()
                                                    dragOffsetY += dragAmount
                                                },
                                                onDragEnd = {
                                                    val endIdx = (draggingStartIndex + (dragOffsetY / rowHeightPx).roundToInt())
                                                        .coerceIn(0, sortedLayers.lastIndex)
                                                    if (endIdx != draggingStartIndex) {
                                                        onReorderLayer(layer.id, endIdx)
                                                    }
                                                    draggingLayerId = null
                                                    draggingStartIndex = -1
                                                    dragOffsetY = 0f
                                                },
                                                onDragCancel = {
                                                    draggingLayerId = null
                                                    draggingStartIndex = -1
                                                    dragOffsetY = 0f
                                                }
                                            )
                                        }
                                        .testTag("drag_handle_${layer.id}")
                                )

                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(24.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(trackColor)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = layerTypeIcon(layer.type),
                                    contentDescription = null,
                                    tint = trackColor,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = layer.name,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) Color.White else TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onToggleVisibility(layer.id) },
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Icon(
                                        imageVector = if (layer.isVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                        contentDescription = "Toggle Visibility",
                                        tint = if (layer.isVisible) TextSecondary else TextSecondary.copy(alpha = 0.35f),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Right Unified Horizontal Scrollable Tracks Pane
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .horizontalScroll(horizontalScroll)
                    ) {
                        Box(
                            modifier = Modifier.width(totalTimelineWidthDp + 48.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                sortedLayers.forEach { layer ->
                                    val isSelected = layer.id == selectedLayerId
                                    val isDragging = layer.id == draggingLayerId
                                    val trackColor = layerTrackColor(layer.type)

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(rowHeightDp)
                                            .zIndex(if (isDragging) 10f else 0f)
                                            .graphicsLayer {
                                                translationY = if (isDragging) dragOffsetY else 0f
                                            }
                                            .background(
                                                if (isSelected) ElectricPurple.copy(alpha = 0.08f)
                                                else StudioSurface
                                            )
                                            .border(0.5.dp, StudioBorder.copy(alpha = 0.45f))
                                    ) {
                                        TimelineClipBar(
                                            layer = layer,
                                            isSelected = isSelected,
                                            trackColor = trackColor,
                                            pxPerMs = pxPerMs,
                                            projectDurationMs = project.durationMs,
                                            mediaManager = mediaManager,
                                            onSelect = { onSelectLayer(layer.id) },
                                            onBeginEdit = onBeginTimelineEdit,
                                            onEndEdit = onEndTimelineEdit,
                                            onTrim = { newStart, newEnd, recordUndo ->
                                                onTrimLayer(layer.id, newStart, newEnd, recordUndo)
                                            }
                                        )
                                    }
                                }
                            }

                            // Unified Playhead line spanning all tracks
                            val playheadX = with(density) { (playheadMs * pxPerMs).toDp() }
                            Box(
                                modifier = Modifier
                                    .offset(x = playheadX)
                                    .width(1.5.dp)
                                    .height(rowHeightDp * sortedLayers.size)
                                    .background(CyberCyan.copy(alpha = 0.9f))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelineClipBar(
    layer: MotionLayer,
    isSelected: Boolean,
    trackColor: Color,
    pxPerMs: Float,
    projectDurationMs: Long,
    mediaManager: MediaManager?,
    onSelect: () -> Unit,
    onBeginEdit: () -> Unit,
    onEndEdit: () -> Unit,
    onTrim: (newStartMs: Long, newEndMs: Long, recordUndo: Boolean) -> Unit
) {
    val density = LocalDensity.current
    val startDp = with(density) { (layer.startTimeMs * pxPerMs).toDp() }
    val widthDp = with(density) { ((layer.endTimeMs - layer.startTimeMs).coerceAtLeast(200L) * pxPerMs).toDp() }
    val keyframeTimes = remember(layer.keyframeTracks) { layer.allKeyframeTimes() }

    val clipThumb by produceState<android.graphics.Bitmap?>(initialValue = null, layer.mediaPath, layer.type, layer.mediaTrimStartMs) {
        value = if (mediaManager != null && (layer.type == LayerType.IMAGE || layer.type == LayerType.VIDEO)) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                mediaManager.getLayerThumbnail(layer, maxDimension = 160)
            }
        } else null
    }

    var dragStartMs by remember(layer.id, layer.startTimeMs) { mutableLongStateOf(layer.startTimeMs) }
    var dragEndMs by remember(layer.id, layer.endTimeMs) { mutableLongStateOf(layer.endTimeMs) }
    val clipDurationSec = String.format(java.util.Locale.US, "%.1fs", (layer.endTimeMs - layer.startTimeMs) / 1000f)

    Box(
        modifier = Modifier
            .offset { IntOffset(with(density) { startDp.roundToPx() }, 5) }
            .width(widthDp)
            .height(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(trackColor.copy(alpha = if (isSelected) 0.36f else 0.22f))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) Color.White else trackColor.copy(alpha = 0.7f),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onSelect)
            .pointerInput(layer.id, layer.isLocked, pxPerMs) {
                if (!layer.isLocked) {
                    detectDragGestures(
                        onDragStart = {
                            dragStartMs = layer.startTimeMs
                            dragEndMs = layer.endTimeMs
                            onBeginEdit()
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount.x / pxPerMs).roundToLong()
                            val clipLen = dragEndMs - dragStartMs
                            val nextStart = (dragStartMs + deltaMs).coerceIn(0L, (projectDurationMs - clipLen).coerceAtLeast(0L))
                            dragStartMs = nextStart
                            dragEndMs = nextStart + clipLen
                            onTrim(dragStartMs, dragEndMs, false)
                        },
                        onDragEnd = { onEndEdit() },
                        onDragCancel = { onEndEdit() }
                    )
                }
            }
            .testTag("timeline_clip_${layer.id}")
    ) {
        if (clipThumb != null && !clipThumb!!.isRecycled) {
            Image(
                bitmap = clipThumb!!.asImageBitmap(),
                contentDescription = "${layer.name} thumbnail",
                contentScale = ContentScale.Crop,
                alpha = 0.42f,
                modifier = Modifier.fillMaxSize()
            )
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            if (layer.waveformSamples.isNotEmpty()) {
                val count = layer.waveformSamples.size
                val barW = (size.width / count.toFloat()).coerceAtLeast(2f)
                for (i in 0 until count) {
                    val amp = layer.waveformSamples[i]
                    val h = (size.height * 0.68f * amp).coerceAtLeast(3f)
                    val x = i * barW
                    val top = (size.height - h) / 2f
                    drawLine(
                        color = trackColor.copy(alpha = 0.75f),
                        start = Offset(x, top),
                        end = Offset(x, top + h),
                        strokeWidth = (barW * 0.55f).coerceAtLeast(1.5f)
                    )
                }
            }

            val clipDur = (layer.endTimeMs - layer.startTimeMs).coerceAtLeast(1L)
            for (kfMs in keyframeTimes) {
                if (kfMs in layer.startTimeMs..layer.endTimeMs) {
                    val ratio = (kfMs - layer.startTimeMs).toFloat() / clipDur.toFloat()
                    val cx = ratio * size.width
                    val cy = size.height / 2f
                    val r = 6f
                    val diamond = Path().apply {
                        moveTo(cx, cy - r)
                        lineTo(cx + r, cy)
                        lineTo(cx, cy + r)
                        lineTo(cx - r, cy)
                        close()
                    }
                    drawPath(diamond, color = KeyframeMagenta)
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 12.dp)
        ) {
            if (layer.isLocked) {
                Icon(Icons.Filled.Lock, contentDescription = "Locked", tint = Color.White, modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(3.dp))
            }
            if (layer.isMuted) {
                Icon(Icons.AutoMirrored.Filled.VolumeOff, contentDescription = "Muted", tint = Color.White, modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(3.dp))
            }
            Text(
                text = "${layer.name} • $clipDurationSec",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (isSelected && !layer.isLocked) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(12.dp)
                    .fillMaxHeight()
                    .background(Color.White.copy(alpha = 0.9f))
                    .pointerInput(layer.id, pxPerMs) {
                        detectDragGestures(
                            onDragStart = {
                                dragStartMs = layer.startTimeMs
                                dragEndMs = layer.endTimeMs
                                onBeginEdit()
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val deltaMs = (dragAmount.x / pxPerMs).roundToLong()
                                dragStartMs = (dragStartMs + deltaMs).coerceIn(0L, dragEndMs - 250L)
                                onTrim(dragStartMs, dragEndMs, false)
                            },
                            onDragEnd = { onEndEdit() },
                            onDragCancel = { onEndEdit() }
                        )
                    }
            ) {
                Box(modifier = Modifier.width(2.dp).height(14.dp).background(ObsidianBg))
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(12.dp)
                    .fillMaxHeight()
                    .background(Color.White.copy(alpha = 0.9f))
                    .pointerInput(layer.id, pxPerMs) {
                        detectDragGestures(
                            onDragStart = {
                                dragStartMs = layer.startTimeMs
                                dragEndMs = layer.endTimeMs
                                onBeginEdit()
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val deltaMs = (dragAmount.x / pxPerMs).roundToLong()
                                dragEndMs = (dragEndMs + deltaMs).coerceIn(dragStartMs + 250L, projectDurationMs)
                                onTrim(dragStartMs, dragEndMs, false)
                            },
                            onDragEnd = { onEndEdit() },
                            onDragCancel = { onEndEdit() }
                        )
                    }
            ) {
                Box(modifier = Modifier.width(2.dp).height(14.dp).background(ObsidianBg))
            }
        }
    }
}

fun layerTrackColor(type: LayerType): Color = when (type) {
    LayerType.VIDEO -> TrackVideoColor
    LayerType.IMAGE -> TrackImageColor
    LayerType.SHAPE -> TrackShapeColor
    LayerType.TEXT -> TrackTextColor
    LayerType.AUDIO -> TrackAudioColor
}

fun layerTypeIcon(type: LayerType) = when (type) {
    LayerType.VIDEO -> Icons.Filled.Videocam
    LayerType.IMAGE -> Icons.Filled.Image
    LayerType.SHAPE -> Icons.Filled.Category
    LayerType.TEXT -> Icons.Filled.TextFields
    LayerType.AUDIO -> Icons.Filled.Audiotrack
}
