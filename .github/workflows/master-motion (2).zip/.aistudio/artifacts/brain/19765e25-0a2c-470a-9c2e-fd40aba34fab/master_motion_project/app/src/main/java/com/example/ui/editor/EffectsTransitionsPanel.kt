package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.MediaManager
import com.example.model.EffectType
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.TransitionType
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun EffectsTransitionsPanel(
    layer: MotionLayer?,
    playheadMs: Long = 0L,
    mediaManager: MediaManager? = null,
    onAddEffect: (EffectType) -> Unit,
    onToggleEffect: (String) -> Unit,
    onUpdateEffectIntensity: (String, Float) -> Unit,
    onUpdateChromaKey: (effectId: String, keyColorHex: Long?, tolerance: Float?, spillSuppression: Float?, recordUndo: Boolean) -> Unit = { _, _, _, _, _ -> },
    onBeginSliderEdit: () -> Unit = {},
    onEndSliderEdit: () -> Unit = {},
    onRemoveEffect: (String) -> Unit,
    onUpdateInTransition: (TransitionType, Long, Boolean) -> Unit,
    onUpdateOutTransition: (TransitionType, Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    if (layer == null) {
        EmptyInspectorHint("Select a visual layer to apply GPU-style effects and In/Out transitions.", modifier)
        return
    }

    val scroll = rememberScrollState()

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(12.dp)
    ) {
        // Add Effect Bar
        Text("Add Visual Effect", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            EffectType.entries.forEach { effectType ->
                val alreadyAdded = layer.effects.any { it.type == effectType }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (alreadyAdded) ElectricPurple.copy(alpha = 0.22f) else StudioSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (alreadyAdded) ElectricPurple else StudioBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(enabled = !alreadyAdded) { onAddEffect(effectType) }
                        .testTag("add_effect_${effectType.name}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Icon(
                            imageVector = if (alreadyAdded) Icons.Filled.AutoFixHigh else Icons.Filled.Add,
                            contentDescription = null,
                            tint = if (alreadyAdded) ElectricPurple else CyberCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = effectType.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (alreadyAdded) Color.White else TextPrimary
                        )
                    }
                }
            }
        }

        val hasChromaKey = layer.effects.any { it.type == EffectType.CHROMA_KEY }
        if (!hasChromaKey && (layer.type == LayerType.VIDEO || layer.type == LayerType.IMAGE)) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SuccessGreen.copy(alpha = 0.14f),
                border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onAddEffect(EffectType.CHROMA_KEY) }
                    .testTag("quick_add_chroma_key_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Chroma Key (Green Screen)",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                        Text(
                            text = "Key out background color with tolerance & spill control",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Enable Chroma Key",
                        tint = SuccessGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Active Effects Stack
        if (layer.effects.isNotEmpty()) {
            layer.effects.forEach { fx ->
                if (fx.type == EffectType.CHROMA_KEY) {
                    ChromaKeyEffectCard(
                        layer = layer,
                        effect = fx,
                        playheadMs = playheadMs,
                        mediaManager = mediaManager,
                        onToggleEnabled = { onToggleEffect(fx.id) },
                        onUpdateChromaKey = { colorHex, tol, spill, recordUndo ->
                            onUpdateChromaKey(fx.id, colorHex, tol, spill, recordUndo)
                        },
                        onBeginSliderEdit = onBeginSliderEdit,
                        onEndSliderEdit = onEndSliderEdit,
                        onRemove = { onRemoveEffect(fx.id) }
                    )
                } else {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = StudioSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = fx.type.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${(fx.intensity * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberCyan
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Switch(
                                    checked = fx.enabled,
                                    onCheckedChange = { onToggleEffect(fx.id) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = ElectricPurple
                                    )
                                )
                                IconButton(
                                    onClick = { onRemoveEffect(fx.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Remove Effect", tint = ErrorCoral, modifier = Modifier.size(18.dp))
                                }
                            }
                            Slider(
                                value = fx.intensity,
                                onValueChange = {
                                    onBeginSliderEdit()
                                    onUpdateEffectIntensity(fx.id, it)
                                },
                                onValueChangeFinished = onEndSliderEdit,
                                enabled = fx.enabled,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.White,
                                    activeTrackColor = ElectricPurple
                                ),
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }
                }
            }
        }

        // In Transition
        TransitionPickerCard(
            title = "In Transition",
            selectedType = layer.inTransition.type,
            durationMs = layer.inTransition.durationMs,
            accentColor = CyberBlue,
            onBeginSliderEdit = onBeginSliderEdit,
            onEndSliderEdit = onEndSliderEdit,
            onUpdate = onUpdateInTransition
        )

        // Out Transition
        TransitionPickerCard(
            title = "Out Transition",
            selectedType = layer.outTransition.type,
            durationMs = layer.outTransition.durationMs,
            accentColor = ElectricPurple,
            onBeginSliderEdit = onBeginSliderEdit,
            onEndSliderEdit = onEndSliderEdit,
            onUpdate = onUpdateOutTransition
        )
    }
}

@Composable
private fun TransitionPickerCard(
    title: String,
    selectedType: TransitionType,
    durationMs: Long,
    accentColor: Color,
    onBeginSliderEdit: () -> Unit,
    onEndSliderEdit: () -> Unit,
    onUpdate: (TransitionType, Long, Boolean) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = StudioSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(title, style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                Text(
                    text = if (selectedType == TransitionType.NONE) "Off" else "${durationMs}ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                TransitionType.entries.forEach { tType ->
                    val selected = tType == selectedType
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selected) accentColor.copy(alpha = 0.28f) else Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) accentColor else StudioBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onUpdate(tType, durationMs, true) }
                    ) {
                        Text(
                            text = tType.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) Color.White else TextSecondary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            if (selectedType != TransitionType.NONE) {
                Slider(
                    value = durationMs.toFloat(),
                    onValueChange = {
                        onBeginSliderEdit()
                        onUpdate(selectedType, it.toLong(), false)
                    },
                    onValueChangeFinished = onEndSliderEdit,
                    valueRange = 150f..2000f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = accentColor
                    ),
                    modifier = Modifier.height(26.dp)
                )
            }
        }
    }
}
