package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.model.ExportFormat
import com.example.model.ExportQuality
import com.example.model.ExportResolution
import com.example.model.LayerType
import com.example.model.MotionProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.roundToInt

data class ExportConfig(
    val format: ExportFormat = ExportFormat.MP4_VIDEO,
    val resolution: ExportResolution = ExportResolution.FHD_1080P,
    val fps: Int = 30,
    val quality: ExportQuality = ExportQuality.HIGH
)

data class ExportProgress(
    val fraction: Float,
    val statusText: String,
    val currentFrame: Int = 0,
    val totalFrames: Int = 0
)

data class ExportResult(
    val filePath: String,
    val shareUri: Uri,
    val galleryUri: Uri?,
    val format: ExportFormat,
    val resolution: ExportResolution,
    val width: Int,
    val height: Int,
    val fileSizeBytes: Long
)

class MediaExporter(
    private val context: Context,
    private val mediaManager: MediaManager
) {

    suspend fun export(
        project: MotionProject,
        playheadMs: Long,
        config: ExportConfig,
        onProgress: (ExportProgress) -> Unit
    ): ExportResult = withContext(Dispatchers.Default) {
        val (targetW, targetH) = project.aspectRatio.dimensionsFor(config.resolution)
        // Ensure even dimensions for H.264 compatibility
        val width = (targetW / 2) * 2
        val height = (targetH / 2) * 2

        when (config.format) {
            ExportFormat.PNG_IMAGE -> exportPng(project, playheadMs, width, height, config.resolution, onProgress)
            ExportFormat.MP4_VIDEO -> exportMp4(project, width, height, config, onProgress)
        }
    }

    private suspend fun exportPng(
        project: MotionProject,
        playheadMs: Long,
        width: Int,
        height: Int,
        resolution: ExportResolution,
        onProgress: (ExportProgress) -> Unit
    ): ExportResult {
        onProgress(ExportProgress(0.25f, "Rendering ${resolution.badge} frame (${width}x${height})..."))
        val bitmap = CompositionRenderer.renderToBitmap(
            project = project,
            timeMs = playheadMs,
            width = width,
            height = height,
            mediaManager = mediaManager,
            selectedLayerId = null,
            showGuides = false,
            exactVideoFrames = true
        )

        onProgress(ExportProgress(0.7f, "Encoding lossless PNG..."))
        val outFile = createExportFile(project.name, "png")
        try {
            FileOutputStream(outFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
        } catch (t: Throwable) {
            runCatching { outFile.delete() }
            throw t
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }

        val galleryUri = saveToMediaStore(outFile, isVideo = false, mimeType = "image/png")
        val shareUri = runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
        }.getOrElse { Uri.fromFile(outFile) }
        onProgress(ExportProgress(1f, "PNG Export Complete"))

        return ExportResult(
            filePath = outFile.absolutePath,
            shareUri = shareUri,
            galleryUri = galleryUri,
            format = ExportFormat.PNG_IMAGE,
            resolution = resolution,
            width = width,
            height = height,
            fileSizeBytes = outFile.length()
        )
    }

    private suspend fun exportMp4(
        project: MotionProject,
        width: Int,
        height: Int,
        config: ExportConfig,
        onProgress: (ExportProgress) -> Unit
    ): ExportResult {
        val fps = config.fps.coerceIn(15, 60)
        val totalFrames = max(1, ((project.durationMs / 1000.0) * fps).roundToInt())
        val outFile = createExportFile(project.name, "mp4")

        val baseBitrate = if (config.resolution == ExportResolution.UHD_4K) 32_000_000 else 12_000_000
        val requestedBitrate = (baseBitrate * config.quality.bitrateMultiplier).toInt()
        val (safeWidth, safeHeight, safeBitrate) = resolveSupportedEncoderConfig(width, height, requestedBitrate)

        try {
            // Try hardware Surface + EGL14 first, fallback to YUV Image/ByteBuffer encoder if EGL surface unsupported
            val surfaceSuccess = try {
                encodeMp4ViaSurface(project, outFile, safeWidth, safeHeight, fps, safeBitrate, totalFrames, onProgress)
                true
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                false
            }

            if (!surfaceSuccess) {
                if (outFile.exists()) outFile.delete()
                encodeMp4ViaByteBuffer(project, outFile, safeWidth, safeHeight, fps, safeBitrate, totalFrames, onProgress)
            }

            // If project has an active unmuted audio track, mux it cleanly into the MP4
            val activeAudioLayer = findPrimaryAudioLayer(project)
            if (activeAudioLayer != null) {
                onProgress(ExportProgress(0.94f, "Muxing audio track..."))
                val muxedTemp = File(outFile.parentFile, "mux_${outFile.name}")
                val muxedOk = muxAudioTrackIntoMp4(
                    videoOnlyMp4 = outFile,
                    audioSourcePath = activeAudioLayer.mediaPath!!,
                    audioTrimStartMs = activeAudioLayer.mediaTrimStartMs,
                    layerStartMs = activeAudioLayer.startTimeMs,
                    layerEndMs = minOf(activeAudioLayer.endTimeMs, project.durationMs),
                    outputMp4 = muxedTemp
                )
                if (muxedOk && muxedTemp.exists() && muxedTemp.length() > 0L) {
                    outFile.delete()
                    muxedTemp.renameTo(outFile)
                } else if (muxedTemp.exists()) {
                    muxedTemp.delete()
                }
            }

            if (!outFile.exists() || outFile.length() == 0L) {
                throw IllegalStateException("Encoded MP4 output file is empty")
            }

            onProgress(ExportProgress(0.98f, "Saving to Gallery..."))
            val galleryUri = saveToMediaStore(outFile, isVideo = true, mimeType = "video/mp4")
            val shareUri = runCatching {
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
            }.getOrElse { Uri.fromFile(outFile) }
            onProgress(ExportProgress(1f, "MP4 Export Complete", totalFrames, totalFrames))

            return ExportResult(
                filePath = outFile.absolutePath,
                shareUri = shareUri,
                galleryUri = galleryUri,
                format = ExportFormat.MP4_VIDEO,
                resolution = config.resolution,
                width = safeWidth,
                height = safeHeight,
                fileSizeBytes = outFile.length()
            )
        } catch (t: Throwable) {
            runCatching { outFile.delete() }
            throw t
        }
    }

    private fun resolveSupportedEncoderConfig(
        requestedW: Int,
        requestedH: Int,
        requestedBitrate: Int
    ): Triple<Int, Int, Int> {
        val fallback = Triple((requestedW / 2) * 2, (requestedH / 2) * 2, requestedBitrate)
        val caps = runCatching {
            val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
                .filter { info ->
                    info.isEncoder && info.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) }
                }
            val preferred = infos.firstOrNull { info ->
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !info.isSoftwareOnly
            } ?: infos.firstOrNull()
            preferred?.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)?.videoCapabilities
        }.getOrNull() ?: return fallback

        val clampedBitrate = caps.bitrateRange?.clamp(requestedBitrate) ?: requestedBitrate
        val alignW = caps.widthAlignment.coerceAtLeast(2)
        val alignH = caps.heightAlignment.coerceAtLeast(2)
        val alignedReqW = ((requestedW / alignW) * alignW).coerceAtLeast(alignW)
        val alignedReqH = ((requestedH / alignH) * alignH).coerceAtLeast(alignH)
        if (caps.isSizeSupported(alignedReqW, alignedReqH)) {
            return Triple(alignedReqW, alignedReqH, clampedBitrate)
        }

        val ratio = requestedW.toFloat() / requestedH.toFloat().coerceAtLeast(1f)
        for (scale in listOf(0.75f, 0.5f, 0.375f, 0.25f)) {
            val candW = (((requestedW * scale).roundToInt() / alignW) * alignW).coerceAtLeast(alignW * 8)
            val candH = (((candW / ratio).roundToInt() / alignH) * alignH).coerceAtLeast(alignH * 8)
            if (caps.isSizeSupported(candW, candH)) {
                return Triple(candW, candH, clampedBitrate)
            }
        }
        return Triple(alignedReqW.coerceAtMost(1920), alignedReqH.coerceAtMost(1080), clampedBitrate)
    }

    private suspend fun encodeMp4ViaSurface(
        project: MotionProject,
        outFile: File,
        width: Int,
        height: Int,
        fps: Int,
        bitrate: Int,
        totalFrames: Int,
        onProgress: (ExportProgress) -> Unit
    ) {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var glPusher: GlSurfaceFramePusher? = null
        var muxerStarted = false

        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = encoder.createInputSurface()
            encoder.start()

            glPusher = GlSurfaceFramePusher(inputSurface, width, height).apply { init() }

            val bufferInfo = MediaCodec.BufferInfo()
            var videoTrackIndex = -1

            fun drainEncoder(endOfStream: Boolean) {
                if (endOfStream) encoder.signalEndOfInputStream()
                while (true) {
                    val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000L)
                    when {
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream) break
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val newFormat = encoder.outputFormat
                            videoTrackIndex = muxer.addTrack(newFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                        outIndex >= 0 -> {
                            val encodedData = encoder.getOutputBuffer(outIndex)
                            if (encodedData != null && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && bufferInfo.size > 0 && muxerStarted) {
                                encodedData.position(bufferInfo.offset)
                                encodedData.limit(bufferInfo.offset + bufferInfo.size)
                                muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                            }
                            encoder.releaseOutputBuffer(outIndex, false)
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                        }
                    }
                }
            }

            val frameDurationNs = 1_000_000_000L / fps
            for (frameIdx in 0 until totalFrames) {
                coroutineContext.ensureActive()
                val timeMs = ((frameIdx.toDouble() / fps.toDouble()) * 1000.0).roundToInt().toLong()
                    .coerceAtMost(project.durationMs)
                val bitmap = CompositionRenderer.renderToBitmap(
                    project = project,
                    timeMs = timeMs,
                    width = width,
                    height = height,
                    mediaManager = mediaManager,
                    selectedLayerId = null,
                    showGuides = false,
                    exactVideoFrames = true
                )
                glPusher.pushBitmapFrame(bitmap, frameIdx * frameDurationNs)
                bitmap.recycle()

                drainEncoder(endOfStream = false)

                val progressFraction = ((frameIdx + 1).toFloat() / totalFrames.toFloat()) * 0.9f
                onProgress(
                    ExportProgress(
                        fraction = progressFraction,
                        statusText = "Encoding frame ${frameIdx + 1} / $totalFrames",
                        currentFrame = frameIdx + 1,
                        totalFrames = totalFrames
                    )
                )
            }

            drainEncoder(endOfStream = true)
        } finally {
            glPusher?.release()
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
    }

    private suspend fun encodeMp4ViaByteBuffer(
        project: MotionProject,
        outFile: File,
        width: Int,
        height: Int,
        fps: Int,
        bitrate: Int,
        totalFrames: Int,
        onProgress: (ExportProgress) -> Unit
    ) {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerStarted = false
        var videoTrackIndex = -1

        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            val bufferInfo = MediaCodec.BufferInfo()
            val frameDurationUs = 1_000_000L / fps
            val argbBuffer = IntArray(width * height)
            val yuvSize = width * height * 3 / 2
            val yuvBytes = ByteArray(yuvSize)

            fun drainOutput(waitForEos: Boolean) {
                while (true) {
                    val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000L)
                    when {
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!waitForEos) break
                        }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                        outIndex >= 0 -> {
                            val outBuf = encoder.getOutputBuffer(outIndex)
                            if (outBuf != null && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && bufferInfo.size > 0 && muxerStarted) {
                                outBuf.position(bufferInfo.offset)
                                outBuf.limit(bufferInfo.offset + bufferInfo.size)
                                muxer.writeSampleData(videoTrackIndex, outBuf, bufferInfo)
                            }
                            encoder.releaseOutputBuffer(outIndex, false)
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                        }
                    }
                }
            }

            for (frameIdx in 0 until totalFrames) {
                coroutineContext.ensureActive()
                val timeMs = ((frameIdx.toDouble() / fps.toDouble()) * 1000.0).roundToInt().toLong()
                    .coerceAtMost(project.durationMs)
                val bitmap = CompositionRenderer.renderToBitmap(
                    project = project,
                    timeMs = timeMs,
                    width = width,
                    height = height,
                    mediaManager = mediaManager,
                    selectedLayerId = null,
                    showGuides = false,
                    exactVideoFrames = true
                )
                bitmap.getPixels(argbBuffer, 0, width, 0, 0, width, height)
                bitmap.recycle()

                val inIndex = encoder.dequeueInputBuffer(20_000L)
                if (inIndex >= 0) {
                    val inputImage = runCatching { encoder.getInputImage(inIndex) }.getOrNull()
                    if (inputImage != null && inputImage.planes.size >= 3) {
                        fillYuvImageFromArgb(argbBuffer, width, height, inputImage)
                        inputImage.close()
                        encoder.queueInputBuffer(inIndex, 0, yuvSize, frameIdx * frameDurationUs, 0)
                    } else {
                        encodeArgbToNv12(argbBuffer, yuvBytes, width, height)
                        val inBuf = encoder.getInputBuffer(inIndex)!!
                        inBuf.clear()
                        val copyLen = yuvSize.coerceAtMost(inBuf.remaining())
                        inBuf.put(yuvBytes, 0, copyLen)
                        encoder.queueInputBuffer(inIndex, 0, copyLen, frameIdx * frameDurationUs, 0)
                    }
                }

                drainOutput(waitForEos = false)
                onProgress(
                    ExportProgress(
                        fraction = ((frameIdx + 1).toFloat() / totalFrames.toFloat()) * 0.9f,
                        statusText = "Encoding frame ${frameIdx + 1} / $totalFrames",
                        currentFrame = frameIdx + 1,
                        totalFrames = totalFrames
                    )
                )
            }

            val eosIndex = encoder.dequeueInputBuffer(20_000L)
            if (eosIndex >= 0) {
                encoder.queueInputBuffer(eosIndex, 0, 0, totalFrames * frameDurationUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drainOutput(waitForEos = true)
        } finally {
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
    }

    private fun fillYuvImageFromArgb(argb: IntArray, width: Int, height: Int, image: Image) {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val yBuf = yPlane.buffer
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer
        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        val uRowStride = uPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixelStride = vPlane.pixelStride

        for (j in 0 until height) {
            val yRowOffset = j * yRowStride
            val uvRowOffsetU = (j shr 1) * uRowStride
            val uvRowOffsetV = (j shr 1) * vRowStride
            for (i in 0 until width) {
                val pixel = argb[j * width + i]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val y = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255)
                val yPos = yRowOffset + i * yPixelStride
                if (yPos < yBuf.capacity()) {
                    yBuf.put(yPos, y.toByte())
                }
                if ((j and 1) == 0 && (i and 1) == 0) {
                    val uvCol = i shr 1
                    val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val uPos = uvRowOffsetU + uvCol * uPixelStride
                    val vPos = uvRowOffsetV + uvCol * vPixelStride
                    if (uPos < uBuf.capacity()) uBuf.put(uPos, u.toByte())
                    if (vPos < vBuf.capacity()) vBuf.put(vPos, v.toByte())
                }
            }
        }
    }

    private fun encodeArgbToNv12(argb: IntArray, yuv: ByteArray, width: Int, height: Int) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize
        for (j in 0 until height) {
            for (i in 0 until width) {
                val pixel = argb[j * width + i]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                yuv[yIndex++] = y.coerceIn(0, 255).toByte()
                if (j % 2 == 0 && i % 2 == 0 && uvIndex + 1 < yuv.size) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    yuv[uvIndex++] = u.coerceIn(0, 255).toByte()
                    yuv[uvIndex++] = v.coerceIn(0, 255).toByte()
                }
            }
        }
    }

    private fun findPrimaryAudioLayer(project: MotionProject): com.example.model.MotionLayer? {
        val audioCapable = project.layers.filter {
            (it.type == LayerType.AUDIO || (it.type == LayerType.VIDEO && it.isVisible)) &&
                !it.mediaPath.isNullOrBlank() &&
                File(it.mediaPath).exists()
        }
        val anySolo = audioCapable.any { it.isSolo }
        return audioCapable.firstOrNull { !it.isMuted && (!anySolo || it.isSolo) }
    }

    private fun muxAudioTrackIntoMp4(
        videoOnlyMp4: File,
        audioSourcePath: String,
        audioTrimStartMs: Long,
        layerStartMs: Long,
        layerEndMs: Long,
        outputMp4: File
    ): Boolean = runCatching {
        val videoExtractor = MediaExtractor()
        val audioExtractor = MediaExtractor()
        val muxer = MediaMuxer(outputMp4.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerStarted = false

        try {
            videoExtractor.setDataSource(videoOnlyMp4.absolutePath)
            var vTrack = -1
            for (i in 0 until videoExtractor.trackCount) {
                val fmt = videoExtractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                    vTrack = i
                    break
                }
            }
            if (vTrack < 0) return false
            videoExtractor.selectTrack(vTrack)
            val muxVideoTrack = muxer.addTrack(videoExtractor.getTrackFormat(vTrack))

            audioExtractor.setDataSource(audioSourcePath)
            var aTrack = -1
            for (i in 0 until audioExtractor.trackCount) {
                val fmt = audioExtractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime == MediaFormat.MIMETYPE_AUDIO_AAC || mime.startsWith("audio/mp4a")) {
                    aTrack = i
                    break
                }
            }
            if (aTrack < 0) return false
            audioExtractor.selectTrack(aTrack)
            val muxAudioTrack = muxer.addTrack(audioExtractor.getTrackFormat(aTrack))

            muxer.start()
            muxerStarted = true

            val buffer = java.nio.ByteBuffer.allocate(512 * 1024)
            val info = MediaCodec.BufferInfo()
            var lastVideoPtsUs = -1L

            while (true) {
                val size = videoExtractor.readSampleData(buffer, 0)
                if (size < 0) break
                val rawPts = videoExtractor.sampleTime.coerceAtLeast(0L)
                val monotonicPts = max(rawPts, lastVideoPtsUs + 1L)
                lastVideoPtsUs = monotonicPts
                info.offset = 0
                info.size = size
                info.presentationTimeUs = monotonicPts
                info.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(muxVideoTrack, buffer, info)
                videoExtractor.advance()
            }

            audioExtractor.seekTo(audioTrimStartMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val startOffsetUs = layerStartMs * 1000L
            val trimStartUs = audioTrimStartMs * 1000L
            val endUs = layerEndMs * 1000L
            var lastAudioPtsUs = -1L

            while (true) {
                val size = audioExtractor.readSampleData(buffer, 0)
                if (size < 0) break
                val sampleUs = audioExtractor.sampleTime
                val outUs = startOffsetUs + (sampleUs - trimStartUs)
                if (outUs > endUs) break
                if (outUs >= 0L) {
                    val monotonicAudioPts = max(outUs, lastAudioPtsUs + 1L)
                    lastAudioPtsUs = monotonicAudioPts
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = monotonicAudioPts
                    info.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(muxAudioTrack, buffer, info)
                }
                audioExtractor.advance()
            }
            true
        } finally {
            runCatching { videoExtractor.release() }
            runCatching { audioExtractor.release() }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
    }.getOrDefault(false)

    private fun createExportFile(projectName: String, ext: String): File {
        val safeName = projectName.replace(Regex("[^A-Za-z0-9_-]"), "_").take(24).ifEmpty { "MasterMotion" }
        val dir = File(context.filesDir, "exports").apply { if (!exists()) mkdirs() }
        return File(dir, "${safeName}_${System.currentTimeMillis()}.$ext")
    }

    private fun saveToMediaStore(file: File, isVideo: Boolean, mimeType: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            val resolver = context.contentResolver
            val collection = if (isVideo) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val relativePath = if (isVideo) {
                "${Environment.DIRECTORY_MOVIES}/Master Motion"
            } else {
                "${Environment.DIRECTORY_PICTURES}/Master Motion"
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val itemUri = resolver.insert(collection, values) ?: return null
            resolver.openOutputStream(itemUri)?.use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(itemUri, values, null, null)
            itemUri
        }.getOrNull()
    }
}
