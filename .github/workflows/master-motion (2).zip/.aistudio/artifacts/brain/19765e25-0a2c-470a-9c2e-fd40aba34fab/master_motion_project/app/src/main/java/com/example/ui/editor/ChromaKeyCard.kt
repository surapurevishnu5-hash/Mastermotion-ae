package com.example.ui.editor

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.engine.MediaManager
import com.example.model.LayerEffect
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private data class ChromaPresetSwatch(
    val label: String,
    val colorHex: Long
)

private val chromaPresetSwatches = listOf(
    ChromaPresetSwatch("Green", 0xFF00D84AL),
    ChromaPresetSwatch("Neon", 0xFF00FF00L),
    ChromaPresetSwatch("Blue", 0xFF0047FFL),
    ChromaPresetSwatch("Cyan", 0xFF00E5FFL),
    ChromaPresetSwatch("Magenta", 0xFFFF00AAL),
    ChromaPresetSwatch("Black", 0xFF000000L)
)

@Composable
fun ChromaKeyEffectCard(
    layer: MotionLayer,
    effect: LayerEffect,
    playheadMs: Long,
    mediaManager: MediaManager?,
    onToggleEnabled: () -> Unit,
    onUpdateChromaKey: (keyColorHex: Long?, tolerance: Float?, spillSuppression: Float?, recordUndo: Boolean) -> Unit,
    onBeginSliderEdit: () -> Unit,
    onEndSliderEdit: () -> Unit,
    onRemove: () -> Unit
) {
    var showColorPickerDialog by remember { mutableStateOf(false) }
    val keyColor = Color(effect.keyColorHex)
    val hexFormatted = remember(effect.keyColorHex) {
        String.format(Locale.US, "#%06X", (effect.keyColorHex.toInt() and 0xFFFFFF))
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = StudioSurfaceElevated,
        border = BorderStroke(
            1.dp,
            if (effect.enabled) SuccessGreen.copy(alpha = 0.6f) else StudioBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chroma_key_card")
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(12.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(keyColor)
                        .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Chroma Key (Green Screen)",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (layer.type == LayerType.VIDEO || layer.type == LayerType.IMAGE) {
                            "Removes key color in preview & export"
                        } else {
                            "Best applied to Video or Image layers"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                Switch(
                    checked = effect.enabled,
                    onCheckedChange = { onToggleEnabled() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = SuccessGreen
                    ),
                    modifier = Modifier.testTag("chroma_key_switch")
                )
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("chroma_key_remove_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Remove Chroma Key",
                        tint = ErrorCoral,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Key Color Picker Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Key Color", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StudioInspector,
                        border = BorderStroke(1.dp, StudioBorder)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(keyColor)
                                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = hexFormatted,
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan,
                                modifier = Modifier.testTag("chroma_key_color_hex")
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ElectricPurple.copy(alpha = 0.22f),
                    border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = effect.enabled) { showColorPickerDialog = true }
                        .testTag("chroma_key_picker_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Colorize,
                            contentDescription = "Select Key Color",
                            tint = CyberCyan,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Pick Color",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Preset Swatches
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                chromaPresetSwatches.forEachIndexed { idx, swatch ->
                    val isSelected = (effect.keyColorHex.toInt() and 0xFFFFFF) == (swatch.colorHex.toInt() and 0xFFFFFF)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(swatch.colorHex))
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color.White else StudioBorder,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .clickable(enabled = effect.enabled) {
                                onUpdateChromaKey(swatch.colorHex, null, null, true)
                            }
                            .testTag("chroma_swatch_$idx")
                    ) {
                        if (isSelected) {
                            val luminance = AndroidColor.luminance(swatch.colorHex.toInt())
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = "${swatch.label} selected",
                                tint = if (luminance > 0.55f) Color.Black else Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Tolerance Slider
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Tolerance", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                    Text(
                        text = "${(effect.intensity * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier.testTag("chroma_key_tolerance_value")
                    )
                }
                Slider(
                    value = effect.intensity,
                    onValueChange = { next ->
                        onBeginSliderEdit()
                        onUpdateChromaKey(null, next, null, false)
                    },
                    onValueChangeFinished = onEndSliderEdit,
                    enabled = effect.enabled,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = SuccessGreen,
                        inactiveTrackColor = StudioBorder
                    ),
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("chroma_key_tolerance_slider")
                )
            }

            // Spill Suppression Slider
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Spill Suppression", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                    Text(
                        text = "${(effect.spillSuppression * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier.testTag("chroma_key_spill_value")
                    )
                }
                Slider(
                    value = effect.spillSuppression,
                    onValueChange = { next ->
                        onBeginSliderEdit()
                        onUpdateChromaKey(null, null, next, false)
                    },
                    onValueChangeFinished = onEndSliderEdit,
                    enabled = effect.enabled,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = ElectricPurple,
                        inactiveTrackColor = StudioBorder
                    ),
                    modifier = Modifier
                        .height(30.dp)
                        .testTag("chroma_key_spill_slider")
                )
            }
        }
    }

    if (showColorPickerDialog) {
        ChromaColorPickerDialog(
            layer = layer,
            initialColorHex = effect.keyColorHex,
            playheadMs = playheadMs,
            mediaManager = mediaManager,
            onDismiss = { showColorPickerDialog = false },
            onConfirm = { chosenHex ->
                onUpdateChromaKey(chosenHex, null, null, true)
                showColorPickerDialog = false
            }
        )
    }
}

@Composable
private fun ChromaColorPickerDialog(
    layer: MotionLayer,
    initialColorHex: Long,
    playheadMs: Long,
    mediaManager: MediaManager?,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit
) {
    var selectedHex by remember(initialColorHex) { mutableLongStateOf(initialColorHex) }
    var red by remember(initialColorHex) { mutableFloatStateOf(AndroidColor.red(initialColorHex.toInt()) / 255f) }
    var green by remember(initialColorHex) { mutableFloatStateOf(AndroidColor.green(initialColorHex.toInt()) / 255f) }
    var blue by remember(initialColorHex) { mutableFloatStateOf(AndroidColor.blue(initialColorHex.toInt()) / 255f) }
    var samplePointNorm by remember { mutableStateOf<Offset?>(null) }
    var frameBoxSize by remember { mutableStateOf(IntSize.Zero) }
    var spectrumSize by remember { mutableStateOf(IntSize.Zero) }

    val frameBitmap by produceState<Bitmap?>(initialValue = null, layer.id, layer.mediaPath, playheadMs) {
        value = withContext(Dispatchers.IO) {
            val path = layer.mediaPath ?: return@withContext null
            when (layer.type) {
                LayerType.VIDEO -> {
                    val mediaTime = (layer.mediaTrimStartMs + (playheadMs - layer.startTimeMs)).coerceAtLeast(0L)
                    mediaManager?.getVideoFrame(path, mediaTime, exactFrame = false, maxDimension = 480)
                }
                LayerType.IMAGE -> mediaManager?.getImageBitmap(path, maxDimension = 480)
                else -> null
            }
        }
    }

    fun updateFromRgb(r: Float, g: Float, b: Float) {
        red = r.coerceIn(0f, 1f)
        green = g.coerceIn(0f, 1f)
        blue = b.coerceIn(0f, 1f)
        val argb = AndroidColor.rgb(
            (red * 255f).toInt().coerceIn(0, 255),
            (green * 255f).toInt().coerceIn(0, 255),
            (blue * 255f).toInt().coerceIn(0, 255)
        )
        selectedHex = argb.toLong() and 0xFFFFFFFFL
    }

    fun updateFromSpectrumOffset(offset: Offset) {
        if (spectrumSize.width <= 0 || spectrumSize.height <= 0) return
        val hue = ((offset.x / spectrumSize.width.toFloat()).coerceIn(0f, 1f)) * 360f
        val yNorm = (offset.y / spectrumSize.height.toFloat()).coerceIn(0f, 1f)
        val sat = if (yNorm < 0.5f) 1f else (1f - (yNorm - 0.5f) * 1.4f).coerceIn(0.2f, 1f)
        val value = if (yNorm < 0.5f) (0.35f + yNorm * 1.3f).coerceIn(0.35f, 1f) else 1f
        val argb = AndroidColor.HSVToColor(floatArrayOf(hue, sat, value))
        updateFromRgb(
            AndroidColor.red(argb) / 255f,
            AndroidColor.green(argb) / 255f,
            AndroidColor.blue(argb) / 255f
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurface,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(Color(selectedHex))
                        .border(1.5.dp, Color.White, CircleShape)
                )
                Text("Select Chroma Key Color", color = TextPrimary)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .testTag("chroma_color_picker_dialog")
            ) {
                val validFrame = frameBitmap?.takeIf { !it.isRecycled }
                if (validFrame != null) {
                    val frameAspect = (validFrame.width.toFloat() / validFrame.height.toFloat().coerceAtLeast(1f))
                        .coerceIn(0.6f, 2.2f)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FilterCenterFocus,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "Tap video frame to sample background color",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 170.dp)
                            .aspectRatio(frameAspect, matchHeightConstraintsFirst = frameAspect < 1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(ObsidianBg)
                            .border(1.dp, StudioBorder, RoundedCornerShape(10.dp))
                            .onSizeChanged { frameBoxSize = it }
                            .pointerInput(validFrame) {
                                detectTapGestures { tap ->
                                    if (frameBoxSize.width > 0 && frameBoxSize.height > 0) {
                                        val nx = (tap.x / frameBoxSize.width.toFloat()).coerceIn(0f, 1f)
                                        val ny = (tap.y / frameBoxSize.height.toFloat()).coerceIn(0f, 1f)
                                        samplePointNorm = Offset(nx, ny)
                                        val pxX = (nx * (validFrame.width - 1)).toInt().coerceIn(0, validFrame.width - 1)
                                        val pxY = (ny * (validFrame.height - 1)).toInt().coerceIn(0, validFrame.height - 1)
                                        val pixel = validFrame.getPixel(pxX, pxY)
                                        updateFromRgb(
                                            AndroidColor.red(pixel) / 255f,
                                            AndroidColor.green(pixel) / 255f,
                                            AndroidColor.blue(pixel) / 255f
                                        )
                                    }
                                }
                            }
                            .testTag("chroma_frame_eyedropper_surface")
                    ) {
                        Image(
                            bitmap = validFrame.asImageBitmap(),
                            contentDescription = "Frame Color Sampler",
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier.fillMaxSize()
                        )
                        samplePointNorm?.let { pt ->
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val center = Offset(pt.x * size.width, pt.y * size.height)
                                drawCircle(Color.White, radius = 12f, center = center, style = Stroke(width = 3f))
                                drawCircle(Color(selectedHex), radius = 8f, center = center)
                            }
                        }
                    }
                }

                // Interactive Hue Spectrum Pad
                Text("Color Spectrum", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, StudioBorder, RoundedCornerShape(10.dp))
                        .onSizeChanged { spectrumSize = it }
                        .pointerInput(Unit) {
                            detectTapGestures { updateFromSpectrumOffset(it) }
                        }
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                updateFromSpectrumOffset(change.position)
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawRect(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    Color.Red,
                                    Color.Yellow,
                                    Color.Green,
                                    Color.Cyan,
                                    Color.Blue,
                                    Color.Magenta,
                                    Color.Red
                                )
                            )
                        )
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.45f),
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.45f)
                                )
                            )
                        )
                    }
                }

                // Fine RGB Sliders
                RgbChannelSlider("R", red, Color(0xFFEF4444), "chroma_picker_r_slider") {
                    updateFromRgb(it, green, blue)
                }
                RgbChannelSlider("G", green, Color(0xFF22C55E), "chroma_picker_g_slider") {
                    updateFromRgb(red, it, blue)
                }
                RgbChannelSlider("B", blue, Color(0xFF3B82F6), "chroma_picker_b_slider") {
                    updateFromRgb(red, green, it)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(selectedHex) },
                modifier = Modifier.testTag("confirm_chroma_color_button")
            ) {
                Text("Apply Color", color = CyberCyan)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun RgbChannelSlider(
    channel: String,
    value: Float,
    tint: Color,
    tag: String,
    onChange: (Float) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = channel,
            style = MaterialTheme.typography.labelMedium,
            color = tint,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(16.dp)
        )
        Slider(
            value = value,
            onValueChange = onChange,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = tint,
                inactiveTrackColor = StudioBorder
            ),
            modifier = Modifier
                .weight(1f)
                .height(26.dp)
                .testTag(tag)
        )
        Text(
            text = "${(value * 255).toInt()}",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            modifier = Modifier.width(28.dp)
        )
    }
}
