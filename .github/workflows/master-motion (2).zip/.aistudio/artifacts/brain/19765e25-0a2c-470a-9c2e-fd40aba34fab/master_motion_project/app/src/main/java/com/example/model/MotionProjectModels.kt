package com.example.model

import com.squareup.moshi.JsonClass
import java.util.UUID

@JsonClass(generateAdapter = true)
data class MotionProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Motion",
    val aspectRatio: AspectRatioPreset = AspectRatioPreset.RATIO_16_9,
    val fps: Int = 30,
    val durationMs: Long = 8000L,
    val backgroundColorHex: Long = 0xFF0A0B10L,
    val masterVolume: Float = 1.0f,
    val layers: List<MotionLayer> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class AspectRatioPreset(
    val label: String,
    val ratioWidth: Int,
    val ratioHeight: Int,
    val fhdWidth: Int,
    val fhdHeight: Int,
    val uhd4kWidth: Int,
    val uhd4kHeight: Int
) {
    RATIO_16_9("16:9", 16, 9, 1920, 1080, 3840, 2160),
    RATIO_9_16("9:16", 9, 16, 1080, 1920, 2160, 3840),
    RATIO_1_1("1:1", 1, 1, 1080, 1080, 2160, 2160),
    RATIO_4_5("4:5", 4, 5, 1080, 1350, 2160, 2700);

    val ratio: Float get() = ratioWidth.toFloat() / ratioHeight.toFloat()

    fun dimensionsFor(resolution: ExportResolution): Pair<Int, Int> = when (resolution) {
        ExportResolution.FHD_1080P -> fhdWidth to fhdHeight
        ExportResolution.UHD_4K -> uhd4kWidth to uhd4kHeight
    }
}

enum class ExportResolution(val label: String, val badge: String) {
    FHD_1080P("1080p Full HD", "1080P"),
    UHD_4K("4K Ultra HD", "4K UHD")
}

enum class ExportFormat(val label: String, val extension: String) {
    MP4_VIDEO("MP4 Video", "mp4"),
    PNG_IMAGE("PNG Frame", "png")
}

enum class ExportQuality(val label: String, val bitrateMultiplier: Float) {
    STANDARD("Standard", 1.0f),
    HIGH("High", 1.6f),
    STUDIO("Studio Master", 2.4f)
}

enum class LayerType(val label: String) {
    VIDEO("Video"),
    IMAGE("Image"),
    AUDIO("Audio"),
    SHAPE("Shape"),
    TEXT("Text")
}

enum class ShapeType(val label: String) {
    RECTANGLE("Rectangle"),
    ROUNDED_CARD("Gradient Card"),
    CIRCLE("Circle"),
    STAR("Star Burst"),
    DIAMOND("Diamond")
}

enum class BlendModeType(val label: String) {
    NORMAL("Normal"),
    ADD("Add"),
    SCREEN("Screen"),
    MULTIPLY("Multiply")
}

enum class AnimatableProperty(
    val label: String,
    val unit: String,
    val minValue: Float,
    val maxValue: Float,
    val defaultValue: Float,
    val is3D: Boolean = false
) {
    POSITION_X("Position X", "", -1.5f, 1.5f, 0f),
    POSITION_Y("Position Y", "", -1.5f, 1.5f, 0f),
    SCALE_X("Scale X", "x", 0.05f, 4.0f, 1f),
    SCALE_Y("Scale Y", "x", 0.05f, 4.0f, 1f),
    ROTATION_Z("Rotation Z", "°", -720f, 720f, 0f),
    OPACITY("Opacity", "%", 0f, 1f, 1f),
    ROTATION_X("3D Pitch (X)", "°", -180f, 180f, 0f, is3D = true),
    ROTATION_Y("3D Yaw (Y)", "°", -180f, 180f, 0f, is3D = true),
    DEPTH_Z("3D Depth (Z)", "", -1.5f, 1.5f, 0f, is3D = true);

    companion object {
        val properties2D: List<AnimatableProperty>
            get() = entries.filter { !it.is3D }

        val properties3D: List<AnimatableProperty>
            get() = entries.filter { it.is3D }
    }
}

@JsonClass(generateAdapter = true)
data class CubicBezierCurve(
    val x1: Float = 0.42f,
    val y1: Float = 0f,
    val x2: Float = 0.58f,
    val y2: Float = 1f,
    val isStep: Boolean = false,
    val presetName: String = "Ease In-Out"
) {
    companion object {
        val LINEAR = CubicBezierCurve(0.0f, 0.0f, 1.0f, 1.0f, presetName = "Linear")
        val EASE_IN = CubicBezierCurve(0.42f, 0.0f, 1.0f, 1.0f, presetName = "Ease In")
        val EASE_OUT = CubicBezierCurve(0.0f, 0.0f, 0.58f, 1.0f, presetName = "Ease Out")
        val EASE_IN_OUT = CubicBezierCurve(0.42f, 0.0f, 0.58f, 1.0f, presetName = "Ease In-Out")
        val OVERSHOOT = CubicBezierCurve(0.34f, 1.56f, 0.64f, 1.0f, presetName = "Overshoot")
        val ELASTIC_SNAP = CubicBezierCurve(0.16f, 1.35f, 0.3f, 1.0f, presetName = "Snap Pop")
        val HOLD = CubicBezierCurve(0f, 0f, 1f, 1f, isStep = true, presetName = "Hold")

        val presets = listOf(
            LINEAR,
            EASE_IN,
            EASE_OUT,
            EASE_IN_OUT,
            OVERSHOOT,
            ELASTIC_SNAP,
            HOLD
        )
    }
}

@JsonClass(generateAdapter = true)
data class Keyframe(
    val id: String = UUID.randomUUID().toString(),
    val timeMs: Long,
    val value: Float,
    val curve: CubicBezierCurve = CubicBezierCurve.EASE_IN_OUT
)

@JsonClass(generateAdapter = true)
data class TransformValues(
    val posX: Float = 0f,
    val posY: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotationZ: Float = 0f,
    val rotationX: Float = 0f,
    val rotationY: Float = 0f,
    val depthZ: Float = 0f,
    val opacity: Float = 1f,
    val cameraDistance: Float = 12f
) {
    fun getProperty(property: AnimatableProperty): Float = when (property) {
        AnimatableProperty.POSITION_X -> posX
        AnimatableProperty.POSITION_Y -> posY
        AnimatableProperty.SCALE_X -> scaleX
        AnimatableProperty.SCALE_Y -> scaleY
        AnimatableProperty.ROTATION_Z -> rotationZ
        AnimatableProperty.OPACITY -> opacity
        AnimatableProperty.ROTATION_X -> rotationX
        AnimatableProperty.ROTATION_Y -> rotationY
        AnimatableProperty.DEPTH_Z -> depthZ
    }

    fun withProperty(property: AnimatableProperty, value: Float): TransformValues = when (property) {
        AnimatableProperty.POSITION_X -> copy(posX = value)
        AnimatableProperty.POSITION_Y -> copy(posY = value)
        AnimatableProperty.SCALE_X -> copy(scaleX = value)
        AnimatableProperty.SCALE_Y -> copy(scaleY = value)
        AnimatableProperty.ROTATION_Z -> copy(rotationZ = value)
        AnimatableProperty.OPACITY -> copy(opacity = value.coerceIn(0f, 1f))
        AnimatableProperty.ROTATION_X -> copy(rotationX = value)
        AnimatableProperty.ROTATION_Y -> copy(rotationY = value)
        AnimatableProperty.DEPTH_Z -> copy(depthZ = value)
    }
}

enum class EffectType(val label: String, val defaultIntensity: Float) {
    CHROMA_KEY("Chroma Key", 0.35f),
    BLUR("Gaussian Blur", 0.35f),
    GLOW("Neon Glow", 0.65f),
    BRIGHTNESS("Brightness", 0.5f),
    CONTRAST("Contrast", 0.6f),
    SATURATION("Saturation", 0.7f),
    MONO_NOIR("Noir B&W Filter", 0.85f),
    SEPIA("Vintage Sepia", 0.75f),
    VIGNETTE("Cinematic Vignette", 0.55f),
    PIXELATE("Pixel Mosaic", 0.3f)
}

@JsonClass(generateAdapter = true)
data class LayerEffect(
    val id: String = UUID.randomUUID().toString(),
    val type: EffectType,
    val intensity: Float = type.defaultIntensity,
    val enabled: Boolean = true,
    val keyColorHex: Long = 0xFF00D84AL,
    val spillSuppression: Float = 0.55f
)

enum class TransitionType(val label: String) {
    NONE("None"),
    FADE("Fade"),
    SLIDE_LEFT("Slide Left"),
    SLIDE_RIGHT("Slide Right"),
    SLIDE_UP("Slide Up"),
    ZOOM_POP("Zoom Pop"),
    FLIP_3D("3D Flip"),
    WIPE_HORIZONTAL("Wipe Reveal")
}

@JsonClass(generateAdapter = true)
data class LayerTransition(
    val type: TransitionType = TransitionType.NONE,
    val durationMs: Long = 500L
)

@JsonClass(generateAdapter = true)
data class MotionLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: LayerType,
    val startTimeMs: Long = 0L,
    val endTimeMs: Long = 5000L,
    val mediaPath: String? = null,
    val mediaTrimStartMs: Long = 0L,
    val mediaDurationMs: Long = 5000L,
    val mediaWidth: Int = 0,
    val mediaHeight: Int = 0,
    val volume: Float = 1f,
    val isMuted: Boolean = false,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val isSolo: Boolean = false,
    val zIndex: Int = 0,
    val blendMode: BlendModeType = BlendModeType.NORMAL,
    val colorHex: Long = 0xFF8B5CF6L,
    val secondaryColorHex: Long = 0xFF3B82F6L,
    val shapeType: ShapeType = ShapeType.ROUNDED_CARD,
    val textContent: String = "MASTER MOTION",
    val textSizeSp: Float = 44f,
    val waveformSamples: List<Float> = emptyList(),
    val baseTransform: TransformValues = TransformValues(),
    val keyframeTracks: Map<String, List<Keyframe>> = emptyMap(),
    val effects: List<LayerEffect> = emptyList(),
    val inTransition: LayerTransition = LayerTransition(),
    val outTransition: LayerTransition = LayerTransition()
) {
    fun keyframesFor(property: AnimatableProperty): List<Keyframe> =
        (keyframeTracks[property.name] ?: emptyList()).sortedBy { it.timeMs }

    fun allKeyframeTimes(): List<Long> =
        keyframeTracks.values.flatten().map { it.timeMs }.distinct().sorted()

    fun isActiveAt(timeMs: Long): Boolean =
        timeMs in startTimeMs..endTimeMs
}
