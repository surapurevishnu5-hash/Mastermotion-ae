package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.ExportsRepository
import com.example.data.ProjectDao
import com.example.data.ProjectRepository
import com.example.engine.MediaExporter
import com.example.engine.MediaManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            AppDatabase.DATABASE_NAME
        )
            .addMigrations(AppDatabase.MIGRATION_1_2)
            .build()
    }

    @Provides
    @Singleton
    fun provideProjectDao(database: AppDatabase): ProjectDao {
        return database.projectDao()
    }

    @Provides
    @Singleton
    fun provideMediaManager(
        @ApplicationContext context: Context
    ): MediaManager {
        return MediaManager(context)
    }

    @Provides
    @Singleton
    fun provideProjectRepository(
        @ApplicationContext context: Context,
        projectDao: ProjectDao,
        mediaManager: MediaManager
    ): ProjectRepository {
        return ProjectRepository(context, projectDao, mediaManager)
    }

    @Provides
    @Singleton
    fun provideMediaExporter(
        @ApplicationContext context: Context,
        mediaManager: MediaManager
    ): MediaExporter {
        return MediaExporter(context, mediaManager)
    }

    @Provides
    @Singleton
    fun provideExportsRepository(
        @ApplicationContext context: Context,
        mediaManager: MediaManager
    ): ExportsRepository {
        return ExportsRepository(context, mediaManager)
    }
}
