package com.example.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.engine.MediaManager
import java.io.File
import java.util.Locale

enum class ExportFileType(val label: String, val mimeType: String) {
    MP4("MP4", "video/mp4"),
    PNG("PNG", "image/png")
}

data class ExportedMediaItem(
    val filePath: String,
    val fileName: String,
    val displayTitle: String,
    val type: ExportFileType,
    val fileSizeBytes: Long,
    val lastModifiedMs: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val shareUri: Uri
)

class ExportsRepository(
    private val context: Context,
    private val mediaManager: MediaManager
) {

    fun exportsDir(): File = File(context.filesDir, "exports").apply {
        if (!exists()) mkdirs()
    }

    fun listExports(): List<ExportedMediaItem> {
        val dir = exportsDir()
        val files = dir.listFiles()
            ?.filter { it.isFile && it.length() > 0L && it.extension.lowercase(Locale.US) in setOf("mp4", "png") }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()

        return files.mapNotNull { buildItem(it) }
    }

    fun getExportThumbnail(item: ExportedMediaItem, maxDimension: Int = 360): Bitmap? {
        return when (item.type) {
            ExportFileType.MP4 -> {
                val sampleMs = if (item.durationMs > 800L) item.durationMs / 4L else 0L
                mediaManager.getVideoFrame(
                    path = item.filePath,
                    mediaTimeMs = sampleMs,
                    exactFrame = false,
                    maxDimension = maxDimension
                )
            }
            ExportFileType.PNG -> {
                mediaManager.getImageBitmap(item.filePath, maxDimension = maxDimension)
            }
        }
    }

    fun renameExport(filePath: String, newBaseName: String): ExportedMediaItem? {
        val source = File(filePath)
        if (!source.exists() || !source.isFile) return null

        val sanitized = newBaseName.trim()
            .replace(Regex("[/\\\\:*?\"<>|]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(48)
        if (sanitized.isEmpty()) return null

        val ext = source.extension.lowercase(Locale.US).ifEmpty { "mp4" }
        val cleanBase = sanitized.removeSuffix(".$ext").trim()
        if (cleanBase.isEmpty()) return null

        var target = File(source.parentFile ?: exportsDir(), "$cleanBase.$ext")
        if (target.absolutePath == source.absolutePath) {
            return buildItem(source)
        }
        var suffix = 1
        while (target.exists() && suffix < 100) {
            target = File(source.parentFile ?: exportsDir(), "${cleanBase}_$suffix.$ext")
            suffix++
        }
        if (target.exists()) return null

        return if (source.renameTo(target)) {
            mediaManager.clearCache()
            buildItem(target)
        } else null
    }

    fun deleteExport(filePath: String): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false
        val deleted = file.delete()
        if (deleted) {
            mediaManager.clearCache()
        }
        return deleted
    }

    fun createShareIntent(item: ExportedMediaItem): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = item.type.mimeType
            putExtra(Intent.EXTRA_STREAM, item.shareUri)
            putExtra(Intent.EXTRA_SUBJECT, item.displayTitle)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun buildItem(file: File): ExportedMediaItem? {
        val ext = file.extension.lowercase(Locale.US)
        val type = when (ext) {
            "mp4" -> ExportFileType.MP4
            "png" -> ExportFileType.PNG
            else -> return null
        }
        var width = 0
        var height = 0
        var durationMs = 0L

        if (type == ExportFileType.PNG) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, opts)
            width = opts.outWidth.coerceAtLeast(0)
            height = opts.outHeight.coerceAtLeast(0)
        } else {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull()?.coerceAtLeast(0) ?: 0
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull()?.coerceAtLeast(0) ?: 0
            } catch (_: Throwable) {
                // Keep zero fallback metadata if container has unreadable metadata headers
            } finally {
                runCatching { retriever.release() }
            }
        }

        val shareUri = runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }.getOrElse { Uri.fromFile(file) }

        return ExportedMediaItem(
            filePath = file.absolutePath,
            fileName = file.name,
            displayTitle = file.nameWithoutExtension,
            type = type,
            fileSizeBytes = file.length(),
            lastModifiedMs = file.lastModified(),
            durationMs = durationMs,
            width = width,
            height = height,
            shareUri = shareUri
        )
    }
}
