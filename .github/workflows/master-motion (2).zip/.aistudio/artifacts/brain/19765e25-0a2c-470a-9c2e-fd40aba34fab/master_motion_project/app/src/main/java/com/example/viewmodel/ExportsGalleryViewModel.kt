package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ExportFileType
import com.example.data.ExportedMediaItem
import com.example.data.ExportsRepository
import com.example.engine.MediaManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

enum class ExportGalleryFilter(val label: String) {
    ALL("All"),
    VIDEOS("Videos"),
    IMAGES("Images")
}

data class ExportsGalleryUiState(
    val isLoading: Boolean = true,
    val items: List<ExportedMediaItem> = emptyList(),
    val filter: ExportGalleryFilter = ExportGalleryFilter.ALL,
    val previewItem: ExportedMediaItem? = null,
    val statusMessage: String? = null
) {
    val filteredItems: List<ExportedMediaItem>
        get() = when (filter) {
            ExportGalleryFilter.ALL -> items
            ExportGalleryFilter.VIDEOS -> items.filter { it.type == ExportFileType.MP4 }
            ExportGalleryFilter.IMAGES -> items.filter { it.type == ExportFileType.PNG }
        }
}

@HiltViewModel
class ExportsGalleryViewModel @Inject constructor(
    private val exportsRepository: ExportsRepository,
    val mediaManager: MediaManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExportsGalleryUiState())
    val uiState: StateFlow<ExportsGalleryUiState> = _uiState.asStateFlow()

    init {
        refreshExports()
    }

    fun refreshExports() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val loaded = withContext(Dispatchers.IO) {
                exportsRepository.listExports()
            }
            _uiState.update { state ->
                val activePreview = state.previewItem?.let { current ->
                    loaded.firstOrNull { it.filePath == current.filePath }
                }
                state.copy(
                    isLoading = false,
                    items = loaded,
                    previewItem = activePreview
                )
            }
        }
    }

    fun setFilter(filter: ExportGalleryFilter) {
        _uiState.update { it.copy(filter = filter) }
    }

    fun openPreview(item: ExportedMediaItem) {
        _uiState.update { it.copy(previewItem = item) }
    }

    fun closePreview() {
        _uiState.update { it.copy(previewItem = null) }
    }

    fun renameExport(item: ExportedMediaItem, newBaseName: String) {
        viewModelScope.launch {
            val renamed = withContext(Dispatchers.IO) {
                exportsRepository.renameExport(item.filePath, newBaseName)
            }
            if (renamed != null) {
                val updatedList = withContext(Dispatchers.IO) {
                    exportsRepository.listExports()
                }
                _uiState.update { state ->
                    state.copy(
                        items = updatedList,
                        previewItem = if (state.previewItem?.filePath == item.filePath) renamed else state.previewItem,
                        statusMessage = "Renamed to ${renamed.fileName}"
                    )
                }
            } else {
                _uiState.update { it.copy(statusMessage = "Could not rename file") }
            }
        }
    }

    fun deleteExport(item: ExportedMediaItem) {
        viewModelScope.launch {
            val removed = withContext(Dispatchers.IO) {
                exportsRepository.deleteExport(item.filePath)
            }
            if (removed) {
                val updatedList = withContext(Dispatchers.IO) {
                    exportsRepository.listExports()
                }
                _uiState.update { state ->
                    state.copy(
                        items = updatedList,
                        previewItem = if (state.previewItem?.filePath == item.filePath) null else state.previewItem,
                        statusMessage = "Deleted ${item.fileName}"
                    )
                }
            } else {
                _uiState.update { it.copy(statusMessage = "Failed to delete file") }
            }
        }
    }

    fun buildShareIntent(item: ExportedMediaItem) = exportsRepository.createShareIntent(item)

    suspend fun loadThumbnail(item: ExportedMediaItem) = withContext(Dispatchers.IO) {
        exportsRepository.getExportThumbnail(item, maxDimension = 420)
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}
