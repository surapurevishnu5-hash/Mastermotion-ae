package com.example.engine

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Looper
import android.provider.OpenableColumns
import android.util.LruCache
import com.example.model.LayerType
import com.example.model.MotionLayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class ImportedMediaMetadata(
    val localPath: String,
    val displayName: String,
    val layerType: LayerType,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val waveformSamples: List<Float>,
    val fileName: String = displayName
)

sealed interface MediaImportResult {
    data class Success(val metadata: ImportedMediaMetadata) : MediaImportResult
    data class Error(val message: String) : MediaImportResult
}

class MediaManager(private val context: Context) {

    val appContext: Context get() = context.applicationContext

    private val decodeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _previewFrameRevision = MutableStateFlow(0L)
    val previewFrameRevision: StateFlow<Long> = _previewFrameRevision.asStateFlow()
    private val latestPreviewFrames = ConcurrentHashMap<String, Bitmap>()
    private val inFlightVideoDecodes = ConcurrentHashMap.newKeySet<String>()
    private val inFlightImageDecodes = ConcurrentHashMap.newKeySet<String>()

    // Up to 48 MB in-memory cache for image layers and quantized preview video frames
    private val bitmapCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(48 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int =
            (value.allocationByteCount / 1024).coerceAtLeast(1)
    }

    suspend fun importMedia(
        projectId: String,
        uri: Uri,
        requestedType: LayerType
    ): ImportedMediaMetadata? {
        return when (val res = importMediaResult(projectId, uri, requestedType)) {
            is MediaImportResult.Success -> res.metadata
            is MediaImportResult.Error -> null
        }
    }

    suspend fun importMediaResult(
        projectId: String,
        uri: Uri,
        requestedType: LayerType
    ): MediaImportResult = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            runCatching {
                resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val displayName = queryDisplayName(uri)
                ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                ?: "${requestedType.label}_${System.currentTimeMillis() % 10000}"
            val mimeType = resolver.getType(uri).orEmpty().lowercase(Locale.US)
            val nameExt = displayName.substringAfterLast('.', "").lowercase(Locale.US)

            val detectedType = when {
                mimeType.startsWith("video/") || nameExt in setOf("mp4", "mov", "mkv", "webm", "3gp", "avi") -> LayerType.VIDEO
                mimeType.startsWith("image/") || nameExt in setOf("png", "jpg", "jpeg", "webp", "gif", "heic") -> LayerType.IMAGE
                mimeType.startsWith("audio/") || nameExt in setOf("mp3", "m4a", "aac", "wav", "ogg", "flac") -> LayerType.AUDIO
                else -> requestedType
            }

            val ext = when (detectedType) {
                LayerType.VIDEO -> when {
                    nameExt in setOf("mp4", "mov", "mkv", "webm") -> nameExt
                    mimeType.contains("webm") -> "webm"
                    mimeType.contains("quicktime") -> "mov"
                    else -> "mp4"
                }
                LayerType.IMAGE -> when {
                    nameExt in setOf("png", "jpg", "jpeg", "webp", "gif") -> nameExt
                    mimeType.contains("png") -> "png"
                    mimeType.contains("webp") -> "webp"
                    mimeType.contains("gif") -> "gif"
                    else -> "jpg"
                }
                LayerType.AUDIO -> when {
                    nameExt in setOf("mp3", "m4a", "aac", "wav", "ogg", "flac") -> nameExt
                    mimeType.contains("mpeg") || mimeType.contains("mp3") -> "mp3"
                    mimeType.contains("wav") -> "wav"
                    mimeType.contains("ogg") -> "ogg"
                    mimeType.contains("flac") -> "flac"
                    else -> "m4a"
                }
                else -> "bin"
            }

            val dir = File(context.filesDir, "project_media/$projectId").apply {
                if (!exists()) mkdirs()
            }
            val safeBase = displayName.substringBeforeLast('.')
                .replace(Regex("[^A-Za-z0-9._-]"), "_")
                .take(28)
                .ifBlank { requestedType.label.lowercase(Locale.US) }
            val resolvedFileName = if (displayName.contains('.')) displayName else "$safeBase.$ext"
            val destFile = File(dir, "${UUID.randomUUID().toString().take(8)}__$safeBase.$ext")

            val copied = try {
                resolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                    true
                } ?: false
            } catch (_: SecurityException) {
                return@withContext MediaImportResult.Error("Permission denied to read the selected file.")
            }

            if (!copied || !destFile.exists() || destFile.length() == 0L) {
                runCatching { destFile.delete() }
                return@withContext MediaImportResult.Error("Selected file is empty or unreadable.")
            }

            when (detectedType) {
                LayerType.IMAGE -> {
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(destFile.absolutePath, opts)
                    if (opts.outWidth <= 0 || opts.outHeight <= 0) {
                        runCatching { destFile.delete() }
                        return@withContext MediaImportResult.Error("Unsupported or corrupted image format.")
                    }
                    MediaImportResult.Success(
                        ImportedMediaMetadata(
                            localPath = destFile.absolutePath,
                            displayName = displayName.substringBeforeLast('.'),
                            layerType = LayerType.IMAGE,
                            durationMs = 5000L,
                            width = opts.outWidth,
                            height = opts.outHeight,
                            waveformSamples = emptyList(),
                            fileName = resolvedFileName
                        )
                    )
                }
                LayerType.VIDEO -> {
                    val retriever = MediaMetadataRetriever()
                    var duration = 5000L
                    var width = 1920
                    var height = 1080
                    try {
                        retriever.setDataSource(destFile.absolutePath)
                        duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                            ?.toLongOrNull()?.coerceAtLeast(500L) ?: 5000L
                        width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                            ?.toIntOrNull()?.coerceAtLeast(100) ?: 1920
                        height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                            ?.toIntOrNull()?.coerceAtLeast(100) ?: 1080
                    } catch (_: Throwable) {
                        runCatching { destFile.delete() }
                        return@withContext MediaImportResult.Error("Unsupported or unreadable video format.")
                    } finally {
                        runCatching { retriever.release() }
                    }
                    val waveform = extractWaveformSamples(destFile.absolutePath, 48)
                    MediaImportResult.Success(
                        ImportedMediaMetadata(
                            localPath = destFile.absolutePath,
                            displayName = displayName.substringBeforeLast('.'),
                            layerType = LayerType.VIDEO,
                            durationMs = duration,
                            width = width,
                            height = height,
                            waveformSamples = waveform,
                            fileName = resolvedFileName
                        )
                    )
                }
                LayerType.AUDIO -> {
                    val retriever = MediaMetadataRetriever()
                    var duration = 6000L
                    try {
                        retriever.setDataSource(destFile.absolutePath)
                        duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                            ?.toLongOrNull()?.coerceAtLeast(500L) ?: 6000L
                    } catch (_: Throwable) {
                        // Fall back cleanly to default duration if MediaMetadataRetriever lacks header in test/edge formats
                    } finally {
                        runCatching { retriever.release() }
                    }
                    val waveform = extractWaveformSamples(destFile.absolutePath, 64)
                    MediaImportResult.Success(
                        ImportedMediaMetadata(
                            localPath = destFile.absolutePath,
                            displayName = displayName.substringBeforeLast('.'),
                            layerType = LayerType.AUDIO,
                            durationMs = duration,
                            width = 0,
                            height = 0,
                            waveformSamples = waveform,
                            fileName = resolvedFileName
                        )
                    )
                }
                else -> MediaImportResult.Error("Unsupported media layer type.")
            }
        } catch (t: Throwable) {
            MediaImportResult.Error(t.message ?: "Failed to import media file.")
        }
    }

    fun getLayerThumbnail(layer: MotionLayer, maxDimension: Int = 180): Bitmap? {
        val path = layer.mediaPath ?: return null
        return getThumbnailForPath(path, layer.type, layer.mediaTrimStartMs, maxDimension)
    }

    fun getThumbnailForPath(
        path: String,
        type: LayerType,
        mediaTimeMs: Long = 0L,
        maxDimension: Int = 180
    ): Bitmap? {
        return when (type) {
            LayerType.IMAGE -> getImageBitmap(path, maxDimension = maxDimension)
            LayerType.VIDEO -> getVideoFrame(path, mediaTimeMs = mediaTimeMs, exactFrame = false, maxDimension = maxDimension)
            else -> null
        }
    }

    fun getThumbnailForMetadata(meta: ImportedMediaMetadata, maxDimension: Int = 180): Bitmap? {
        return when (meta.layerType) {
            LayerType.IMAGE -> getImageBitmap(meta.localPath, maxDimension = maxDimension)
            LayerType.VIDEO -> getVideoFrame(meta.localPath, mediaTimeMs = 0L, exactFrame = false, maxDimension = maxDimension)
            else -> null
        }
    }

    fun listProjectMedia(
        projectId: String,
        projectLayers: List<MotionLayer> = emptyList()
    ): List<ImportedMediaMetadata> {
        val byPath = linkedMapOf<String, ImportedMediaMetadata>()
        // Include media already referenced by project layers first
        for (layer in projectLayers) {
            val path = layer.mediaPath ?: continue
            val file = File(path)
            if (!file.exists()) continue
            if (!byPath.containsKey(path)) {
                val rawName = file.name.substringAfter("__", file.name)
                byPath[path] = ImportedMediaMetadata(
                    localPath = path,
                    displayName = layer.name,
                    layerType = layer.type,
                    durationMs = layer.mediaDurationMs,
                    width = layer.mediaWidth,
                    height = layer.mediaHeight,
                    waveformSamples = layer.waveformSamples,
                    fileName = rawName
                )
            }
        }
        // Scan filesDir/project_media/<projectId> for any other imported files
        val dir = File(context.filesDir, "project_media/$projectId")
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()
        for (file in files) {
            if (!file.isFile || file.length() <= 0L) continue
            val path = file.absolutePath
            if (byPath.containsKey(path)) continue
            val ext = file.extension.lowercase(Locale.US)
            val type = when (ext) {
                "mp4", "mov", "mkv", "webm", "3gp", "avi" -> LayerType.VIDEO
                "png", "jpg", "jpeg", "webp", "gif", "heic" -> LayerType.IMAGE
                "mp3", "m4a", "aac", "wav", "ogg", "flac" -> LayerType.AUDIO
                else -> continue
            }
            val cleanFileName = file.name.substringAfter("__", file.name)
            byPath[path] = ImportedMediaMetadata(
                localPath = path,
                displayName = cleanFileName.substringBeforeLast('.'),
                layerType = type,
                durationMs = if (type == LayerType.IMAGE) 5000L else 6000L,
                width = if (type == LayerType.AUDIO) 0 else 1920,
                height = if (type == LayerType.AUDIO) 0 else 1080,
                waveformSamples = emptyList(),
                fileName = cleanFileName
            )
        }
        return byPath.values.toList()
    }

    fun prewarmProjectMedia(layers: List<MotionLayer>) {
        decodeScope.launch {
            for (layer in layers) {
                val path = layer.mediaPath ?: continue
                if (!File(path).exists()) continue
                when (layer.type) {
                    LayerType.IMAGE -> getImageBitmap(path, maxDimension = 1080)
                    LayerType.VIDEO -> {
                        val key = "vid|$path|${(layer.mediaTrimStartMs / 66L) * 66L}|720"
                        if (bitmapCache.get(key) == null) {
                            decodeVideoFrameSync(path, (layer.mediaTrimStartMs / 66L) * 66L, exactFrame = false, maxDimension = 720)?.let {
                                bitmapCache.put(key, it)
                                latestPreviewFrames[path] = it
                            }
                        }
                    }
                    else -> Unit
                }
            }
            _previewFrameRevision.value++
        }
    }

    fun getImageBitmap(path: String, maxDimension: Int = 1280): Bitmap? {
        val key = "img|$path|$maxDimension"
        bitmapCache.get(key)?.let { if (!it.isRecycled) return it }

        val file = File(path)
        if (!file.exists()) return null

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        val maxSide = max(bounds.outWidth, bounds.outHeight)
        while (maxSide / sampleSize > maxDimension) {
            sampleSize *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = runCatching { BitmapFactory.decodeFile(path, decodeOpts) }.getOrNull() ?: return null
        bitmapCache.put(key, decoded)
        return decoded
    }

    fun getVideoFrame(
        path: String,
        mediaTimeMs: Long,
        exactFrame: Boolean = false,
        maxDimension: Int = 960
    ): Bitmap? {
        val quantizedMs = if (exactFrame) mediaTimeMs else (mediaTimeMs / 66L) * 66L
        val key = "vid|$path|$quantizedMs|$maxDimension"
        if (!exactFrame) {
            bitmapCache.get(key)?.let { if (!it.isRecycled) return it }
        }
        val file = File(path)
        if (!file.exists()) return null

        // Never run MediaMetadataRetriever synchronously on the Android Main UI thread during preview/scrubbing
        if (!exactFrame && Looper.myLooper() == Looper.getMainLooper()) {
            if (inFlightVideoDecodes.add(key)) {
                decodeScope.launch {
                    try {
                        val decoded = decodeVideoFrameSync(path, quantizedMs, exactFrame = false, maxDimension = maxDimension)
                        if (decoded != null) {
                            bitmapCache.put(key, decoded)
                            latestPreviewFrames[path] = decoded
                            _previewFrameRevision.value++
                        }
                    } finally {
                        inFlightVideoDecodes.remove(key)
                    }
                }
            }
            return latestPreviewFrames[path]?.takeIf { !it.isRecycled }
        }

        val decoded = decodeVideoFrameSync(path, quantizedMs, exactFrame, maxDimension)
        if (decoded != null && !exactFrame) {
            bitmapCache.put(key, decoded)
            latestPreviewFrames[path] = decoded
        }
        return decoded
    }

    private fun decodeVideoFrameSync(
        path: String,
        quantizedMs: Long,
        exactFrame: Boolean,
        maxDimension: Int
    ): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val timeUs = (quantizedMs * 1000L).coerceAtLeast(0L)
            val option = if (exactFrame) {
                MediaMetadataRetriever.OPTION_CLOSEST
            } else {
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            }
            val raw = retriever.getFrameAtTime(timeUs, option)
                ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            val scaled = scaleDownIfNeeded(raw, maxDimension)
            if (scaled !== raw && !raw.isRecycled) raw.recycle()
            scaled
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun deleteProjectMedia(projectId: String) {
        val dir = File(context.filesDir, "project_media/$projectId")
        if (dir.exists()) {
            dir.deleteRecursively()
        }
    }

    fun clearCache() {
        bitmapCache.evictAll()
        latestPreviewFrames.clear()
        inFlightVideoDecodes.clear()
        inFlightImageDecodes.clear()
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val longest = max(w, h)
        if (longest <= maxDimension || longest <= 0) return bitmap
        val ratio = maxDimension.toFloat() / longest.toFloat()
        val newW = (w * ratio).toInt().coerceAtLeast(1)
        val newH = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
    }.getOrNull()

    /**
     * Samples packet sizes / energy from the audio track via MediaExtractor to produce
     * an accurate normalized waveform envelope without requiring full PCM decode overhead.
     */
    private fun extractWaveformSamples(path: String, bucketCount: Int): List<Float> {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(path)
            var audioTrackIndex = -1
            var durationUs = 0L
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
                        format.getLong(MediaFormat.KEY_DURATION)
                    } else 5_000_000L
                    break
                }
            }
            if (audioTrackIndex < 0) {
                return List(bucketCount) { 0.25f }
            }
            extractor.selectTrack(audioTrackIndex)
            val buckets = FloatArray(bucketCount)
            val counts = IntArray(bucketCount)
            val buffer = ByteBuffer.allocate(16 * 1024)
            var samplesRead = 0
            while (samplesRead < 400) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val timeUs = extractor.sampleTime.coerceAtLeast(0L)
                val bucket = if (durationUs > 0L) {
                    ((timeUs.toDouble() / durationUs.toDouble()) * bucketCount).toInt()
                        .coerceIn(0, bucketCount - 1)
                } else {
                    samplesRead % bucketCount
                }
                // Inspect byte energy in packet
                var energy = 0f
                val limit = min(sampleSize, 256)
                for (b in 0 until limit) {
                    energy += abs((buffer.get(b).toInt() and 0xFF) - 128)
                }
                val norm = (energy / max(1, limit) / 128f).coerceIn(0.12f, 1.0f)
                buckets[bucket] += norm
                counts[bucket]++
                samplesRead++
                extractor.advance()
            }
            val rawList = List(bucketCount) { idx ->
                if (counts[idx] > 0) buckets[idx] / counts[idx] else 0.18f
            }
            val peak = rawList.maxOrNull()?.coerceAtLeast(0.1f) ?: 1f
            rawList.map { (it / peak).coerceIn(0.15f, 1.0f) }
        } catch (_: Throwable) {
            List(bucketCount) { idx ->
                0.3f + 0.5f * abs(kotlin.math.sin(idx * 0.45f))
            }
        } finally {
            runCatching { extractor.release() }
        }
    }
}
