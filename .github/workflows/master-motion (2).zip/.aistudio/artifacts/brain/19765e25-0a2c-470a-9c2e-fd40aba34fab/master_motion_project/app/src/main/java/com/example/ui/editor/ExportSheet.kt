package com.example.ui.editor

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.engine.ExportConfig
import com.example.engine.ExportResult
import com.example.model.ExportFormat
import com.example.model.ExportQuality
import com.example.model.ExportResolution
import com.example.model.MotionProject
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioInspector
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.ExportUiState
import java.util.Locale

@Composable
fun ExportDialog(
    project: MotionProject,
    exportState: ExportUiState,
    onStartExport: (ExportConfig) -> Unit,
    onCancelExport: () -> Unit,
    onOpenExportsGallery: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var format by remember { mutableStateOf(ExportFormat.MP4_VIDEO) }
    var resolution by remember { mutableStateOf(ExportResolution.FHD_1080P) }
    var fps by remember(project.fps) { mutableIntStateOf(project.fps) }
    var quality by remember { mutableStateOf(ExportQuality.HIGH) }

    val (targetW, targetH) = project.aspectRatio.dimensionsFor(resolution)

    Dialog(onDismissRequest = {
        if (exportState !is ExportUiState.Running) onDismiss()
    }) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = StudioSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Studio Export", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ElectricPurple.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "${targetW}×${targetH}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                when (exportState) {
                    is ExportUiState.Idle -> {
                        // Format Selector: MP4 Video vs PNG Image
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Format", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ExportFormat.entries.forEach { fmt ->
                                    val selected = fmt == format
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (selected) ElectricPurple.copy(alpha = 0.22f) else StudioSurfaceElevated,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.5.dp,
                                            if (selected) ElectricPurple else StudioBorder
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { format = fmt }
                                            .testTag("export_format_${fmt.name}")
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center,
                                            modifier = Modifier.padding(vertical = 12.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (fmt == ExportFormat.MP4_VIDEO) Icons.Filled.Movie else Icons.Filled.Image,
                                                contentDescription = null,
                                                tint = if (selected) Color.White else TextSecondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = fmt.label,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (selected) Color.White else TextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Resolution Selector: 1080p vs 4K
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Resolution", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ExportResolution.entries.forEach { res ->
                                    val selected = res == resolution
                                    val (rw, rh) = project.aspectRatio.dimensionsFor(res)
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (selected) CyberBlue.copy(alpha = 0.25f) else StudioSurfaceElevated,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.5.dp,
                                            if (selected) CyberCyan else StudioBorder
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { resolution = res }
                                            .testTag("export_res_${res.name}")
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        ) {
                                            Text(
                                                text = res.badge,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = if (selected) Color.White else TextPrimary
                                            )
                                            Text(
                                                text = "${rw}×${rh}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (selected) CyberCyan else TextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (format == ExportFormat.MP4_VIDEO) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("FPS", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf(24, 30, 60).forEach { f ->
                                            val sel = fps == f
                                            Box(
                                                contentAlignment = Alignment.Center,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(36.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (sel) ElectricPurple.copy(alpha = 0.25f) else StudioInspector)
                                                    .border(1.dp, if (sel) ElectricPurple else StudioBorder, RoundedCornerShape(8.dp))
                                                    .clickable { fps = f }
                                            ) {
                                                Text("$f", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                            }
                                        }
                                    }
                                }

                                Column(
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Bitrate", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        ExportQuality.entries.forEach { q ->
                                            val sel = quality == q
                                            Box(
                                                contentAlignment = Alignment.Center,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(36.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (sel) CyberBlue.copy(alpha = 0.25f) else StudioInspector)
                                                    .border(1.dp, if (sel) CyberBlue else StudioBorder, RoundedCornerShape(8.dp))
                                                    .clickable { quality = q }
                                            ) {
                                                Text(
                                                    text = q.label.take(4),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TextButton(onClick = onDismiss) {
                                Text("Close", color = TextSecondary)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    onStartExport(ExportConfig(format, resolution, fps, quality))
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Brush.horizontalGradient(listOf(ElectricPurple, CyberBlue)))
                                    .testTag("start_export_button")
                            ) {
                                Icon(Icons.Filled.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Render & Save", color = Color.White, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    is ExportUiState.Running -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportState.progress.statusText,
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextPrimary
                            )
                            LinearProgressIndicator(
                                progress = { exportState.progress.fraction.coerceIn(0f, 1f) },
                                color = ElectricPurple,
                                trackColor = StudioInspector,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            )
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "${(exportState.progress.fraction * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberCyan
                                )
                                TextButton(onClick = onCancelExport) {
                                    Text("Cancel", color = ErrorCoral)
                                }
                            }
                        }
                    }

                    is ExportUiState.Completed -> {
                        ExportCompletedContent(
                            result = exportState.result,
                            onShare = {
                                val mime = if (exportState.result.format == ExportFormat.MP4_VIDEO) "video/mp4" else "image/png"
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = mime
                                    putExtra(Intent.EXTRA_STREAM, exportState.result.shareUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Master Motion Export"))
                            },
                            onOpenGallery = {
                                onDismiss()
                                onOpenExportsGallery()
                            },
                            onDone = onDismiss
                        )
                    }

                    is ExportUiState.Failed -> {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = ErrorCoral)
                                Text(exportState.message, style = MaterialTheme.typography.bodyMedium, color = ErrorCoral)
                            }
                            Row(
                                horizontalArrangement = Arrangement.End,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                TextButton(onClick = onDismiss) {
                                    Text("Close", color = TextSecondary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExportCompletedContent(
    result: ExportResult,
    onShare: () -> Unit,
    onOpenGallery: () -> Unit,
    onDone: () -> Unit
) {
    val sizeMb = String.format(Locale.US, "%.2f MB", result.fileSizeBytes / (1024.0 * 1024.0))
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(SuccessGreen.copy(alpha = 0.2f))
        ) {
            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(30.dp))
        }
        Text(
            text = "${result.format.label} Ready!",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary
        )
        Text(
            text = "${result.resolution.badge} (${result.width}×${result.height}) • $sizeMb",
            style = MaterialTheme.typography.labelSmall,
            color = CyberCyan
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = onShare,
                modifier = Modifier.weight(1f).testTag("share_export_button")
            ) {
                Icon(Icons.Filled.Share, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share", color = TextPrimary)
            }
            Button(
                onClick = onDone,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                modifier = Modifier.weight(1f).testTag("done_export_button")
            ) {
                Text("Done", color = Color.White)
            }
        }
        TextButton(
            onClick = onOpenGallery,
            modifier = Modifier.testTag("open_gallery_after_export_button")
        ) {
            Text("View & Play in Exports Gallery", color = CyberCyan)
        }
    }
}
