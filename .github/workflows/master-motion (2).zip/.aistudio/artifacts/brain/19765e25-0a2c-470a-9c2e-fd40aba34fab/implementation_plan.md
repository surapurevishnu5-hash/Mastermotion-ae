# Master Motion — Next Studio Milestone (Pro Audio, Chroma Key, Presets & Exports Gallery)

Master Motion already provides a complete Room-backed Projects Hub, AndroidX Media3 ExoPlayer video/audio preview, multi-track timeline editing, keyframe curves, and 1080p/4K export. This next milestone elevates creator productivity with a **Pro Audio Mixer & Voiceover Recorder**, **Chroma Key & Kinetic Text Presets**, and an **On-Device Exports Gallery**—keeping the Obsidian dark studio aesthetic and fast device-local persistence.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The interactive questions were skipped, so this plan uses our recommended defaults across features, workspace layout, and persistence. Review the decisions below before approving.

- **Confirmed Default 1 — Next Feature Scope**: Adds **Video Export Polish & Exports Gallery**, **Audio Mixer, Fade Envelopes & Voiceover Recording**, **Chroma Key (Green/Blue Screen) Effect**, and **One-Tap Kinetic Text & Typography Presets**.
- **Confirmed Default 2 — Workspace Evolution**: Preserves the **Obsidian dark pro studio layout** (`#0A0B10` canvas backdrop, `#131622` studio surfaces, Electric Purple `#8B5CF6` & Cyber Cyan `#38BDF8` accents) while integrating new Audio/Voiceover and Exports Gallery controls cleanly into existing studio panels.
- **Confirmed Default 3 — Storage Posture**: Keeps projects and exported media **device-local** via Room + app-private media folders + `.mmproj` project files and Android `MediaStore` gallery outputs (zero cloud sign-in friction).

---

### 1. Overview & Core Concept

- **What It Does**: Lets mobile editors record narrated voiceovers directly onto the timeline, shape audio tracks with smooth fade-in/out envelopes and per-track faders, key out green/blue screen backgrounds on imported videos/photos, apply multi-font kinetic typography presets in one tap, and inspect or replay finished exports in a dedicated Exports Gallery.
- **Target Audience / Persona**: Short-form creators, tutorial makers, and motion designers editing voice-led reels, commentary clips, and green-screen overlays directly on Android.
- **Key Value**: Bridges the gap between raw multi-track assembly and broadcast-ready finishing without requiring third-party audio tools, green-screen apps, or external video players.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Voiceover & Audio Mixing**: In the **Trim & Audio** inspector (or Audio Mixer strip), creators tap **Record Voiceover**, grant microphone permission once via standard Android runtime prompt, watch a live dB meter while speaking against timeline playback, and tap **Stop** to drop the recorded `.m4a` track straight onto the timeline with waveform bars. Sliders adjust volume, **Fade In**, and **Fade Out** durations.
  2. **Chroma Key & Layer Styling**: Selecting any video or image layer opens **FX & Trans**, where toggling **Chroma Key** reveals target color swatches (Emerald Green `#00D15B`, Cobalt Blue `#1D4ED8`, or custom screen tone), **Similarity Tolerance**, and **Edge Feather** sliders rendered live on the preview canvas.
  3. **Kinetic Text & Font Presets**: Selecting a text layer in **Layers** offers one-tap **Typography Presets** (*Typewriter Pop*, *Neon Pulse*, *Slide Reveal*, *Editorial Clean*) paired with studio font pills (**Space Grotesk**, **Inter**, **JetBrains Mono**) that automatically populate clean keyframe curves and colors.
  4. **Exports Gallery & Playback**: From the **Projects Hub** top bar or inside the **Export Dialog** completion card, creators open **Exports Gallery** to view thumbnail cards of rendered MP4/PNG outputs, replay finished videos inside an embedded **Media3 ExoPlayer** sheet, share via Android Sharesheet, or clean up old renders.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: High-precision dark post-production suite—razor-thin `#2D3348` borders, tonal layered cards (`#131622` / `#1B1F31`), and luminous semantic accents matching track categories.
  - *Color Palette & Mood*: Obsidian backdrop (`#0A0B10`), Electric Purple (`#8B5CF6`) primary actions, Cyber Blue/Cyan (`#3B82F6` / `#38BDF8`) playhead & audio meters, Emerald (`#10B981`) audio track fades & chroma indicators, and Keyframe Magenta (`#EC4899`).
  - *Typography & Hierarchy*: **Space Grotesk** for display titles and preset headers, **Inter** for dense audio/chroma sliders, and **JetBrains Mono** for exact millisecond fades, bitrates, and recording timers.
  - *Component Styling & Layout*: Edge-to-edge M3 layouts (`WindowInsets.safeDrawing`), `>= 48dp` interactive targets, horizontally scrollable preset chips, and adaptive phone/tablet sheets.

- **Interactive Feedback & Motion**:
  - Live pulsing red-coral VU level bar during active voiceover capture; animated fade-ramp polygons drawn directly over audio timeline clip bars; smooth `AnimatedVisibility` transitions when opening Chroma Key tuning or the Exports Gallery player.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Dual-Mode Audio Fade Rendering (Preview + Export)**
  - *Chosen Approach*: Evaluate smooth per-frame fade-in/out gain curves in both real-time Media3 `ExoPlayer` playback ticks and offscreen AAC mixdown in `MediaExporter`.
  - *Why*: Ensures fade-ins and ducking heard during preview match the exported MP4 soundtrack cleanly.
  - *Alternatives Considered*: Post-export FFmpeg/Transformer audio graph only, which adds heavy native binary size and mismatches live ExoPlayer preview.

- **Decision 2 — Least-Privilege Microphone Capture for Voiceover**
  - *Chosen Approach*: Request `RECORD_AUDIO` exclusively at the moment the user taps **Record Voiceover** using Jetpack Compose's runtime permission launcher, saving `.m4a` audio directly into project-local storage.
  - *Why*: Keeps Photo Picker / media import zero-permission while delivering genuine on-device voiceover recording with graceful denied-state messaging.
  - *Alternatives Considered*: External audio recording intent, which breaks timeline sync and prevents simultaneous reference playback.

- **Decision 3 — Real-Time Shader-Free Chroma Key Fallback + Export Parity**
  - *Chosen Approach*: Implement fast HSV/RGB distance alpha keying inside the shared composition bitmap pass (cached per frame/source in `MediaManager` during preview and computed per frame in `MediaExporter`).
  - *Why*: Guarantees identical green-screen cutout behavior across all Android GPU/emulator environments and between preview and 1080p/4K MP4 export.

---

### 4. Technical Architecture & Data Strategy

- **Architecture & Component Diagram**:
```text
┌────────────────────────────────────────────────────────────────────────┐
│                       Master Motion Studio UI                          │
│  ┌─────────────────────┐      ┌──────────────────────────────────────┐ │
│  │    Projects Hub     │─────▶│           Editor Studio              │ │
│  │ • Saved Grid        │      │ • Media3 Preview & Keyed Canvas      │ │
│  │ • Exports Gallery ◀─┼──────┼─• Audio Clip Fade Overlays           │ │
│  └─────────────────────┘      │ • Inspector: Mixer / Voiceover /     │ │
│                               │   Chroma Key / Text Presets          │ │
│                               └──────────────────┬───────────────────┘ │
└──────────────────────────────────────────────────┼─────────────────────┘
                                                   │
                                                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│                    ViewModels & Studio Controllers                     │
│  • EditorViewModel (Audio Fades, Voiceover State, Presets, Export)     │
│  • VoiceoverRecorder (MediaRecorder M4A + Live Amplitude Meter)        │
│  • Media3VideoPreviewController & AudioPlaybackController (Fade Gain)  │
└──────────────────────────┬─────────────────────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────────────────────┐
│                  Render, Keying & Storage Layer                        │
│  • CompositionRenderer (Chroma Key Alpha + Font Family + Keyframes)    │
│  • MediaExporter (MP4/PNG + Export History Index + Audio Fade Envelope)│
│  • Room Database & App-Private Project Media / Export Directories      │
└────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Layer Extensions**: Add `audioFadeInMs`, `audioFadeOutMs`, `fontStyle` (*Space Grotesk*, *Inter*, *JetBrains Mono*), and `chromaKeyConfig` (`enabled`, `targetColorHex`, `tolerance`, `softness`) with backward-compatible serialization defaults for existing projects.
  - **Voiceover Recorder State**: Tracks `isRecording`, `elapsedMs`, `amplitudeLevel`, and permission/error state in `EditorUiState`.
  - **Export History Item**: Represents rendered files on disk (filename, format, resolution badge, duration/size, timestamp, share URI) for the Exports Gallery.

- **Interactive Component & State Mapping**:
  - **Voiceover Record Control**: Checks `RECORD_AUDIO` permission → starts `MediaRecorder` synchronized with timeline playback → on Stop, extracts waveform samples via `MediaManager` and commits a new `AUDIO` layer at the starting playhead.
  - **Audio Fade Sliders**: Update `audioFadeInMs`/`audioFadeOutMs` with undo support, redraw linear fade ramps on the timeline clip bar, and modulate `ExoPlayer` volume during playback + `MediaExporter` audio samples on render.
  - **Kinetic Text Preset Chips**: Mutate `fontStyle`, `colorHex`, and `keyframeTracks` atomically via `commitProjectEdit` so one tap produces an animated title that users can further customize in **Graph** or **Transform**.
  - **Exports Gallery Sheet**: Scans app export outputs, launches an inline **Media3 ExoPlayer** video dialog or high-res PNG viewer, and triggers Android Share/Delete actions.
